export * as UtxoGlobalA from "./advancedBarrel.js";
//# sourceMappingURL=advanced.d.ts.map