"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SignerDoge = void 0;
const core_1 = require("@ckb-ccc/core");
/**
 * @public
 */
class SignerDoge extends core_1.ccc.SignerDoge {
    constructor(client, provider, preferredNetworks = [
        {
            addressPrefix: "ckb",
            signerType: core_1.ccc.SignerType.Doge,
            network: "doge",
        },
        {
            addressPrefix: "ckt",
            signerType: core_1.ccc.SignerType.Doge,
            network: "dogeTestnet",
        },
    ]) {
        super(client);
        this.provider = provider;
        this.preferredNetworks = preferredNetworks;
    }
    async getDogeAddress() {
        const accounts = await this.provider.getAccount();
        this.accountCache = accounts[0];
        return this.accountCache;
    }
    /**
     * Ensure the BTC network is the same as CKB network.
     */
    async ensureNetwork() {
        const network = await this._getNetworkToChange();
        if (!network) {
            return;
        }
        const chain = {
            doge: "dogecoin",
            dogeTestnet: "dogecoin_testnet",
        }[network];
        if (chain) {
            await this.provider.switchNetwork(chain);
            return;
        }
        throw new Error(`UTXO Global Doge wallet doesn't support the requested chain ${network}`);
    }
    async _getNetworkToChange() {
        const currentNetwork = {
            dogecoin: "doge",
            dogecoin_testnet: "dogeTestnet",
        }[await this.provider.getNetwork()];
        const { network } = this.matchNetworkPreference(this.preferredNetworks, currentNetwork) ?? { network: currentNetwork };
        if (network === currentNetwork) {
            return;
        }
        return network;
    }
    onReplaced(listener) {
        const stop = [];
        const replacer = async () => {
            listener();
            stop[0]?.();
        };
        stop.push(() => {
            this.provider.removeListener("accountsChanged", replacer);
            this.provider.removeListener("networkChanged", replacer);
        });
        this.provider.on("accountsChanged", replacer);
        this.provider.on("networkChanged", replacer);
        return stop[0];
    }
    async connect() {
        await this.provider.connect();
        await this.ensureNetwork();
    }
    async isConnected() {
        if ((await this._getNetworkToChange()) !== undefined) {
            return false;
        }
        return await this.provider.isConnected();
    }
    async signMessageRaw(message) {
        const challenge = typeof message === "string" ? message : core_1.ccc.hexFrom(message).slice(2);
        return this.provider.signMessage(challenge, this.accountCache ?? (await this.getDogeAddress()));
    }
}
exports.SignerDoge = SignerDoge;
