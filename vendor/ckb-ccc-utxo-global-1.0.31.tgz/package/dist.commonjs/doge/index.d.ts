import { ccc } from "@ckb-ccc/core";
import { Provider } from "../advancedBarrel.js";
/**
 * @public
 */
export declare class SignerDoge extends ccc.SignerDoge {
    readonly provider: Provider;
    private readonly preferredNetworks;
    private accountCache;
    constructor(client: ccc.Client, provider: Provider, preferredNetworks?: ccc.NetworkPreference[]);
    getDogeAddress(): Promise<string>;
    /**
     * Ensure the BTC network is the same as CKB network.
     */
    ensureNetwork(): Promise<void>;
    _getNetworkToChange(): Promise<string | undefined>;
    onReplaced(listener: () => void): () => void;
    connect(): Promise<void>;
    isConnected(): Promise<boolean>;
    signMessageRaw(message: string | ccc.BytesLike): Promise<string>;
}
//# sourceMappingURL=index.d.ts.map