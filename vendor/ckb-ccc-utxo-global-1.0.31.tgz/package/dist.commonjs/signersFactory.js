"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUtxoGlobalSigners = getUtxoGlobalSigners;
const index_js_1 = require("./btc/index.js");
const index_js_2 = require("./ckb/index.js");
const index_js_3 = require("./doge/index.js");
/**
 * @public
 */
function getUtxoGlobalSigners(client, preferredNetworks) {
    const windowRef = window;
    if (typeof windowRef.utxoGlobal === "undefined") {
        return [];
    }
    return [
        {
            name: "CKB",
            signer: new index_js_2.SignerCkb(client, windowRef.utxoGlobal.ckbSigner),
        },
        {
            name: "BTC",
            signer: new index_js_1.SignerBtc(client, windowRef.utxoGlobal.bitcoinSigner, preferredNetworks),
        },
        {
            name: "DOGE",
            signer: new index_js_3.SignerDoge(client, windowRef.utxoGlobal.dogeSigner, preferredNetworks),
        },
    ];
}
