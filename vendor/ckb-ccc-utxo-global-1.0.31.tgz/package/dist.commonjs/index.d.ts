export * as UtxoGlobal from "./barrel.js";
//# sourceMappingURL=index.d.ts.map