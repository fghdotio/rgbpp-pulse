import { ccc } from "@ckb-ccc/core";
/**
 * @public
 */
export declare function getUtxoGlobalSigners(client: ccc.Client, preferredNetworks?: ccc.NetworkPreference[]): ccc.SignerInfo[];
//# sourceMappingURL=signersFactory.d.ts.map