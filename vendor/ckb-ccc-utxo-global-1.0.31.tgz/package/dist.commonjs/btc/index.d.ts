import { ccc } from "@ckb-ccc/core";
import { Provider } from "../advancedBarrel.js";
/**
 * @public
 */
export declare class SignerBtc extends ccc.SignerBtc {
    readonly provider: Provider;
    private readonly preferredNetworks;
    private accountCache;
    constructor(client: ccc.Client, provider: Provider, preferredNetworks?: ccc.NetworkPreference[]);
    getBtcAccount(): Promise<string>;
    getBtcPublicKey(): Promise<ccc.Hex>;
    /**
     * Ensure the BTC network is the same as CKB network.
     */
    ensureNetwork(): Promise<void>;
    _getNetworkToChange(): Promise<string | undefined>;
    onReplaced(listener: () => void): () => void;
    connect(): Promise<void>;
    isConnected(): Promise<boolean>;
    signMessageRaw(message: string | ccc.BytesLike): Promise<string>;
    /**
     * Signs a PSBT using UTXO Global wallet.
     *
     * @param psbtHex - The hex string of PSBT to sign.
     * @param options - Options for signing the PSBT
     * @returns A promise that resolves to the signed PSBT as a Hex string
     */
    signPsbt(_psbtHex: ccc.HexLike, _options?: ccc.SignPsbtOptionsLike): Promise<ccc.Hex>;
    /**
     * Broadcasts a signed PSBT to the Bitcoin network.
     *
     * @param psbtHex - The hex string of signed PSBT to broadcast.
     * @returns A promise that resolves to the transaction ID as a Hex string
     * @todo Implement PSBT broadcasting with UTXO Global
     */
    broadcastPsbt(_psbtHex: ccc.HexLike, _options?: ccc.SignPsbtOptionsLike): Promise<ccc.Hex>;
}
//# sourceMappingURL=index.d.ts.map