"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SignerBtc = void 0;
const core_1 = require("@ckb-ccc/core");
/**
 * @public
 */
class SignerBtc extends core_1.ccc.SignerBtc {
    constructor(client, provider, preferredNetworks = [
        {
            addressPrefix: "ckb",
            signerType: core_1.ccc.SignerType.BTC,
            network: "btc",
        },
        {
            addressPrefix: "ckt",
            signerType: core_1.ccc.SignerType.BTC,
            network: "btcTestnet",
        },
    ]) {
        super(client);
        this.provider = provider;
        this.preferredNetworks = preferredNetworks;
    }
    async getBtcAccount() {
        const accounts = await this.provider.getAccount();
        this.accountCache = accounts[0];
        return this.accountCache;
    }
    async getBtcPublicKey() {
        const pubKeys = await this.provider.getPublicKey();
        const account = await this.getBtcAccount();
        const pubKey = pubKeys.find((p) => p.address === account);
        if (!pubKey) {
            throw new Error("pubKey not found");
        }
        return core_1.ccc.hexFrom(pubKey.publicKey);
    }
    /**
     * Ensure the BTC network is the same as CKB network.
     */
    async ensureNetwork() {
        const network = await this._getNetworkToChange();
        if (!network) {
            return;
        }
        const chain = {
            btc: "btc",
            btcTestnet: "btc_testnet",
            btcTestnet4: "btc_testnet_4",
            btcSignet: "btc_signet",
        }[network];
        if (chain) {
            await this.provider.switchNetwork(chain);
            return;
        }
        throw new Error(`UTXO Global wallet doesn't support the requested chain ${network}`);
    }
    async _getNetworkToChange() {
        const currentNetwork = {
            btc: "btc",
            btc_testnet: "btcTestnet",
            btc_testnet_4: "btcTestnet4",
            btc_signet: "btcSignet",
        }[await this.provider.getNetwork()];
        const { network } = this.matchNetworkPreference(this.preferredNetworks, currentNetwork) ?? { network: currentNetwork };
        if (network === currentNetwork) {
            return;
        }
        return network;
    }
    onReplaced(listener) {
        const stop = [];
        const replacer = async () => {
            listener();
            stop[0]?.();
        };
        stop.push(() => {
            this.provider.removeListener("accountsChanged", replacer);
            this.provider.removeListener("networkChanged", replacer);
        });
        this.provider.on("accountsChanged", replacer);
        this.provider.on("networkChanged", replacer);
        return stop[0];
    }
    async connect() {
        await this.provider.connect();
        await this.ensureNetwork();
    }
    async isConnected() {
        if ((await this._getNetworkToChange()) !== undefined) {
            return false;
        }
        return await this.provider.isConnected();
    }
    async signMessageRaw(message) {
        const challenge = typeof message === "string" ? message : core_1.ccc.hexFrom(message).slice(2);
        return this.provider.signMessage(challenge, this.accountCache ?? (await this.getBtcAccount()));
    }
    /**
     * Signs a PSBT using UTXO Global wallet.
     *
     * @param psbtHex - The hex string of PSBT to sign.
     * @param options - Options for signing the PSBT
     * @returns A promise that resolves to the signed PSBT as a Hex string
     */
    async signPsbt(_psbtHex, _options) {
        throw new Error("UTXO Global PSBT signing not implemented yet");
    }
    /**
     * Broadcasts a signed PSBT to the Bitcoin network.
     *
     * @param psbtHex - The hex string of signed PSBT to broadcast.
     * @returns A promise that resolves to the transaction ID as a Hex string
     * @todo Implement PSBT broadcasting with UTXO Global
     */
    async broadcastPsbt(_psbtHex, _options) {
        throw new Error("UTXO Global PSBT broadcasting not implemented yet");
    }
}
exports.SignerBtc = SignerBtc;
