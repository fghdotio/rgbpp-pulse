"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SignerCkb = void 0;
const core_1 = require("@ckb-ccc/core");
/**
 * @public
 */
class SignerCkb extends core_1.ccc.Signer {
    get type() {
        return core_1.ccc.SignerType.CKB;
    }
    /**
     * Gets the sign type.
     * @returns The sign type.
     */
    get signType() {
        return core_1.ccc.SignerSignType.CkbSecp256k1;
    }
    constructor(client, provider) {
        super(client);
        this.provider = provider;
    }
    getInternalAddress() {
        return this.getAccount();
    }
    async getIdentity() {
        return this.getPublicKey();
    }
    async getAddressObj() {
        const address = await this.getInternalAddress();
        return core_1.ccc.Address.fromString(address, this.client);
    }
    async getAddressObjs() {
        return [await this.getAddressObj()];
    }
    async getAccount() {
        const accounts = await this.provider.getAccount();
        this.accountCache = accounts[0];
        return this.accountCache;
    }
    async getPublicKey() {
        const pubKeys = await this.provider.getPublicKey();
        const account = await this.getAccount();
        const pubKey = pubKeys.find((p) => p.address === account);
        if (!pubKey) {
            throw new Error("pubKey not found");
        }
        return core_1.ccc.hexFrom(pubKey.publicKey);
    }
    get ckbNetwork() {
        return this.client.addressPrefix === "ckb" ? "nervos" : "nervos_testnet";
    }
    async connect() {
        await this.provider.connect();
        if (this.ckbNetwork === (await this.provider.getNetwork())) {
            return;
        }
        await this.provider.switchNetwork(this.ckbNetwork);
    }
    onReplaced(listener) {
        const stop = [];
        const replacer = async () => {
            listener();
            stop[0]?.();
        };
        stop.push(() => {
            this.provider.removeListener("accountsChanged", replacer);
            this.provider.removeListener("networkChanged", replacer);
        });
        this.provider.on("accountsChanged", replacer);
        this.provider.on("networkChanged", replacer);
        return stop[0];
    }
    async isConnected() {
        if ((await this.provider.getNetwork()) !== this.ckbNetwork) {
            return false;
        }
        return await this.provider.isConnected();
    }
    async signMessageRaw(message) {
        const challenge = typeof message === "string" ? message : core_1.ccc.hexFrom(message).slice(2);
        return this.provider.signMessage(challenge, this.accountCache ?? (await this.getAccount()));
    }
    async signOnlyTransaction(txLike) {
        const txSigned = await this.provider.signTransaction(txLike);
        return core_1.ccc.Transaction.from(txSigned);
    }
    async prepareTransaction(txLike) {
        const tx = core_1.ccc.Transaction.from(txLike);
        const { script } = await this.getAddressObj();
        await tx.addCellDepsOfKnownScripts(this.client, core_1.ccc.KnownScript.Secp256k1Blake160);
        await tx.prepareSighashAllWitness(script, 65, this.client);
        return tx;
    }
}
exports.SignerCkb = SignerCkb;
