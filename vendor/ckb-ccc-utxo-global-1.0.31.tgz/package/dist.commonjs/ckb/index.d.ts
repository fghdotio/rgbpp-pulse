import { ccc } from "@ckb-ccc/core";
import { Provider } from "../advancedBarrel.js";
/**
 * @public
 */
export declare class SignerCkb extends ccc.Signer {
    readonly provider: Provider;
    private accountCache;
    get type(): ccc.SignerType;
    /**
     * Gets the sign type.
     * @returns The sign type.
     */
    get signType(): ccc.SignerSignType;
    constructor(client: ccc.Client, provider: Provider);
    getInternalAddress(): Promise<string>;
    getIdentity(): Promise<string>;
    getAddressObj(): Promise<ccc.Address>;
    getAddressObjs(): Promise<ccc.Address[]>;
    getAccount(): Promise<string>;
    getPublicKey(): Promise<ccc.Hex>;
    get ckbNetwork(): string;
    connect(): Promise<void>;
    onReplaced(listener: () => void): () => void;
    isConnected(): Promise<boolean>;
    signMessageRaw(message: string | ccc.BytesLike): Promise<string>;
    signOnlyTransaction(txLike: ccc.TransactionLike): Promise<ccc.Transaction>;
    prepareTransaction(txLike: ccc.TransactionLike): Promise<ccc.Transaction>;
}
//# sourceMappingURL=index.d.ts.map