import { ccc } from "@ckb-ccc/core";
/**
 * Retrieves the UniSat signer if available.
 * @public
 *
 * @param client - The client instance.
 * @returns The Signer instance if the UniSat provider is available, otherwise undefined.
 */
export declare function getUniSatSigners(client: ccc.Client, preferredNetworks?: ccc.NetworkPreference[]): ccc.SignerInfo[];
//# sourceMappingURL=signersFactory.d.ts.map