export * as UniSatA from "./advancedBarrel.js";
//# sourceMappingURL=advanced.d.ts.map