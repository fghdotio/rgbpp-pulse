"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUniSatSigners = getUniSatSigners;
const signer_js_1 = require("./signer.js");
/**
 * Retrieves the UniSat signer if available.
 * @public
 *
 * @param client - The client instance.
 * @returns The Signer instance if the UniSat provider is available, otherwise undefined.
 */
function getUniSatSigners(client, preferredNetworks) {
    const windowRef = window;
    if (typeof windowRef.unisat === "undefined") {
        return [];
    }
    return [
        {
            signer: new signer_js_1.Signer(client, windowRef.unisat, preferredNetworks),
            name: "BTC",
        },
    ];
}
