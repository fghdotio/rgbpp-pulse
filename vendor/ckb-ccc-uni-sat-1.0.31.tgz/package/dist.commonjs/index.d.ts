export * as UniSat from "./barrel.js";
//# sourceMappingURL=index.d.ts.map