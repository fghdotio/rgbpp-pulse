import { ccc } from "@ckb-ccc/core";
import { Provider } from "./advancedBarrel.js";
/**
 * Class representing a Bitcoin signer that extends SignerBtc
 * @public
 */
export declare class Signer extends ccc.SignerBtc {
    readonly provider: Provider;
    private readonly preferredNetworks;
    /**
     * Creates an instance of Signer.
     * @param client - The client instance.
     * @param provider - The provider instance.
     */
    constructor(client: ccc.Client, provider: Provider, preferredNetworks?: ccc.NetworkPreference[]);
    _getNetworkToChange(): Promise<string | undefined>;
    /**
     * Ensure the BTC network is the same as CKB network.
     */
    ensureNetwork(): Promise<void>;
    /**
     * Gets the Bitcoin account address.
     * @returns A promise that resolves to the Bitcoin account address.
     */
    getBtcAccount(): Promise<string>;
    /**
     * Gets the Bitcoin public key.
     * @returns A promise that resolves to the Bitcoin public key.
     */
    getBtcPublicKey(): Promise<ccc.Hex>;
    /**
     * Connects to the provider by requesting accounts.
     * @returns A promise that resolves when the connection is established.
     */
    connect(): Promise<void>;
    onReplaced(listener: () => void): () => void;
    /**
     * Checks if the signer is connected.
     * @returns A promise that resolves to true if connected, false otherwise.
     */
    isConnected(): Promise<boolean>;
    /**
     * Signs a raw message with the Bitcoin account.
     * @param message - The message to sign.
     * @returns A promise that resolves to the signed message.
     */
    signMessageRaw(message: string | ccc.BytesLike): Promise<string>;
    /**
     * Signs a PSBT using UniSat wallet.
     *
     * @param psbtHex - The hex string of PSBT to sign.
     * @param options - Options for signing the PSBT
     * @returns A promise that resolves to the signed PSBT as a Hex string
     */
    signPsbt(psbtHex: ccc.HexLike, options?: ccc.SignPsbtOptionsLike): Promise<ccc.Hex>;
    /**
     * Broadcasts a signed PSBT to the Bitcoin network.
     *
     * @param psbtHex - The hex string of signed PSBT to broadcast.
     * @returns A promise that resolves to the transaction ID as a Hex string
     */
    broadcastPsbt(psbtHex: ccc.HexLike, _options?: ccc.SignPsbtOptionsLike): Promise<ccc.Hex>;
}
//# sourceMappingURL=signer.d.ts.map