"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Signer = void 0;
const core_1 = require("@ckb-ccc/core");
/**
 * Class representing a Bitcoin signer that extends SignerBtc
 * @public
 */
class Signer extends core_1.ccc.SignerBtc {
    /**
     * Creates an instance of Signer.
     * @param client - The client instance.
     * @param provider - The provider instance.
     */
    constructor(client, provider, preferredNetworks = [
        {
            addressPrefix: "ckb",
            signerType: core_1.ccc.SignerType.BTC,
            network: "btc",
        },
        {
            addressPrefix: "ckt",
            signerType: core_1.ccc.SignerType.BTC,
            network: "btcTestnet",
        },
    ]) {
        super(client);
        this.provider = provider;
        this.preferredNetworks = preferredNetworks;
    }
    async _getNetworkToChange() {
        const currentNetwork = await (async () => {
            if (this.provider.getChain) {
                return ({
                    BITCOIN_MAINNET: "btc",
                    BITCOIN_TESTNET: "btcTestnet",
                    FRACTAL_BITCOIN_MAINNET: "fractalBtc",
                }[(await this.provider.getChain()).enum] ?? "");
            }
            return (await this.provider.getNetwork()) === "livenet"
                ? "btc"
                : "btcTestnet";
        })();
        const { network } = this.matchNetworkPreference(this.preferredNetworks, currentNetwork) ?? { network: currentNetwork };
        if (network === currentNetwork) {
            return;
        }
        return network;
    }
    /**
     * Ensure the BTC network is the same as CKB network.
     */
    async ensureNetwork() {
        const network = await this._getNetworkToChange();
        if (!network) {
            return;
        }
        if (this.provider.switchChain) {
            const chain = {
                btc: "BITCOIN_MAINNET",
                btcTestnet: "BITCOIN_TESTNET",
                fractalBtc: "FRACTAL_BITCOIN_MAINNET",
            }[network];
            if (chain) {
                await this.provider.switchChain(chain);
                return;
            }
        }
        else if (network === "btc" || network === "btcTestnet") {
            await this.provider.switchNetwork(network === "btc" ? "livenet" : "testnet");
            return;
        }
        throw new Error(`UniSat wallet doesn't support the requested chain ${network}`);
    }
    /**
     * Gets the Bitcoin account address.
     * @returns A promise that resolves to the Bitcoin account address.
     */
    async getBtcAccount() {
        return (await this.provider.getAccounts())[0];
    }
    /**
     * Gets the Bitcoin public key.
     * @returns A promise that resolves to the Bitcoin public key.
     */
    async getBtcPublicKey() {
        return core_1.ccc.hexFrom(await this.provider.getPublicKey());
    }
    /**
     * Connects to the provider by requesting accounts.
     * @returns A promise that resolves when the connection is established.
     */
    async connect() {
        await this.provider.requestAccounts();
        await this.ensureNetwork();
    }
    onReplaced(listener) {
        const stop = [];
        const replacer = async () => {
            listener();
            stop[0]?.();
        };
        stop.push(() => {
            this.provider.removeListener("accountsChanged", replacer);
            this.provider.removeListener("networkChanged", replacer);
        });
        this.provider.on("accountsChanged", replacer);
        this.provider.on("networkChanged", replacer);
        return stop[0];
    }
    /**
     * Checks if the signer is connected.
     * @returns A promise that resolves to true if connected, false otherwise.
     */
    async isConnected() {
        if (await this._getNetworkToChange()) {
            return false;
        }
        return (await this.provider.getAccounts()).length !== 0;
    }
    /**
     * Signs a raw message with the Bitcoin account.
     * @param message - The message to sign.
     * @returns A promise that resolves to the signed message.
     */
    async signMessageRaw(message) {
        const challenge = typeof message === "string" ? message : core_1.ccc.hexFrom(message).slice(2);
        return this.provider.signMessage(challenge, "ecdsa");
    }
    /**
     * Signs a PSBT using UniSat wallet.
     *
     * @param psbtHex - The hex string of PSBT to sign.
     * @param options - Options for signing the PSBT
     * @returns A promise that resolves to the signed PSBT as a Hex string
     */
    async signPsbt(psbtHex, options) {
        return core_1.ccc.hexFrom(await this.provider.signPsbt(core_1.ccc.hexFrom(psbtHex).slice(2), options));
    }
    /**
     * Broadcasts a signed PSBT to the Bitcoin network.
     *
     * @param psbtHex - The hex string of signed PSBT to broadcast.
     * @returns A promise that resolves to the transaction ID as a Hex string
     */
    async broadcastPsbt(psbtHex, _options) {
        const txid = await this.provider.pushPsbt(core_1.ccc.hexFrom(psbtHex).slice(2));
        return core_1.ccc.hexFrom(txid);
    }
}
exports.Signer = Signer;
