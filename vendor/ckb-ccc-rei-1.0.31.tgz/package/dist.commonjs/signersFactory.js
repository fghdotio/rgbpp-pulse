"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getReiSigners = getReiSigners;
const signer_js_1 = require("./signer.js");
/**
 * Retrieves the Rei signer if available.
 * @param {ccc.Client} client - The client instance.
 * @returns {Signer | undefined} The Signer instance if the Rei provider is available, otherwise undefined.

 */
function getReiSigners(client) {
    const windowRef = window;
    if (typeof windowRef?.rei?.ckb === "undefined") {
        return [];
    }
    return [
        {
            signer: new signer_js_1.ReiSigner(client, windowRef.rei.ckb),
            name: "CKB",
        },
    ];
}
