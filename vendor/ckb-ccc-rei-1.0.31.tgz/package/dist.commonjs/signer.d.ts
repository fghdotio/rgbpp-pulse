import { ccc } from "@ckb-ccc/core";
import { Provider } from "./advancedBarrel.js";
/**
 * Class representing a CKB signer that extends Signer from @ckb-ccc/core.
 * @public
 */
export declare class ReiSigner extends ccc.Signer {
    readonly provider: Provider;
    /**
     * Creates an instance of Signer.
     * @param client - The client instance.
     * @param provider - The provider instance.
     */
    constructor(client: ccc.Client, provider: Provider);
    /**
     * Register a listener to be called when this signer is replaced.
     *
     * @returns A function for unregister
     */
    onReplaced(listener: () => void): () => void;
    /**
     * Gets the signer type.
     * @returns The type of the signer.
     */
    get type(): ccc.SignerType;
    /**
     * Gets the sign type.
     * @returns The sign type.
     */
    get signType(): ccc.SignerSignType;
    /**
     * Connects to the provider by requesting authentication.
     * @returns A promise that resolves when the connection is established.
     */
    connect(): Promise<void>;
    /**
     * Checks if the signer is connected.
     * @returns A promise that resolves to true if connected, false otherwise.
     */
    isConnected(): Promise<boolean>;
    _getNetworkChanged(): Promise<boolean>;
    /**
     * Gets the internal address.
     * @returns A promise that resolves to the internal address.
     */
    getInternalAddress(): Promise<string>;
    /**
     * Gets the address object.
     * @returns A promise that resolves to the address object.
     */
    getAddressObj(): Promise<ccc.Address>;
    /**
     * Gets the address objects.
     * @returns A promise that resolves to an array of address objects.
     */
    getAddressObjs(): Promise<ccc.Address[]>;
    /**
     * Gets the identity of the signer.
     * @returns A promise that resolves to the identity.
     */
    getIdentity(): Promise<string>;
    /**
     * Signs a raw message with the personal account.
     * @param message - The message to sign.
     * @returns A promise that resolves to the signed message.
     */
    signMessageRaw(message: string): Promise<ccc.Hex>;
    /**
     * prepare a transaction before signing.
     *
     * @param txLike - The transaction to prepare, represented as a TransactionLike object.
     * @returns A promise that resolves to the prepared Transaction object.
     */
    prepareTransaction(txLike: ccc.TransactionLike): Promise<ccc.Transaction>;
    /**
     * Signs a transaction without preparing information for it.
     *
     * @param txLike - The transaction to sign, represented as a TransactionLike object.
     * @returns A promise that resolves to the signed Transaction object.
     */
    signOnlyTransaction(txLike: ccc.TransactionLike): Promise<ccc.Transaction>;
}
//# sourceMappingURL=signer.d.ts.map