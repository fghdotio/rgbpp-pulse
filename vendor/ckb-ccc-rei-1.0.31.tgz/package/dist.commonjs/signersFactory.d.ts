import { ccc } from "@ckb-ccc/core";
/**
 * Retrieves the Rei signer if available.
 * @param {ccc.Client} client - The client instance.
 * @returns {Signer | undefined} The Signer instance if the Rei provider is available, otherwise undefined.

 */
export declare function getReiSigners(client: ccc.Client): ccc.SignerInfo[];
//# sourceMappingURL=signersFactory.d.ts.map