export * as ReiA from "./advancedBarrel.js";
//# sourceMappingURL=advanced.d.ts.map