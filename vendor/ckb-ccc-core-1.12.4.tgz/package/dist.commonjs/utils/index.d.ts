import { NumLike, type Num } from "../num/index.js";
/**
 * A type safe way to apply a transformer on a value if it's not empty.
 * @public
 *
 * @param transformer - The transformer.
 * @param value - The value to be transformed.
 * @returns If the value is empty, it becomes undefined. Otherwise it will be transformed.
 */
export declare function apply<T, R>(transformer: (val: T) => R, value: undefined): undefined;
/**
 * A type safe way to apply a transformer on a value if it's not empty.
 * @public
 *
 * @param transformer - The transformer.
 * @param value - The value to be transformed.
 * @returns If the value is empty, it becomes undefined. Otherwise it will be transformed.
 */
export declare function apply<T, R>(transformer: (val: T) => R, value: null): undefined;
/**
 * A type safe way to apply a transformer on a value if it's not empty.
 * @public
 *
 * @param transformer - The transformer.
 * @param value - The value to be transformed.
 * @returns If the value is empty, it becomes undefined. Otherwise it will be transformed.
 */
export declare function apply<T, R>(transformer: (val: T) => R, value: T): R;
/**
 * A type safe way to apply a transformer on a value if it's not empty.
 * @public
 *
 * @param transformer - The transformer.
 * @param value - The value to be transformed.
 * @returns If the value is empty, it becomes undefined. Otherwise it will be transformed.
 */
export declare function apply<T, R>(transformer: (val: T) => R, value: T | undefined): R | undefined;
/**
 * A type safe way to apply a transformer on a value if it's not empty.
 * @public
 *
 * @param transformer - The transformer.
 * @param value - The value to be transformed.
 * @returns If the value is empty, it becomes undefined. Otherwise it will be transformed.
 */
export declare function apply<T, R>(transformer: (val: T) => R, value: T | null): R | undefined;
/**
 * A type safe way to apply a transformer on a value if it's not empty.
 * @public
 *
 * @param transformer - The transformer.
 * @param value - The value to be transformed.
 * @returns If the value is empty, it becomes undefined. Otherwise it will be transformed.
 */
export declare function apply<T, R>(transformer: (val: T) => R, value: undefined | null): undefined;
/**
/**
 * A type safe way to apply a transformer on a value if it's not empty.
 * @public
 *
 * @param transformer - The transformer.
 * @param value - The value to be transformed.
 * @returns If the value is empty, it becomes undefined. Otherwise it will be transformed.
 */
export declare function apply<T, R>(transformer: (val: T) => R, value: T | undefined | null): R | undefined;
/**
 * Similar to Array.reduce, but works on any iterable.
 * @public
 *
 * @param values - The iterable to be reduced.
 * @param accumulator - A callback to be called for each value. If it returns null or undefined, the previous result will be kept.
 * @returns The accumulated result.
 */
export declare function reduce<T>(values: Iterable<T>, accumulator: (a: T, b: T, i: number) => T | undefined | null | void): T;
/**
 * Similar to Array.reduce, but works on any iterable.
 * @public
 *
 * @param values - The iterable to be reduced.
 * @param accumulator - A callback to be called for each value. If it returns null or undefined, the previous result will be kept.
 * @param init - The initial value.
 * @returns The accumulated result.
 */
export declare function reduce<T, V>(values: Iterable<V>, accumulator: (a: T, b: V, i: number) => T | undefined | null | void, init: T): T;
/**
 * Similar to Array.reduce, but works on async iterables and the accumulator can return a Promise.
 * @public
 *
 * @param values - The iterable or async iterable to be reduced.
 * @param accumulator - A callback to be called for each value. If it returns null or undefined, the previous result will be kept.
 * @returns The accumulated result.
 */
export declare function reduceAsync<T>(values: Iterable<T> | AsyncIterable<T>, accumulator: (a: T, b: T, i: number) => Promise<T | undefined | null | void> | T | undefined | null | void): Promise<T>;
/**
 * Similar to Array.reduce, but works on async iterables and the accumulator can return a Promise.
 * @public
 *
 * @param values - The iterable or async iterable to be reduced.
 * @param accumulator - A callback to be called for each value. If it returns null or undefined, the previous result will be kept.
 * @param init - The initial value.
 * @returns The accumulated result.
 */
export declare function reduceAsync<T, V>(values: Iterable<V> | AsyncIterable<V>, accumulator: (a: T, b: V, i: number) => Promise<T | undefined | null | void> | T | undefined | null | void, init: T | Promise<T>): Promise<T>;
export declare function sleep(ms: NumLike): Promise<unknown>;
export type Constructor<T> = {
    new (...args: any[]): T;
};
/**
 * @public
 */
export declare function isWebview(userAgent: string): boolean;
/**
 * @public
 */
export declare function stringify(val: unknown): string;
/**
 * Calculate the greatest common divisor (GCD) of two NumLike values using the Euclidean algorithm.
 *
 * @param a - First operand.
 * @param b - Second operand.
 * @returns GCD(a, b) as a Num.
 */
export declare function gcd(a: NumLike, b: NumLike): Num;
//# sourceMappingURL=index.d.ts.map