"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.apply = apply;
exports.reduce = reduce;
exports.reduceAsync = reduceAsync;
exports.sleep = sleep;
exports.isWebview = isWebview;
exports.stringify = stringify;
exports.gcd = gcd;
const index_js_1 = require("../fixedPoint/index.js");
const index_js_2 = require("../num/index.js");
/**
 * A type safe way to apply a transformer on a value if it's not empty.
 * @public
 *
 * @param transformer - The transformer.
 * @param value - The value to be transformed.
 * @returns If the value is empty, it becomes undefined. Otherwise it will be transformed.
 */
function apply(transformer, value) {
    if (value == null) {
        return undefined;
    }
    return transformer(value);
}
/**
 * Similar to Array.reduce, but works on any iterable.
 * @public
 *
 * @param values - The iterable to be reduced.
 * @param accumulator - A callback to be called for each value. If it returns null or undefined, the previous result will be kept.
 * @param init - The initial value.
 * @returns The accumulated result.
 */
function reduce(values, accumulator, init) {
    const hasInit = arguments.length > 2;
    let acc = init; // The compiler thinks `acc` isn't assigned without this. Since `T` might be nullable, we should not use non-null assertion here.
    let i = 0;
    for (const value of values) {
        if (!hasInit && i === 0) {
            acc = value;
            i++;
            continue;
        }
        acc = accumulator(acc, value, i) ?? acc;
        i++;
    }
    if (!hasInit && i === 0) {
        throw new TypeError("Reduce of empty iterator with no initial value");
    }
    return acc;
}
/**
 * Similar to Array.reduce, but works on async iterables and the accumulator can return a Promise.
 * @public
 *
 * @param values - The iterable or async iterable to be reduced.
 * @param accumulator - A callback to be called for each value. If it returns null or undefined, the previous result will be kept.
 * @param init - The initial value.
 * @returns The accumulated result.
 */
async function reduceAsync(values, accumulator, init) {
    const hasInit = arguments.length > 2;
    let acc = (await Promise.resolve(init)); // The compiler thinks `acc` isn't assigned without this. Since `T` might be nullable, we should not use non-null assertion here.
    let i = 0;
    for await (const value of values) {
        if (!hasInit && i === 0) {
            acc = value;
            i++;
            continue;
        }
        acc = (await accumulator(acc, value, i)) ?? acc;
        i++;
    }
    if (!hasInit && i === 0) {
        throw new TypeError("Reduce of empty iterator with no initial value");
    }
    return acc;
}
function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, Number((0, index_js_2.numFrom)(ms))));
}
/**
 * @public
 */
function isWebview(userAgent) {
    return /webview|wv|ip((?!.*Safari)|(?=.*like Safari))/i.test(userAgent);
}
/**
 * @public
 */
function stringify(val) {
    return JSON.stringify(val, (_, value) => {
        if (typeof value === "bigint") {
            return (0, index_js_2.numToHex)(value);
        }
        // eslint-disable-next-line @typescript-eslint/no-unsafe-return
        return value;
    });
}
/**
 * Calculate the greatest common divisor (GCD) of two NumLike values using the Euclidean algorithm.
 *
 * @param a - First operand.
 * @param b - Second operand.
 * @returns GCD(a, b) as a Num.
 */
function gcd(a, b) {
    a = (0, index_js_2.numFrom)(a);
    b = (0, index_js_2.numFrom)(b);
    a = a < index_js_1.Zero ? -a : a;
    b = b < index_js_1.Zero ? -b : b;
    while (b !== index_js_1.Zero) {
        [a, b] = [b, a % b];
    }
    return a;
}
