import { JsonRpcPayload, Transport } from "./transports/advanced.js";
export type RequestorJsonRpcConfig = {
    fallbacks?: string[];
    timeout?: number;
    maxConcurrent?: number;
    transport?: Transport;
};
export declare class RequestorJsonRpc {
    private readonly url_;
    private readonly onError?;
    readonly maxConcurrent?: number;
    private concurrent;
    private readonly pending;
    readonly transport: Transport;
    private id;
    /**
     * Creates an instance of ClientJsonRpc.
     *
     * @param url_ - The URL of the JSON-RPC server.
     * @param timeout - The timeout for requests in milliseconds
     */
    constructor(url_: string, config?: RequestorJsonRpcConfig, onError?: ((err: unknown) => Promise<void> | void) | undefined);
    /**
     * Returns the URL of the JSON-RPC server.
     *
     * @returns The URL of the JSON-RPC server.
     */
    get url(): string;
    /**
     * request a JSON-RPC method.
     *
     * @param rpcMethod - The JSON-RPC method.
     * @param params - Params for the method.
     * @param inTransformers - An array of input transformers.
     * @param outTransformer - An output transformer function.
     * @returns Method response.
     */
    request(rpcMethod: string, params: unknown[], inTransformers?: (((_: any) => unknown) | undefined)[], outTransformer?: (_: any) => unknown): Promise<unknown>;
    requestPayload(payload: JsonRpcPayload): Promise<unknown>;
    /**
     * Builds a JSON-RPC payload for the given method and parameters.
     *
     * @param method - The JSON-RPC method name.
     * @param req - The parameters for the JSON-RPC method.
     * @returns The JSON-RPC payload.
     */
    buildPayload(method: string, req: unknown[]): JsonRpcPayload;
}
//# sourceMappingURL=requestor.d.ts.map