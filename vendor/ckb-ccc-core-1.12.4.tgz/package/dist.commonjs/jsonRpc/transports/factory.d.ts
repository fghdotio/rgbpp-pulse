import { TransportHttp } from "./http.js";
import { TransportWebSocket } from "./webSocket.js";
export declare function transportFromUri(uri: string, config?: {
    timeout?: number;
}): TransportHttp | TransportWebSocket;
//# sourceMappingURL=factory.d.ts.map