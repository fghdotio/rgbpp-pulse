import { Codec, CodecLike, DecodedType, EncodableType } from "../codec/index.js";
export { 
/**
 * @deprecated Use ccc.Codec instead
 */
Codec, 
/**
 * @deprecated Use ccc.CodecLike instead
 */
CodecLike, 
/**
 * @deprecated Use ccc.DecodedType instead
 */
DecodedType, 
/**
 * @deprecated Use ccc.EncodableType instead
 */
EncodableType, 
/**
 * @deprecated Use ccc.codecUint instead
 */
codecUint as uint, 
/**
 * @deprecated Use ccc.codecUintNumber instead
 */
codecUintNumber as uintNumber, } from "../codec/index.js";
/**
 * Vector with fixed size item codec
 * @param itemCodec fixed-size vector item codec
 */
export declare function fixedItemVec<Encodable, Decoded>(itemCodec: CodecLike<Encodable, Decoded>): Codec<Array<Encodable>, Array<Decoded>>;
/**
 * Vector with dynamic size item codec, you can create a recursive vector with this function
 * @param itemCodec the vector item codec. It can be fixed-size or dynamic-size.
 */
export declare function dynItemVec<Encodable, Decoded>(itemCodec: CodecLike<Encodable, Decoded>): Codec<Array<Encodable>, Array<Decoded>>;
/**
 * General vector codec, if `itemCodec` is fixed size type, it will create a fixvec codec, otherwise a dynvec codec will be created.
 * @param itemCodec
 */
export declare function vector<Encodable, Decoded>(itemCodec: CodecLike<Encodable, Decoded>): Codec<Array<Encodable>, Array<Decoded>>;
/**
 * Option is a dynamic-size type.
 * Serializing an option depends on whether it is empty or not:
 * - if it's empty, there is zero bytes (the size is 0).
 * - if it's not empty, just serialize the inner item (the size is same as the inner item's size).
 * @param innerCodec
 */
export declare function option<Encodable, Decoded>(innerCodec: CodecLike<Encodable, Decoded>): Codec<Encodable | undefined | null, Decoded | undefined>;
/**
 * Wrap the encoded value with a fixed-length buffer
 * @param codec
 */
export declare function byteVec<Encodable, Decoded>(codec: CodecLike<Encodable, Decoded>): Codec<Encodable, Decoded>;
export type EncodableRecordOptionalKeys<T extends Record<string, CodecLike<any, any>>> = {
    [K in keyof T]: Extract<EncodableType<T[K]>, undefined> extends never ? never : K;
}[keyof T];
export type EncodableRecord<T extends Record<string, CodecLike<any, any>>> = {
    [key in keyof Pick<T, EncodableRecordOptionalKeys<T>>]+?: EncodableType<T[key]>;
} & {
    [key in keyof Omit<T, EncodableRecordOptionalKeys<T>>]: EncodableType<T[key]>;
};
export type DecodedRecordOptionalKeys<T extends Record<string, CodecLike<any, any>>> = {
    [K in keyof T]: Extract<DecodedType<T[K]>, undefined> extends never ? never : K;
}[keyof T];
export type DecodedRecord<T extends Record<string, CodecLike<any, any>>> = {
    [key in keyof Pick<T, DecodedRecordOptionalKeys<T>>]+?: DecodedType<T[key]>;
} & {
    [key in keyof Omit<T, DecodedRecordOptionalKeys<T>>]: DecodedType<T[key]>;
};
/**
 * Table is a dynamic-size type. It can be considered as a dynvec but the length is fixed.
 * @param codecLayout
 */
export declare function table<T extends Record<string, CodecLike<any, any>>, Encodable extends EncodableRecord<T>, Decoded extends DecodedRecord<T>>(codecLayout: T): Codec<Encodable, Decoded>;
type UnionEncodable<T extends Record<string, CodecLike<any, any>>, K extends keyof T = keyof T> = K extends unknown ? {
    type: K;
    value: EncodableType<T[K]>;
} : never;
type UnionDecoded<T extends Record<string, CodecLike<any, any>>, K extends keyof T = keyof T> = K extends unknown ? {
    type: K;
    value: DecodedType<T[K]>;
} : never;
/**
 * Constructs a union codec that can serialize and deserialize values tagged with a type identifier.
 *
 * If all variants have the same fixed size, the resulting union codec is fixed-size (header + payload).
 * Otherwise, it falls back to a dynamic-size codec.
 *
 * Serialization format:
 * 1. 4-byte little-endian unsigned integer for the variant index.
 * 2. Encoded bytes of the selected variant.
 *
 * @typeParam T
 *   A record mapping variant names to codecs.
 * @param codecLayout
 *   An object whose keys are variant names and values are codecs for each variant.
 * @param fields
 *   Optional mapping from variant names to custom numeric IDs. If omitted, the index
 *   of each variant in `codecLayout` is used as its ID.
 *
 *
 * @example
 * // Dynamic union without custom numeric IDs
 * union({ cafe: Uint8, bee: Uint16 })
 *
 * // Dynamic union with custom numeric IDs
 * union({ cafe: Uint8, bee: Uint16 }, { cafe: 0xcafe, bee: 0xbee })
 *
 * // Fixed-size union without custom numeric IDs
 * const PaddedUint8 = struct({ data : u8, padding : u8 })
 * union({ cafe: PaddedUint8, bee: Uint16 });
 *
 * // Fixed-size union with custom numeric IDs
 * union({ cafe: PaddedUint8, bee: Uint16 }, { cafe: 0xcafe, bee: 0xbee })
 */
export declare function union<T extends Record<string, CodecLike<any, any>>>(codecLayout: T, fields?: Record<keyof T, number | undefined | null>): Codec<UnionEncodable<T>, UnionDecoded<T>>;
/**
 * Struct is a fixed-size type: all fields in struct are fixed-size and it has a fixed quantity of fields.
 * The size of a struct is the sum of all fields' size.
 * @param codecLayout a object contains all fields' codec
 */
export declare function struct<T extends Record<string, CodecLike<any, any>>, Encodable extends EncodableRecord<T>, Decoded extends DecodedRecord<T>>(codecLayout: T): Codec<Encodable, Decoded>;
/**
 * The array is a fixed-size type: it has a fixed-size inner type and a fixed length.
 * The size of an array is the size of inner type times the length.
 * @param itemCodec the fixed-size array item codec
 * @param itemCount
 */
export declare function array<Encodable, Decoded>(itemCodec: CodecLike<Encodable, Decoded>, itemCount: number): Codec<Array<Encodable>, Array<Decoded>>;
//# sourceMappingURL=codec.d.ts.map