import { ScriptInfoLike } from "./clientTypes.js";
import { KnownScript } from "./knownScript.js";
export declare const TESTNET_SCRIPTS: Record<KnownScript, ScriptInfoLike>;
//# sourceMappingURL=clientPublicTestnet.advanced.d.ts.map