import { ScriptInfoLike } from "./clientTypes.js";
import { KnownScript } from "./knownScript.js";
export declare const MAINNET_SCRIPTS: Record<KnownScript, ScriptInfoLike | undefined>;
//# sourceMappingURL=clientPublicMainnet.advanced.d.ts.map