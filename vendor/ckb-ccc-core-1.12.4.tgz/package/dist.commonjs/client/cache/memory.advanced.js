"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MapLru = exports.DEFAULT_CONFIRMED_BLOCK_TIME = void 0;
exports.filterData = filterData;
exports.filterScript = filterScript;
exports.filterNumByRange = filterNumByRange;
exports.filterScriptByLenRange = filterScriptByLenRange;
exports.filterCell = filterCell;
const index_js_1 = require("../../bytes/index.js");
const index_js_2 = require("../../ckb/index.js");
const index_js_3 = require("../../hex/index.js");
const index_js_4 = require("../../num/index.js");
const clientTypes_advanced_js_1 = require("../clientTypes.advanced.js");
const clientTypes_js_1 = require("../clientTypes.js");
exports.DEFAULT_CONFIRMED_BLOCK_TIME = (0, index_js_4.numFrom)(1000 * 10 * 50); // 50 blocks * 10s
function filterData(dataLike, filterLike, filterMode) {
    if (!filterLike) {
        return true;
    }
    const data = (0, index_js_3.hexFrom)(dataLike);
    const filter = (0, index_js_3.hexFrom)(filterLike);
    if ((filterMode === "exact" && data !== filter) ||
        (filterMode === "prefix" && !data.startsWith(filter)) ||
        (filterMode === "partial" && data.search(filter) === -1)) {
        return false;
    }
    return true;
}
function filterScript(valueLike, filterLike, filterMode) {
    if (!filterLike) {
        return true;
    }
    if (!valueLike) {
        return false;
    }
    const value = index_js_2.Script.from(valueLike);
    const filter = index_js_2.Script.from(filterLike);
    if (value.codeHash !== filter.codeHash ||
        value.hashType !== filter.hashType) {
        return false;
    }
    return filterData(value.args, filter?.args, filterMode);
}
function filterNumByRange(lengthLike, range) {
    if (!range) {
        return true;
    }
    const length = (0, index_js_4.numFrom)(lengthLike);
    const [lower, upper] = (0, clientTypes_advanced_js_1.clientSearchKeyRangeFrom)(range);
    return lower <= length && length < upper;
}
function filterScriptByLenRange(valueLike, scriptLenRange) {
    if (!scriptLenRange) {
        return true;
    }
    const len = (() => {
        if (!valueLike) {
            return 0;
        }
        return (0, index_js_1.bytesFrom)(index_js_2.Script.from(valueLike).args).length + 33;
    })();
    return filterNumByRange(len, scriptLenRange);
}
function filterCell(searchKeyLike, cellLike) {
    const key = clientTypes_js_1.ClientIndexerSearchKey.from(searchKeyLike);
    const cell = index_js_2.Cell.from(cellLike);
    if (key.scriptType === "lock") {
        if (!filterScript(cell.cellOutput.lock, key.script, key.scriptSearchMode) ||
            !filterScript(cell.cellOutput.type, key.filter?.script, "prefix") ||
            !filterScriptByLenRange(cell.cellOutput.type, key.filter?.scriptLenRange)) {
            return false;
        }
    }
    if (key.scriptType === "type") {
        if (!filterScript(cell.cellOutput.type, key.script, key.scriptSearchMode) ||
            !filterScript(cell.cellOutput.lock, key.filter?.script, "prefix") ||
            !filterScriptByLenRange(cell.cellOutput.lock, key.filter?.scriptLenRange)) {
            return false;
        }
    }
    if (!filterData(cell.outputData, key.filter?.outputData, key.filter?.outputDataSearchMode ?? "prefix") ||
        !filterNumByRange((0, index_js_1.bytesFrom)(cell.outputData).length, key.filter?.outputDataLenRange)) {
        return false;
    }
    if (!filterNumByRange(cell.cellOutput.capacity, key.filter?.outputCapacityRange)) {
        return false;
    }
    return true;
}
/**
 * A Map-like class that implements a "Least Recently Used" (LRU) cache policy.
 * When the cache reaches its capacity, the least recently used item is removed.
 * @public
 */
class MapLru extends Map {
    /**
     * @param capacity - The maximum number of items to store in the cache. Must be a positive integer.
     */
    constructor(capacity) {
        super();
        this.capacity = capacity;
        this.lru = new Set();
        if (!Number.isInteger(capacity) || capacity < 1) {
            throw new Error("Capacity must be a positive integer");
        }
    }
    /**
     * Retrieves the value for a given key and marks it as recently used.
     * @param key - The key of the element to retrieve.
     * @returns The value associated with the key, or `undefined` if the key is not in the cache.
     */
    get(key) {
        if (!super.has(key)) {
            return;
        }
        this.lru.delete(key);
        this.lru.add(key);
        return super.get(key);
    }
    /**
     * Adds or updates a key-value pair in the cache and marks the key as recently used.
     * If setting a new key causes the cache to exceed its capacity, the least recently used item is evicted.
     * @param key - The key of the element to add or update.
     * @param value - The value of the element to add or update.
     * @returns The `MapLru` instance.
     */
    set(key, value) {
        super.set(key, value);
        this.lru.delete(key);
        this.lru.add(key);
        // Evict the oldest entry if capacity is exceeded.
        if (this.lru.size > this.capacity) {
            const oldestKey = this.lru.keys().next().value;
            this.delete(oldestKey);
        }
        return this;
    }
    /**
     * Removes the specified element from the cache.
     * @param key - The key of the element to remove.
     * @returns `true` if an element in the `MapLru` object existed and has been removed, or `false` if the element does not exist.
     */
    delete(key) {
        if (!super.delete(key)) {
            return false;
        }
        this.lru.delete(key);
        return true;
    }
    /**
     * Removes all key-value pairs from the cache.
     */
    clear() {
        super.clear();
        this.lru.clear();
    }
}
exports.MapLru = MapLru;
