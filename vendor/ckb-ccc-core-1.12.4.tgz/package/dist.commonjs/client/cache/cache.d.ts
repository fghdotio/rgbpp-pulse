import { Cell, CellLike, OutPointLike, Transaction, TransactionLike } from "../../ckb/index.js";
import { HexLike } from "../../hex/index.js";
import { NumLike } from "../../num/index.js";
import { ClientCollectableSearchKeyLike } from "../clientTypes.advanced.js";
import { ClientBlock, ClientBlockHeader, ClientBlockHeaderLike, ClientBlockLike, ClientTransactionResponse, ClientTransactionResponseLike } from "../clientTypes.js";
/**
 * @public
 * The ClientCache class is mainly designed for chained transactions.
 * Consumed & Created cells are "marked" so they can be correctly handled when composing transactions.
 * It also act as cache for rpc requests to reduce cost, but this is optional.
 */
export declare abstract class ClientCache {
    abstract markUsableNoCache(...cellLikes: (CellLike | CellLike[])[]): Promise<void>;
    markUsable(...cellLikes: (CellLike | CellLike[])[]): Promise<void>;
    abstract markUnusable(...outPointLike: (OutPointLike | OutPointLike[])[]): Promise<void>;
    markTransactions(...transactionLike: (TransactionLike | TransactionLike[])[]): Promise<void>;
    abstract clear(): Promise<void>;
    abstract findCells(filter: ClientCollectableSearchKeyLike): AsyncGenerator<Cell>;
    abstract isUnusable(outPointLike: OutPointLike): Promise<boolean>;
    /**
     * Record known cells
     * Implement this method to enable cells query caching
     * @param _cells
     */
    recordCells(..._cells: (CellLike | CellLike[])[]): Promise<void>;
    /**
     * Get a known cell by out point
     * Implement this method to enable cells query caching
     * @param _outPoint
     */
    getCell(_outPoint: OutPointLike): Promise<Cell | undefined>;
    /**
     * Record known transaction responses.
     * Implement this method to enable transactions query caching
     * @param _transactions
     */
    recordTransactionResponses(..._transactions: (ClientTransactionResponseLike | ClientTransactionResponseLike[])[]): Promise<void>;
    /**
     * Get a known transaction response by hash
     * Implement this method to enable transactions query caching
     * @param _txHash
     */
    getTransactionResponse(_txHash: HexLike): Promise<ClientTransactionResponse | undefined>;
    /**
     * Record known transactions.
     * @param transactions
     */
    recordTransactions(...transactions: (TransactionLike | TransactionLike[])[]): Promise<void>;
    /**
     * Get a known transaction by hash
     * @param txHash
     */
    getTransaction(txHash: HexLike): Promise<Transaction | undefined>;
    /**
     * Record known block headers.
     * Implement this method to enable block headers query caching
     * @param _headers
     */
    recordHeaders(..._headers: (ClientBlockHeaderLike | ClientBlockHeaderLike[])[]): Promise<void>;
    /**
     * Get a known block header by hash
     * Implement this method to enable block headers query caching
     * @param _hash
     */
    getHeaderByHash(_hash: HexLike): Promise<ClientBlockHeader | undefined>;
    /**
     * Get a known block header by number
     * Implement this method to enable block headers query caching
     * @param _number
     */
    getHeaderByNumber(_number: NumLike): Promise<ClientBlockHeader | undefined>;
    /**
     * Record known blocks.
     * Implement this method to enable blocks query caching
     * @param _blocks
     */
    recordBlocks(..._blocks: (ClientBlockLike | ClientBlockLike[])[]): Promise<void>;
    /**
     * Get a known block header by hash
     * Implement this method to enable block headers query caching
     * @param _hash
     */
    getBlockByHash(_hash: HexLike): Promise<ClientBlock | undefined>;
    /**
     * Get a known block header by number
     * Implement this method to enable block headers query caching
     * @param _number
     */
    getBlockByNumber(_number: NumLike): Promise<ClientBlock | undefined>;
    /**
     * Checks if a block header is considered confirmed.
     * The default implementation compares the header's timestamp against the current time
     * and a configured confirmation time. Override this method for custom confirmation logic.
     * @param header
     */
    hasHeaderConfirmed(header: ClientBlockHeader): boolean;
}
//# sourceMappingURL=cache.d.ts.map