import { Cell, CellLike, ScriptLike } from "../../ckb/index.js";
import { HexLike } from "../../hex/index.js";
import { NumLike } from "../../num/index.js";
import { ClientCollectableSearchKeyLike } from "../clientTypes.advanced.js";
export declare const DEFAULT_CONFIRMED_BLOCK_TIME: bigint;
export type CellRecord = [
    false,
    Pick<Cell, "outPoint"> & Partial<Pick<Cell, "cellOutput" | "outputData">>
] | [true, Cell] | [undefined, Cell];
export declare function filterData(dataLike: HexLike, filterLike: HexLike | undefined, filterMode: "exact" | "prefix" | "partial"): boolean;
export declare function filterScript(valueLike: ScriptLike | undefined, filterLike: ScriptLike | undefined, filterMode: "prefix" | "exact" | "partial"): boolean;
export declare function filterNumByRange(lengthLike: NumLike, range: [NumLike, NumLike] | undefined): boolean;
export declare function filterScriptByLenRange(valueLike?: ScriptLike, scriptLenRange?: [NumLike, NumLike]): boolean;
export declare function filterCell(searchKeyLike: ClientCollectableSearchKeyLike, cellLike: CellLike): boolean;
/**
 * A Map-like class that implements a "Least Recently Used" (LRU) cache policy.
 * When the cache reaches its capacity, the least recently used item is removed.
 * @public
 */
export declare class MapLru<K, V> extends Map<K, V> {
    private readonly capacity;
    private readonly lru;
    /**
     * @param capacity - The maximum number of items to store in the cache. Must be a positive integer.
     */
    constructor(capacity: number);
    /**
     * Retrieves the value for a given key and marks it as recently used.
     * @param key - The key of the element to retrieve.
     * @returns The value associated with the key, or `undefined` if the key is not in the cache.
     */
    get(key: K): V | undefined;
    /**
     * Adds or updates a key-value pair in the cache and marks the key as recently used.
     * If setting a new key causes the cache to exceed its capacity, the least recently used item is evicted.
     * @param key - The key of the element to add or update.
     * @param value - The value of the element to add or update.
     * @returns The `MapLru` instance.
     */
    set(key: K, value: V): this;
    /**
     * Removes the specified element from the cache.
     * @param key - The key of the element to remove.
     * @returns `true` if an element in the `MapLru` object existed and has been removed, or `false` if the element does not exist.
     */
    delete(key: K): boolean;
    /**
     * Removes all key-value pairs from the cache.
     */
    clear(): void;
}
//# sourceMappingURL=memory.advanced.d.ts.map