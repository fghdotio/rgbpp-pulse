import { ScriptInfo, ScriptInfoLike } from "./clientTypes.js";
import { ClientJsonRpc, ClientJsonRpcConfig } from "./jsonRpc/index.js";
import { KnownScript } from "./knownScript.js";
/**
 * @public
 */
export declare class ClientPublicMainnet extends ClientJsonRpc {
    private readonly config?;
    constructor(config?: (ClientJsonRpcConfig & {
        url?: string;
        scripts?: Record<KnownScript, ScriptInfoLike | undefined>;
    }) | undefined);
    get scripts(): Record<KnownScript, ScriptInfoLike | undefined>;
    get addressPrefix(): string;
    getKnownScript(script: KnownScript): Promise<ScriptInfo>;
}
//# sourceMappingURL=clientPublicMainnet.d.ts.map