import { Address } from "../../address/index.js";
import { Script, ScriptLike } from "../../ckb/index.js";
import { Client } from "../../client/index.js";
import { Signer, SignerSignType, SignerType } from "../signer/index.js";
/**
 * A read-only signer for a CKB script. It can be used to get addresses,
 * but not to sign transactions. This is useful when you want to watch an address
 * without having the private key.
 *
 * @public
 */
export declare class SignerCkbScriptReadonly extends Signer {
    /**
     * The type of the signer.
     */
    get type(): SignerType;
    /**
     * The sign type of the signer.
     * As this is a read-only signer, the sign type is {@link SignerSignType.Unknown}.
     */
    get signType(): SignerSignType;
    /**
     * The scripts associated with the signer.
     */
    readonly scripts: Script[];
    /**
     * Creates an instance of SignerCkbScriptReadonly.
     *
     * @param client - The client instance used for communication.
     * @param scripts - The scripts associated with the signer. Can be a single script, an array of scripts, or multiple script arguments.
     */
    constructor(client: Client, ...scripts: (ScriptLike | ScriptLike[])[]);
    /**
     * Connects to the client. This implementation does nothing as the class is read-only.
     *
     * @returns A promise that resolves when the connection is complete.
     */
    connect(): Promise<void>;
    /**
     * Check if the signer is connected.
     *
     * @returns A promise that resolves the connection status.
     */
    isConnected(): Promise<boolean>;
    /**
     * Gets the internal address for the script.
     *
     * @returns A promise that resolves to a string representing the internal address.
     *
     * @example
     * ```typescript
     * const internalAddress = await signer.getInternalAddress(); // Outputs the internal address
     * ```
     */
    getInternalAddress(): Promise<string>;
    /**
     * Gets an array of Address objects representing the script address.
     *
     * @returns A promise that resolves to an array of Address objects.
     *
     * @example
     * ```typescript
     * const addressObjs = await signer.getAddressObjs(); // Outputs the array of Address objects
     * ```
     */
    getAddressObjs(): Promise<Address[]>;
}
//# sourceMappingURL=signerCkbScriptReadonly.d.ts.map