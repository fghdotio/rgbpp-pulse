"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SignerCkbScriptReadonly = void 0;
const index_js_1 = require("../../address/index.js");
const index_js_2 = require("../../ckb/index.js");
const index_js_3 = require("../signer/index.js");
/**
 * A read-only signer for a CKB script. It can be used to get addresses,
 * but not to sign transactions. This is useful when you want to watch an address
 * without having the private key.
 *
 * @public
 */
class SignerCkbScriptReadonly extends index_js_3.Signer {
    /**
     * The type of the signer.
     */
    get type() {
        return index_js_3.SignerType.CKB;
    }
    /**
     * The sign type of the signer.
     * As this is a read-only signer, the sign type is {@link SignerSignType.Unknown}.
     */
    get signType() {
        return index_js_3.SignerSignType.Unknown;
    }
    /**
     * Creates an instance of SignerCkbScriptReadonly.
     *
     * @param client - The client instance used for communication.
     * @param scripts - The scripts associated with the signer. Can be a single script, an array of scripts, or multiple script arguments.
     */
    constructor(client, ...scripts) {
        super(client);
        this.scripts = scripts.flat().map(index_js_2.Script.from);
        if (this.scripts.length === 0) {
            throw new Error("SignerCkbScriptReadonly requires at least one script.");
        }
    }
    /**
     * Connects to the client. This implementation does nothing as the class is read-only.
     *
     * @returns A promise that resolves when the connection is complete.
     */
    async connect() { }
    /**
     * Check if the signer is connected.
     *
     * @returns A promise that resolves the connection status.
     */
    async isConnected() {
        return true;
    }
    /**
     * Gets the internal address for the script.
     *
     * @returns A promise that resolves to a string representing the internal address.
     *
     * @example
     * ```typescript
     * const internalAddress = await signer.getInternalAddress(); // Outputs the internal address
     * ```
     */
    async getInternalAddress() {
        return this.getRecommendedAddress();
    }
    /**
     * Gets an array of Address objects representing the script address.
     *
     * @returns A promise that resolves to an array of Address objects.
     *
     * @example
     * ```typescript
     * const addressObjs = await signer.getAddressObjs(); // Outputs the array of Address objects
     * ```
     */
    async getAddressObjs() {
        return this.scripts.map((script) => index_js_1.Address.fromScript(script, this.client));
    }
}
exports.SignerCkbScriptReadonly = SignerCkbScriptReadonly;
