"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InputToSign = exports.SignPsbtOptions = void 0;
const index_js_1 = require("../../hex/index.js");
class SignPsbtOptions {
    constructor(autoFinalized, inputsToSign) {
        this.autoFinalized = autoFinalized;
        this.inputsToSign = inputsToSign;
    }
    static from(options) {
        if (options instanceof SignPsbtOptions) {
            return options;
        }
        return new SignPsbtOptions(options?.autoFinalized ?? true, options?.inputsToSign?.map((i) => InputToSign.from(i)) ?? []);
    }
}
exports.SignPsbtOptions = SignPsbtOptions;
class InputToSign {
    constructor(index, sighashTypes, disableTweakSigner, address, publicKey) {
        this.index = index;
        this.sighashTypes = sighashTypes;
        this.disableTweakSigner = disableTweakSigner;
        this.address = address;
        this.publicKey = publicKey;
    }
    static from(input) {
        if (input instanceof InputToSign) {
            return input;
        }
        return new InputToSign(input.index, input.sighashTypes, input.disableTweakSigner, input.address, input.publicKey ? (0, index_js_1.hexFrom)(input.publicKey) : undefined);
    }
}
exports.InputToSign = InputToSign;
