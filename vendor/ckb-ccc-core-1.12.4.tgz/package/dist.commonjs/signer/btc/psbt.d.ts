import { Hex, HexLike } from "../../hex/index.js";
/**
 * Options for signing a PSBT (Partially Signed Bitcoin Transaction)
 */
export type SignPsbtOptionsLike = {
    /**
     * Whether to finalize the PSBT after signing.
     * Default is true.
     */
    autoFinalized?: boolean;
    /**
     * Array of inputs to sign
     */
    inputsToSign?: InputToSignLike[];
};
export declare class SignPsbtOptions {
    autoFinalized: boolean;
    inputsToSign: InputToSign[];
    constructor(autoFinalized: boolean, inputsToSign: InputToSign[]);
    static from(options?: SignPsbtOptionsLike): SignPsbtOptions;
}
/**
 * Specification for an input to sign in a PSBT.
 * Must specify at least one of: address or pubkey.
 */
export type InputToSignLike = {
    /**
     * Which input to sign (index in the PSBT inputs array)
     */
    index: number;
    /**
     * (Optional) Sighash types to use for signing.
     */
    sighashTypes?: number[];
    /**
     * (Optional) When signing and unlocking Taproot addresses, the tweakSigner is used by default
     * for signature generation. Setting this to true allows for signing with the original private key.
     * Default value is false.
     */
    disableTweakSigner?: boolean;
} & ({
    /**
     * The address whose corresponding private key to use for signing.
     */
    address: string;
    /**
     * The public key whose corresponding private key to use for signing.
     */
    publicKey?: HexLike;
} | {
    /**
     * The address whose corresponding private key to use for signing.
     */
    address?: string;
    /**
     * The public key whose corresponding private key to use for signing.
     */
    publicKey: HexLike;
});
export declare class InputToSign {
    index: number;
    sighashTypes?: number[] | undefined;
    disableTweakSigner?: boolean | undefined;
    address?: string | undefined;
    publicKey?: Hex | undefined;
    constructor(index: number, sighashTypes?: number[] | undefined, disableTweakSigner?: boolean | undefined, address?: string | undefined, publicKey?: Hex | undefined);
    static from(input: InputToSignLike): InputToSign;
}
//# sourceMappingURL=psbt.d.ts.map