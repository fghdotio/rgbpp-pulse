import { Bytes, BytesLike } from "../../bytes/index.js";
import { Hex } from "../../hex/index.js";
import { NumLike } from "../../num/index.js";
/**
 * Encodes a number into a variable-length byte array according to the Bitcoin protocol.
 * This format is used for encoding lengths of data, such as script lengths.
 *
 * @param len - The number to encode. Can be a NumLike.
 * @returns The encoded length as a Bytes.
 * @public
 */
export declare function btcVarLengthBytesFrom(len: NumLike): Bytes;
/**
 * Computes the message hash for Bitcoin ECDSA signatures.
 * This function follows the Bitcoin message signing standard, which involves
 * prefixing the message with a magic string and its length, then double SHA256 hashing the result.
 *
 * @param message - The message to be hashed. Can be a string or BytesLike.
 * @param messagePrefix - Optional. A custom prefix to use instead of the default "\u0018Bitcoin Signed Message:\n".
 * @returns The Bitcoin hash of the prefixed message as Bytes.
 * @public
 */
export declare function messageHashBtcEcdsa(message: string | BytesLike, messagePrefix?: string | BytesLike): Bytes;
/**
 * @public
 */
export declare function btcEcdsaPublicKeyHash(publicKey: BytesLike): Bytes;
/**
 * @public
 */
export declare function btcP2pkhAddressFromPublicKey(publicKey: BytesLike, network: number): string;
/**
 * @public
 */
export declare function btcPublicKeyFromP2pkhAddress(address: string): Hex;
/**
 * @public
 */
export declare function verifyMessageBtcEcdsa(message: string | BytesLike, signature: string, publicKey: string): boolean;
//# sourceMappingURL=verify.d.ts.map