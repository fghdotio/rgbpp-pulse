"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.btcVarLengthBytesFrom = btcVarLengthBytesFrom;
exports.messageHashBtcEcdsa = messageHashBtcEcdsa;
exports.btcEcdsaPublicKeyHash = btcEcdsaPublicKeyHash;
exports.btcP2pkhAddressFromPublicKey = btcP2pkhAddressFromPublicKey;
exports.btcPublicKeyFromP2pkhAddress = btcPublicKeyFromP2pkhAddress;
exports.verifyMessageBtcEcdsa = verifyMessageBtcEcdsa;
const secp256k1_1 = require("@noble/curves/secp256k1");
const legacy_js_1 = require("@noble/hashes/legacy.js");
const sha2_js_1 = require("@noble/hashes/sha2.js");
const bs58check_1 = __importDefault(require("bs58check"));
const index_js_1 = require("../../bytes/index.js");
const index_js_2 = require("../../hex/index.js");
const index_js_3 = require("../../num/index.js");
/**
 * Encodes a number into a variable-length byte array according to the Bitcoin protocol.
 * This format is used for encoding lengths of data, such as script lengths.
 *
 * @param len - The number to encode. Can be a NumLike.
 * @returns The encoded length as a Bytes.
 * @public
 */
function btcVarLengthBytesFrom(len) {
    const num = (0, index_js_3.numFrom)(len);
    return num < 0xfd
        ? (0, index_js_3.numLeToBytes)(num, 1)
        : num <= 0xffff
            ? (0, index_js_1.bytesConcat)([0xfd], (0, index_js_3.numLeToBytes)(num, 2))
            : num <= 0xffffffff
                ? (0, index_js_1.bytesConcat)([0xfe], (0, index_js_3.numLeToBytes)(num, 4))
                : (0, index_js_1.bytesConcat)([0xff], (0, index_js_3.numLeToBytes)(num, 8));
}
/**
 * Computes the message hash for Bitcoin ECDSA signatures.
 * This function follows the Bitcoin message signing standard, which involves
 * prefixing the message with a magic string and its length, then double SHA256 hashing the result.
 *
 * @param message - The message to be hashed. Can be a string or BytesLike.
 * @param messagePrefix - Optional. A custom prefix to use instead of the default "\u0018Bitcoin Signed Message:\n".
 * @returns The Bitcoin hash of the prefixed message as Bytes.
 * @public
 */
function messageHashBtcEcdsa(message, messagePrefix) {
    const prefix = messagePrefix ?? "\u0018Bitcoin Signed Message:\n";
    const rawPrefix = typeof prefix === "string" ? (0, index_js_1.bytesFrom)(prefix, "utf8") : (0, index_js_1.bytesFrom)(prefix);
    const rawMsg = typeof message === "string"
        ? (0, index_js_1.bytesFrom)(message, "utf8")
        : (0, index_js_1.bytesFrom)(message);
    return (0, sha2_js_1.sha256)((0, sha2_js_1.sha256)((0, index_js_1.bytesConcat)(rawPrefix, btcVarLengthBytesFrom(rawMsg.length), rawMsg)));
}
/**
 * @public
 */
function btcEcdsaPublicKeyHash(publicKey) {
    return (0, legacy_js_1.ripemd160)((0, sha2_js_1.sha256)((0, index_js_1.bytesFrom)(publicKey)));
}
/**
 * @public
 */
function btcP2pkhAddressFromPublicKey(publicKey, network) {
    return bs58check_1.default.encode((0, index_js_1.bytesConcat)([network], btcEcdsaPublicKeyHash(publicKey)));
}
/**
 * @public
 */
function btcPublicKeyFromP2pkhAddress(address) {
    return (0, index_js_2.hexFrom)(bs58check_1.default.decode(address).slice(1));
}
/**
 * @public
 */
function verifyMessageBtcEcdsa(message, signature, publicKey) {
    const challenge = typeof message === "string" ? message : (0, index_js_2.hexFrom)(message).slice(2);
    const rawSign = (0, index_js_1.bytesFrom)(signature, "base64").slice(1);
    return secp256k1_1.secp256k1.verify((0, index_js_1.bytesFrom)(rawSign), messageHashBtcEcdsa(challenge), (0, index_js_1.bytesFrom)(publicKey));
}
