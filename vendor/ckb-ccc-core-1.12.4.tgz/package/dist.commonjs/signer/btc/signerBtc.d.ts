import { Address } from "../../address/index.js";
import { Transaction, TransactionLike } from "../../ckb/index.js";
import { Hex, HexLike } from "../../hex/index.js";
import { Signer, SignerSignType, SignerType } from "../signer/index.js";
import { SignPsbtOptionsLike } from "./psbt.js";
/**
 * An abstract class extending the Signer class for Bitcoin-like signing operations.
 * This class provides methods to get Bitcoin account, public key, and internal address,
 * as well as signing transactions.
 * @public
 */
export declare abstract class SignerBtc extends Signer {
    get type(): SignerType;
    get signType(): SignerSignType;
    /**
     * Sign and broadcast a PSBT.
     *
     * @param psbtHex - The hex string of PSBT to sign and broadcast.
     * @param options - Options for signing the PSBT.
     * @returns A promise that resolves to the transaction ID as a Hex string.
     */
    signAndBroadcastPsbt(psbtHex: HexLike, options?: SignPsbtOptionsLike): Promise<Hex>;
    /**
     * Gets the Bitcoin account associated with the signer.
     *
     * @returns A promise that resolves to a string representing the Bitcoin account.
     */
    abstract getBtcAccount(): Promise<string>;
    /**
     * Gets the Bitcoin public key associated with the signer.
     *
     * @returns A promise that resolves to a HexLike value representing the Bitcoin public key.
     */
    abstract getBtcPublicKey(): Promise<HexLike>;
    /**
     * Gets the internal address, which is the Bitcoin account in this case.
     *
     * @returns A promise that resolves to a string representing the internal address.
     */
    getInternalAddress(): Promise<string>;
    /**
     * Gets the identity, which is the Bitcoin public key in this case.
     *
     * @returns A promise that resolves to a string representing the identity
     */
    getIdentity(): Promise<string>;
    /**
     * Gets an array of Address objects representing the known script addresses for the signer.
     *
     * @returns A promise that resolves to an array of Address objects.
     */
    getAddressObjs(): Promise<Address[]>;
    /**
     * prepare a transaction before signing. This method is not implemented and should be overridden by subclasses.
     *
     * @param txLike - The transaction to prepare, represented as a TransactionLike object.
     * @returns A promise that resolves to the prepared Transaction object.
     */
    prepareTransaction(txLike: TransactionLike): Promise<Transaction>;
    /**
     * Signs a transaction without modifying it.
     *
     * @param txLike - The transaction to sign, represented as a TransactionLike object.
     * @returns A promise that resolves to a signed Transaction object.
     */
    signOnlyTransaction(txLike: TransactionLike): Promise<Transaction>;
    /**
     * Signs a Partially Signed Bitcoin Transaction (PSBT).
     *
     * @param psbtHex - The hex string of PSBT to sign.
     * @param options - Options for signing the PSBT
     * @returns A promise that resolves to the signed PSBT as a Hex string.
     */
    abstract signPsbt(psbtHex: HexLike, options?: SignPsbtOptionsLike): Promise<Hex>;
    /**
     * Broadcasts a PSBT to the Bitcoin network.
     *
     * @param psbtHex - The hex string of the PSBT to broadcast.
     * @param options - Options for broadcasting the PSBT.
     * @returns A promise that resolves to the transaction ID as a Hex string.
     */
    abstract broadcastPsbt(psbtHex: HexLike, options?: SignPsbtOptionsLike): Promise<Hex>;
}
//# sourceMappingURL=signerBtc.d.ts.map