"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SignerDogePrivateKey = void 0;
const secp256k1_1 = require("@noble/curves/secp256k1");
const index_js_1 = require("../../bytes/index.js");
const index_js_2 = require("../../hex/index.js");
const verify_js_1 = require("../btc/verify.js");
const signerDoge_js_1 = require("./signerDoge.js");
const verify_js_2 = require("./verify.js");
/**
 * A class extending SignerDoge that provides access to a Doge address.
 * @public
 */
class SignerDogePrivateKey extends signerDoge_js_1.SignerDoge {
    /**
     * Creates an instance of SignerDogePrivateKey
     *
     * @param client - The client instance used for communication.
     * @param privateKey - The Doge private key with the signer.
     */
    constructor(client, privateKey, dogeNetwork = 0x1e) {
        super(client);
        this.dogeNetwork = dogeNetwork;
        this.privateKey = (0, index_js_1.bytesFrom)(privateKey);
        if (this.privateKey.length !== 32) {
            throw new Error("Private key must be 32 bytes!");
        }
    }
    /**
     * Connects to the client. This implementation does nothing as the class is always connected.
     *
     * @returns A promise that resolves when the connection is complete.
     */
    async connect() { }
    /**
     * Check if the signer is connected.
     *
     * @returns A promise that resolves the connection status.
     */
    async isConnected() {
        return true;
    }
    async getDogePublicKey() {
        return (0, index_js_2.hexFrom)(secp256k1_1.secp256k1.getPublicKey(this.privateKey, true));
    }
    /**
     * Gets the Doge address associated with the signer.
     *
     * @returns A promise that resolves to a string representing the Doge address.
     *
     * @example
     * ```typescript
     * const account = await signer.getDogeAddress(); // Outputs the Doge address
     * ```
     */
    async getDogeAddress() {
        return (0, verify_js_1.btcP2pkhAddressFromPublicKey)(await this.getDogePublicKey(), this.dogeNetwork);
    }
    /**
     * Signs a message and returns signature only.
     *
     * @param msg - The message to sign, as a string or BytesLike object.
     * @returns A promise that resolves to the signature as a string.
     * @throws Will throw an error if not implemented.
     */
    async signMessageRaw(msg) {
        const challenge = typeof msg === "string" ? msg : (0, index_js_2.hexFrom)(msg).slice(2);
        const signature = secp256k1_1.secp256k1.sign((0, verify_js_2.messageHashDogeEcdsa)(challenge), this.privateKey);
        return (0, index_js_1.bytesTo)((0, index_js_1.bytesConcat)([31 + signature.recovery], signature.toCompactRawBytes()), "base64");
    }
}
exports.SignerDogePrivateKey = SignerDogePrivateKey;
