"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.messageHashDogeEcdsa = messageHashDogeEcdsa;
exports.verifyMessageDogeEcdsa = verifyMessageDogeEcdsa;
const secp256k1_1 = require("@noble/curves/secp256k1");
const index_js_1 = require("../../bytes/index.js");
const index_js_2 = require("../../hex/index.js");
const verify_js_1 = require("../btc/verify.js");
/**
 * Computes the message hash for Dogecoin ECDSA signatures.
 * This function follows the Dogecoin message signing standard, which involves
 * prefixing the message with a magic string and its length, then double SHA256 hashing the result.
 *
 * @param message - The message to be hashed. Can be a string or BytesLike.
 * @param messagePrefix - Optional. A custom prefix to use instead of the default "\x19Dogecoin Signed Message:\n".
 * @returns The Dogecoin hash of the prefixed message as Bytes.
 * @public
 */
function messageHashDogeEcdsa(message, messagePrefix) {
    return (0, verify_js_1.messageHashBtcEcdsa)(message, messagePrefix ?? "\x19Dogecoin Signed Message:\n");
}
/**
 * @public
 */
function verifyMessageDogeEcdsa(message, signature, address) {
    const challenge = typeof message === "string" ? message : (0, index_js_2.hexFrom)(message).slice(2);
    const signatureBytes = (0, index_js_1.bytesFrom)(signature, "base64");
    const recoveryBit = signatureBytes[0];
    const rawSign = signatureBytes.slice(1);
    const sig = secp256k1_1.secp256k1.Signature.fromCompact((0, index_js_2.hexFrom)(rawSign).slice(2)).addRecoveryBit(recoveryBit - 31);
    return ((0, verify_js_1.btcPublicKeyFromP2pkhAddress)(address) ===
        (0, index_js_2.hexFrom)((0, verify_js_1.btcEcdsaPublicKeyHash)(sig.recoverPublicKey(messageHashDogeEcdsa(challenge)).toHex())));
}
