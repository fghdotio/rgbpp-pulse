import { Bytes, BytesLike } from "../../bytes/index.js";
/**
 * Computes the message hash for Dogecoin ECDSA signatures.
 * This function follows the Dogecoin message signing standard, which involves
 * prefixing the message with a magic string and its length, then double SHA256 hashing the result.
 *
 * @param message - The message to be hashed. Can be a string or BytesLike.
 * @param messagePrefix - Optional. A custom prefix to use instead of the default "\x19Dogecoin Signed Message:\n".
 * @returns The Dogecoin hash of the prefixed message as Bytes.
 * @public
 */
export declare function messageHashDogeEcdsa(message: string | BytesLike, messagePrefix?: string | BytesLike): Bytes;
/**
 * @public
 */
export declare function verifyMessageDogeEcdsa(message: string | BytesLike, signature: string, address: string): boolean;
//# sourceMappingURL=verify.d.ts.map