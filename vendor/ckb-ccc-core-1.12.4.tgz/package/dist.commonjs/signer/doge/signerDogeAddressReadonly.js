"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SignerDogeAddressReadonly = void 0;
const signerDoge_js_1 = require("./signerDoge.js");
/**
 * A class extending SignerDoge that provides read-only access to a Doge address.
 * This class does not support signing operations.
 * @public
 */
class SignerDogeAddressReadonly extends signerDoge_js_1.SignerDoge {
    /**
     * Creates an instance of SignerDogeAddressReadonly.
     *
     * @param client - The client instance used for communication.
     * @param address - The Doge address with the signer.
     */
    constructor(client, address) {
        super(client);
        this.address = address;
    }
    /**
     * Connects to the client. This implementation does nothing as the class is read-only.
     *
     * @returns A promise that resolves when the connection is complete.
     */
    async connect() { }
    /**
     * Check if the signer is connected.
     *
     * @returns A promise that resolves the connection status.
     */
    async isConnected() {
        return true;
    }
    /**
     * Gets the Doge address associated with the signer.
     *
     * @returns A promise that resolves to a string representing the Doge address.
     *
     * @example
     * ```typescript
     * const account = await signer.getDogeAddress(); // Outputs the Doge address
     * ```
     */
    async getDogeAddress() {
        return this.address;
    }
}
exports.SignerDogeAddressReadonly = SignerDogeAddressReadonly;
