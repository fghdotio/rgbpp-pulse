import { Client } from "../../client/index.js";
import { Hex, HexLike } from "../../hex/index.js";
import { SignerNostr } from "./signerNostr.js";
/**
 * Signer from Nostr public key
 * Support npub and hex format
 */
export declare class SignerNostrPublicKeyReadonly extends SignerNostr {
    readonly publicKey: Hex;
    constructor(client: Client, publicKey: HexLike);
    connect(): Promise<void>;
    isConnected(): Promise<boolean>;
    getNostrPublicKey(): Promise<Hex>;
}
//# sourceMappingURL=signerNostrPublicKeyReadonly.d.ts.map