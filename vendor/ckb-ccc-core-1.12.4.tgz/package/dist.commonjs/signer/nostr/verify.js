"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildNostrEventFromMessage = buildNostrEventFromMessage;
exports.nostrEventHash = nostrEventHash;
exports.verifyMessageNostrEvent = verifyMessageNostrEvent;
const secp256k1_1 = require("@noble/curves/secp256k1");
const sha2_js_1 = require("@noble/hashes/sha2.js");
const bech32_1 = require("bech32");
const index_js_1 = require("../../bytes/index.js");
const index_js_2 = require("../../hex/index.js");
/**
 * @public
 */
function buildNostrEventFromMessage(message) {
    if (typeof message === "string") {
        try {
            // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
            const event = JSON.parse(message);
            if (typeof event === "object" &&
                typeof event.created_at === "number" &&
                typeof event.kind === "number" &&
                typeof event.content === "string" &&
                Array.isArray(event.tags) &&
                event.tags.every((tag) => Array.isArray(tag) &&
                    tag.every((v) => typeof v === "string"))) {
                return event;
            }
        }
        catch (_) { }
    }
    return {
        kind: 23335,
        created_at: 0,
        content: typeof message === "string" ? message : (0, index_js_2.hexFrom)(message),
        tags: [],
    };
}
function nostrEventHash(event) {
    const serialized = JSON.stringify([
        0,
        event.pubkey,
        event.created_at,
        event.kind,
        event.tags,
        event.content,
    ]);
    return (0, sha2_js_1.sha256)((0, index_js_1.bytesFrom)(serialized, "utf8"));
}
function verifyMessageNostrEvent(message, signature, address) {
    const { words } = bech32_1.bech32.decode(address);
    const pubkey = (0, index_js_2.hexFrom)(bech32_1.bech32.fromWords(words)).slice(2);
    const event = buildNostrEventFromMessage(message);
    const eventHash = nostrEventHash({ ...event, pubkey });
    try {
        return secp256k1_1.schnorr.verify((0, index_js_2.hexFrom)(signature).slice(2), eventHash, pubkey);
    }
    catch (_) {
        return false;
    }
}
