import { Client } from "../../client/index.js";
import { HexLike } from "../../hex/index.js";
import { NostrEvent } from "./signerNostr.js";
import { SignerNostrPublicKeyReadonly } from "./signerNostrPublicKeyReadonly.js";
/**
 * Signer from Nostr private key
 * Support nsec and hex format
 */
export declare class SignerNostrPrivateKey extends SignerNostrPublicKeyReadonly {
    private readonly privateKey;
    constructor(client: Client, privateKeyLike: HexLike);
    signNostrEvent(event: NostrEvent): Promise<Required<NostrEvent>>;
}
//# sourceMappingURL=signerNostrPrivateKey.d.ts.map