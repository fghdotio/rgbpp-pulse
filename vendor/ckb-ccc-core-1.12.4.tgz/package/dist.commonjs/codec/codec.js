"use strict";
/* eslint-disable @typescript-eslint/no-explicit-any */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Codec = void 0;
const index_js_1 = require("../bytes/index.js");
class Codec {
    constructor(encode, decode, byteLength) {
        this.encode = encode;
        this.decode = decode;
        this.byteLength = byteLength;
    }
    encodeOr(encodable, fallback) {
        try {
            return this.encode(encodable);
        }
        catch (_) {
            return fallback;
        }
    }
    decodeOr(decodable, fallback, config) {
        try {
            return this.decode(decodable, config);
        }
        catch (_) {
            return fallback;
        }
    }
    static from({ encode, decode, byteLength, }) {
        return new Codec((encodable) => {
            const encoded = encode(encodable);
            if (byteLength !== undefined && encoded.byteLength !== byteLength) {
                throw new Error(`Codec.encode: expected byte length ${byteLength}, got ${encoded.byteLength}`);
            }
            return encoded;
        }, (decodable, config) => {
            const decodableBytes = (0, index_js_1.bytesFrom)(decodable);
            if (byteLength !== undefined &&
                decodableBytes.byteLength !== byteLength) {
                throw new Error(`Codec.decode: expected byte length ${byteLength}, got ${decodableBytes.byteLength}`);
            }
            return decode(decodable, config);
        }, byteLength);
    }
    map({ inMap, outMap, }) {
        return new Codec((encodable) => this.encode((inMap ? inMap(encodable) : encodable)), (buffer, config) => (outMap
            ? outMap(this.decode(buffer, config))
            : this.decode(buffer, config)), this.byteLength);
    }
    mapIn(map) {
        return this.map({ inMap: map });
    }
    mapOut(map) {
        return this.map({ outMap: map });
    }
}
exports.Codec = Codec;
