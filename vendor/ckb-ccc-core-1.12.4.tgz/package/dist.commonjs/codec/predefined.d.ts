import { Bytes, BytesLike } from "../bytes/index.js";
import { Hex, HexLike } from "../hex/index.js";
import { Num, NumLike } from "../num/index.js";
import { Codec } from "./codec.js";
/**
 * Create a codec to deal with fixed LE or BE bytes.
 * @param byteLength
 * @param littleEndian
 */
export declare function codecUint(byteLength: number, littleEndian?: boolean): Codec<NumLike, Num>;
/**
 * Create a codec to deal with fixed LE or BE bytes.
 * @param byteLength
 * @param littleEndian
 */
export declare function codecUintNumber(byteLength: number, littleEndian?: boolean): Codec<NumLike, number>;
/**
 * Create a codec for padding bytes.
 * The padding bytes are zero-filled when encoding and ignored when decoding.
 * @param byteLength The length of the padding in bytes.
 */
export declare function codecPadding(byteLength: number): Codec<void | undefined | null, void>;
export declare const CodecRaw: Codec<BytesLike, Bytes>;
export declare const CodecBytes: Codec<HexLike, Hex>;
export declare const CodecUint8: Codec<NumLike, number>;
export declare const CodecUint16LE: Codec<NumLike, number>;
export declare const CodecUint16BE: Codec<NumLike, number>;
export declare const CodecUint16: Codec<NumLike, number>;
export declare const CodecUint32LE: Codec<NumLike, number>;
export declare const CodecUint32BE: Codec<NumLike, number>;
export declare const CodecUint32: Codec<NumLike, number>;
export declare const CodecUint64LE: Codec<NumLike, bigint>;
export declare const CodecUint64BE: Codec<NumLike, bigint>;
export declare const CodecUint64: Codec<NumLike, bigint>;
export declare const CodecUint128LE: Codec<NumLike, bigint>;
export declare const CodecUint128BE: Codec<NumLike, bigint>;
export declare const CodecUint128: Codec<NumLike, bigint>;
export declare const CodecUint256LE: Codec<NumLike, bigint>;
export declare const CodecUint256BE: Codec<NumLike, bigint>;
export declare const CodecUint256: Codec<NumLike, bigint>;
export declare const CodecUint512LE: Codec<NumLike, bigint>;
export declare const CodecUint512BE: Codec<NumLike, bigint>;
export declare const CodecUint512: Codec<NumLike, bigint>;
export declare const CodecBool: Codec<boolean>;
export declare const CodecByte: Codec<HexLike, Hex>;
export declare const CodecByte4: Codec<HexLike, Hex>;
export declare const CodecByte8: Codec<HexLike, Hex>;
export declare const CodecByte16: Codec<HexLike, Hex>;
export declare const CodecByte32: Codec<HexLike, Hex>;
//# sourceMappingURL=predefined.d.ts.map