import { Bytes, BytesLike } from "../bytes/index.js";
import { Hex } from "../hex/index.js";
import { Constructor } from "../utils/index.js";
import { Codec } from "./codec.js";
/**
 * The base class of CCC to create a serializable instance. This should be used with the {@link codec} decorator.
 * @public
 */
export declare abstract class Entity {
    /**
     * Generate a base class of CCC to create a serializable instance.
     * This should be used with the {@link codec} decorator.
     * @public
     */
    static Base<SubTypeLike, SubType = SubTypeLike>(): (abstract new () => {
        /**
         * Convert the entity to bytes
         * @public
         * @returns The bytes representation of the entity
         */
        toBytes(): Bytes;
        /**
         * Create a clone of the entity
         * @public
         * @returns A clone of the entity
         */
        clone(): SubType;
        /**
         * Check if the entity is equal to another entity
         * @public
         * @param other - The other entity to compare with
         * @returns True if the entities are equal, false otherwise
         */
        eq(other: SubTypeLike): boolean;
        /**
         * Calculate the hash of the entity
         * @public
         * @returns The hash of the entity
         */
        hash(): Hex;
        /**
         * Convert the entity to a full-byte untrimmed Hex representation
         * @public
         * @returns The entity full-byte untrimmed hexadecimal representation
         */
        toHex(): Hex;
    }) & {
        /**
         * The bytes length of the entity, if it is fixed, otherwise undefined
         * @public
         * @static
         */
        byteLength?: number;
        /**
         * Encode the entity into bytes
         * @public
         * @static
         * @param _ - The entity to encode
         * @returns The encoded bytes
         * @throws Will throw an error if the entity is not serializable
         */
        encode(_: SubTypeLike): Bytes;
        /**
         * Decode the entity from bytes
         * @public
         * @static
         * @param _ - The bytes to decode
         * @returns The decoded entity
         * @throws Will throw an error if the entity is not serializable
         */
        decode(_: BytesLike): SubType;
        /**
         * Create an entity from bytes
         * @public
         * @static
         * @param _ - The bytes to create the entity from
         * @returns The created entity
         * @throws Will throw an error if the entity is not serializable
         */
        fromBytes(_bytes: BytesLike): SubType;
        /**
         * Create an entity from a serializable object
         * @public
         * @static
         * @param _ - The serializable object to create the entity from
         * @returns The created entity
         * @throws Will throw an error if the entity is not serializable
         */
        from(_: SubTypeLike): SubType;
    };
    abstract toBytes(): Bytes;
    abstract hash(): Hex;
    abstract toHex(): Hex;
    abstract clone(): Entity;
}
/**
 * A class decorator to add methods implementation on the {@link Entity.Base} class
 * @example
 * ```typescript
 * @codec(
 *   mol.table({
 *     codeHash: mol.Byte32,
 *     hashType: HashTypeCodec,
 *     args: mol.Bytes,
 *   }),
 * )
 * export class Script extends Entity.Base<ScriptLike, Script>() {
 *   from(scriptLike: ScriptLike): Script {}
 * }
 * ```
 */
export declare function codec<Encodable, TypeLike extends Encodable, Decoded extends TypeLike>(codec: Codec<Encodable, Decoded>): <Type extends TypeLike, ConstructorType extends Constructor<Type> & {
    from(decoded: TypeLike): Type;
    byteLength?: number;
    encode(encodable: TypeLike): Bytes;
    decode(bytesLike: BytesLike): Type;
    fromBytes(bytes: BytesLike): Type;
}>(Constructor: ConstructorType, ..._: unknown[]) => ConstructorType;
//# sourceMappingURL=entity.d.ts.map