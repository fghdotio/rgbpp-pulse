import { Bytes, BytesLike } from "../bytes/index.js";
export type CodecLike<Encodable, Decoded = Encodable> = {
    readonly encode: (encodable: Encodable) => Bytes;
    readonly decode: (decodable: BytesLike, config?: {
        isExtraFieldIgnored?: boolean;
    }) => Decoded;
    readonly byteLength?: number;
};
export declare class Codec<Encodable, Decoded = Encodable> {
    readonly encode: (encodable: Encodable) => Bytes;
    readonly decode: (decodable: BytesLike, config?: {
        isExtraFieldIgnored?: boolean;
    }) => Decoded;
    readonly byteLength?: number | undefined;
    constructor(encode: (encodable: Encodable) => Bytes, decode: (decodable: BytesLike, config?: {
        isExtraFieldIgnored?: boolean;
    }) => Decoded, byteLength?: number | undefined);
    encodeOr<T>(encodable: Encodable, fallback: T): Bytes | T;
    decodeOr<T>(decodable: BytesLike, fallback: T, config?: {
        isExtraFieldIgnored?: boolean;
    }): Decoded | T;
    static from<Encodable, Decoded = Encodable>({ encode, decode, byteLength, }: CodecLike<Encodable, Decoded>): Codec<Encodable, Decoded>;
    map<NewEncodable = Encodable, NewDecoded = Decoded>({ inMap, outMap, }: {
        inMap?: (encodable: NewEncodable) => Encodable;
        outMap?: (decoded: Decoded) => NewDecoded;
    }): Codec<NewEncodable, NewDecoded>;
    mapIn<NewEncodable>(map: (encodable: NewEncodable) => Encodable): Codec<NewEncodable, Decoded>;
    mapOut<NewDecoded>(map: (decoded: Decoded) => NewDecoded): Codec<Encodable, NewDecoded>;
}
export type EncodableType<T extends CodecLike<any, any>> = T extends CodecLike<infer Encodable, unknown> ? Encodable : never;
export type DecodedType<T extends CodecLike<any, any>> = T extends CodecLike<any, infer Decoded> ? Decoded : never;
//# sourceMappingURL=codec.d.ts.map