"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CodecByte32 = exports.CodecByte16 = exports.CodecByte8 = exports.CodecByte4 = exports.CodecByte = exports.CodecBool = exports.CodecUint512 = exports.CodecUint512BE = exports.CodecUint512LE = exports.CodecUint256 = exports.CodecUint256BE = exports.CodecUint256LE = exports.CodecUint128 = exports.CodecUint128BE = exports.CodecUint128LE = exports.CodecUint64 = exports.CodecUint64BE = exports.CodecUint64LE = exports.CodecUint32 = exports.CodecUint32BE = exports.CodecUint32LE = exports.CodecUint16 = exports.CodecUint16BE = exports.CodecUint16LE = exports.CodecUint8 = exports.CodecBytes = exports.CodecRaw = void 0;
exports.codecUint = codecUint;
exports.codecUintNumber = codecUintNumber;
exports.codecPadding = codecPadding;
const index_js_1 = require("../bytes/index.js");
const index_js_2 = require("../hex/index.js");
const index_js_3 = require("../num/index.js");
const codec_js_1 = require("./codec.js");
/**
 * Create a codec to deal with fixed LE or BE bytes.
 * @param byteLength
 * @param littleEndian
 */
function codecUint(byteLength, littleEndian = false) {
    return codec_js_1.Codec.from({
        byteLength,
        encode: (numLike) => {
            if (littleEndian) {
                return (0, index_js_3.numToBytes)(numLike, byteLength);
            }
            else {
                return (0, index_js_3.numBeToBytes)(numLike, byteLength);
            }
        },
        decode: (buffer) => {
            if (littleEndian) {
                return (0, index_js_3.numFromBytes)(buffer);
            }
            else {
                return (0, index_js_3.numBeFromBytes)(buffer);
            }
        },
    });
}
/**
 * Create a codec to deal with fixed LE or BE bytes.
 * @param byteLength
 * @param littleEndian
 */
function codecUintNumber(byteLength, littleEndian = false) {
    if (byteLength > 4) {
        throw new Error("uintNumber: byteLength must be less than or equal to 4");
    }
    return codecUint(byteLength, littleEndian).map({
        outMap: (num) => Number(num),
    });
}
/**
 * Create a codec for padding bytes.
 * The padding bytes are zero-filled when encoding and ignored when decoding.
 * @param byteLength The length of the padding in bytes.
 */
function codecPadding(byteLength) {
    return codec_js_1.Codec.from({
        byteLength,
        encode: () => {
            return new Uint8Array(byteLength);
        },
        decode: () => { },
    });
}
exports.CodecRaw = codec_js_1.Codec.from({
    encode: (value) => (0, index_js_1.bytesFrom)(value),
    decode: (buffer) => (0, index_js_1.bytesFrom)(buffer),
});
exports.CodecBytes = codec_js_1.Codec.from({
    encode: (value) => (0, index_js_1.bytesFrom)(value),
    decode: (buffer) => (0, index_js_2.hexFrom)(buffer),
});
exports.CodecUint8 = codecUintNumber(1, true);
exports.CodecUint16LE = codecUintNumber(2, true);
exports.CodecUint16BE = codecUintNumber(2);
exports.CodecUint16 = exports.CodecUint16LE;
exports.CodecUint32LE = codecUintNumber(4, true);
exports.CodecUint32BE = codecUintNumber(4);
exports.CodecUint32 = exports.CodecUint32LE;
exports.CodecUint64LE = codecUint(8, true);
exports.CodecUint64BE = codecUint(8);
exports.CodecUint64 = exports.CodecUint64LE;
exports.CodecUint128LE = codecUint(16, true);
exports.CodecUint128BE = codecUint(16);
exports.CodecUint128 = exports.CodecUint128LE;
exports.CodecUint256LE = codecUint(32, true);
exports.CodecUint256BE = codecUint(32);
exports.CodecUint256 = exports.CodecUint256LE;
exports.CodecUint512LE = codecUint(64, true);
exports.CodecUint512BE = codecUint(64);
exports.CodecUint512 = exports.CodecUint512LE;
exports.CodecBool = codec_js_1.Codec.from({
    byteLength: 1,
    encode: (value) => (0, index_js_1.bytesFrom)(value ? [1] : [0]),
    decode: (buffer) => (0, index_js_1.bytesFrom)(buffer)[0] !== 0,
});
exports.CodecByte = codec_js_1.Codec.from({
    byteLength: 1,
    encode: (value) => (0, index_js_1.bytesFrom)(value),
    decode: (buffer) => (0, index_js_2.hexFrom)(buffer),
});
exports.CodecByte4 = codec_js_1.Codec.from({
    byteLength: 4,
    encode: (value) => (0, index_js_1.bytesFrom)(value),
    decode: (buffer) => (0, index_js_2.hexFrom)(buffer),
});
exports.CodecByte8 = codec_js_1.Codec.from({
    byteLength: 8,
    encode: (value) => (0, index_js_1.bytesFrom)(value),
    decode: (buffer) => (0, index_js_2.hexFrom)(buffer),
});
exports.CodecByte16 = codec_js_1.Codec.from({
    byteLength: 16,
    encode: (value) => (0, index_js_1.bytesFrom)(value),
    decode: (buffer) => (0, index_js_2.hexFrom)(buffer),
});
exports.CodecByte32 = codec_js_1.Codec.from({
    byteLength: 32,
    encode: (value) => (0, index_js_1.bytesFrom)(value),
    decode: (buffer) => (0, index_js_2.hexFrom)(buffer),
});
