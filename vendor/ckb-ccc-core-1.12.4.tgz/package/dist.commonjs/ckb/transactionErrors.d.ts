import { Num, NumLike } from "../num/index.js";
import { Script, ScriptLike } from "./script.js";
export declare class ErrorTransactionInsufficientCapacity extends Error {
    readonly amount: Num;
    readonly isForChange: boolean;
    constructor(amountLike: NumLike, reason?: {
        isForChange?: boolean;
    });
}
export declare class ErrorTransactionInsufficientCoin extends Error {
    readonly amount: Num;
    readonly type: Script;
    constructor(amountLike: NumLike, typeLike: ScriptLike);
}
//# sourceMappingURL=transactionErrors.d.ts.map