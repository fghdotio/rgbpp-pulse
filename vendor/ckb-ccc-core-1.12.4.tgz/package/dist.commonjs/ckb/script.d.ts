import { Bytes, BytesLike } from "../bytes/index.js";
import type { Client } from "../client/index.js";
import { KnownScript } from "../client/knownScript.js";
import { Codec } from "../codec/index.js";
import { Hex, HexLike } from "../hex/index.js";
export declare const HashTypeCodec: Codec<HashTypeLike, HashType>;
/**
 * @public
 */
export type HashTypeLike = string | number | bigint;
/**
 * @public
 */
export type HashType = "type" | "data" | "data1" | "data2";
/**
 * Converts a HashTypeLike value to a HashType.
 * @public
 *
 * @param val - The value to convert, which can be a string, number, or bigint.
 * @returns The corresponding HashType.
 *
 * @throws Will throw an error if the input value is not a valid hash type.
 *
 * @example
 * ```typescript
 * const hashType = hashTypeFrom(1); // Outputs "data"
 * const hashType = hashTypeFrom("type"); // Outputs "type"
 * ```
 */
export declare function hashTypeFrom(val: HashTypeLike): HashType;
/**
 * Converts a HashTypeLike value to its corresponding byte representation.
 * @public
 *
 * @param hashType - The hash type value to convert.
 * @returns A Uint8Array containing the byte representation of the hash type.
 *
 * @example
 * ```typescript
 * const hashTypeBytes = hashTypeToBytes("type"); // Outputs Uint8Array [0]
 * ```
 */
export declare function hashTypeToBytes(hashType: HashTypeLike): Bytes;
/**
 * Converts a byte-like value to a HashType.
 * @public
 *
 * @param bytes - The byte-like value to convert.
 * @returns The corresponding HashType.
 *
 * @throws Will throw an error if the input bytes do not correspond to a valid hash type.
 *
 * @example
 * ```typescript
 * const hashType = hashTypeFromBytes(new Uint8Array([0])); // Outputs "type"
 * ```
 */
export declare function hashTypeFromBytes(bytes: BytesLike): HashType;
/**
 * @public
 */
export type ScriptLike = {
    codeHash: BytesLike;
    hashType: HashTypeLike;
    args: BytesLike;
};
declare const Script_base: (abstract new () => {
    toBytes(): Bytes;
    clone(): Script;
    eq(other: ScriptLike): boolean;
    hash(): Hex;
    toHex(): Hex;
}) & {
    byteLength?: number;
    encode(_: ScriptLike): Bytes;
    decode(_: BytesLike): Script;
    fromBytes(_bytes: BytesLike): Script;
    from(_: ScriptLike): Script;
};
/**
 * @public
 */
export declare class Script extends Script_base {
    codeHash: Hex;
    hashType: HashType;
    args: Hex;
    /**
     * Creates an instance of Script.
     *
     * @param codeHash - The code hash of the script.
     * @param hashType - The hash type of the script.
     * @param args - The arguments for the script.
     */
    constructor(codeHash: Hex, hashType: HashType, args: Hex);
    get occupiedSize(): number;
    /**
     * Clone a script.
     *
     * @returns A cloned Script instance.
     *
     * @example
     * ```typescript
     * const script1 = script0.clone();
     * ```
     */
    clone(): Script;
    /**
     * Check if the script is equal to another script.
     * @public
     * @param other - The other script to compare with
     * @returns True if the scripts are equal, false otherwise
     *
     * @example
     * ```typescript
     * const isEqual = script0.eq(script1);
     * ```
     */
    eq(other: ScriptLike): boolean;
    /**
     * Creates a Script instance from a ScriptLike object.
     *
     * @param script - A ScriptLike object or an instance of Script.
     * @returns A Script instance.
     *
     * @example
     * ```typescript
     * const script = Script.from({
     *   codeHash: "0x1234...",
     *   hashType: "type",
     *   args: "0xabcd..."
     * });
     * ```
     */
    static from(script: ScriptLike): Script;
    /**
     * Creates a Script instance from client and known script.
     *
     * @param knownScript - A KnownScript enum.
     * @param args - Args for the script.
     * @param client - A ScriptLike object or an instance of Script.
     * @returns A promise that resolves to the script instance.
     *
     * @example
     * ```typescript
     * const script = await Script.fromKnownScript(
     *   client,
     *   KnownScript.XUdt,
     *   args: "0xabcd..."
     * );
     * ```
     */
    static fromKnownScript(client: Client, knownScript: KnownScript, args: HexLike): Promise<Script>;
}
export declare const ScriptOpt: Codec<ScriptLike | null | undefined, Script | undefined>;
export declare const ScriptVec: Codec<ScriptLike[], Script[]>;
export {};
//# sourceMappingURL=script.d.ts.map