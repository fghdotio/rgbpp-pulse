import { Bytes, BytesLike } from "../bytes/index.js";
import type { ClientCollectableSearchKeyFilterLike } from "../client/clientTypes.advanced.js";
import { ClientBlockHeader, type CellDepInfoLike, type Client, type ClientBlockHeaderLike } from "../client/index.js";
import { KnownScript } from "../client/knownScript.js";
import { Codec } from "../codec/index.js";
import { Hasher } from "../hasher/index.js";
import { Hex, HexLike } from "../hex/index.js";
import { mol } from "../molecule/index.js";
import { Num, NumLike } from "../num/index.js";
import type { Signer } from "../signer/index.js";
import { Epoch } from "./epoch.js";
import { Script, ScriptLike } from "./script.js";
import type { LumosTransactionSkeletonType } from "./transactionLumos.js";
export declare const DepTypeCodec: Codec<DepTypeLike, DepType>;
/**
 * @public
 */
export type DepTypeLike = string | number | bigint;
/**
 * @public
 */
export type DepType = "depGroup" | "code";
/**
 * Converts a DepTypeLike value to a DepType.
 * @public
 *
 * @param val - The value to convert, which can be a string, number, or bigint.
 * @returns The corresponding DepType.
 *
 * @throws Will throw an error if the input value is not a valid dep type.
 *
 * @example
 * ```typescript
 * const depType = depTypeFrom(1); // Outputs "code"
 * const depType = depTypeFrom("depGroup"); // Outputs "depGroup"
 * ```
 */
export declare function depTypeFrom(val: DepTypeLike): DepType;
/**
 * Converts a DepTypeLike value to its corresponding byte representation.
 * @public
 *
 * @param depType - The dep type value to convert.
 * @returns A Uint8Array containing the byte representation of the dep type.
 *
 * @example
 * ```typescript
 * const depTypeBytes = depTypeToBytes("code"); // Outputs Uint8Array [1]
 * ```
 */
export declare function depTypeToBytes(depType: DepTypeLike): Bytes;
/**
 * Converts a byte-like value to a DepType.
 * @public
 *
 * @param bytes - The byte-like value to convert.
 * @returns The corresponding DepType.
 *
 * @throws Will throw an error if the input bytes do not correspond to a valid dep type.
 *
 * @example
 * ```typescript
 * const depType = depTypeFromBytes(new Uint8Array([1])); // Outputs "code"
 * ```
 */
export declare function depTypeFromBytes(bytes: BytesLike): DepType;
/**
 * @public
 */
export type OutPointLike = {
    txHash: HexLike;
    index: NumLike;
};
declare const OutPoint_base: (abstract new () => {
    toBytes(): Bytes;
    clone(): OutPoint;
    eq(other: OutPointLike): boolean;
    hash(): Hex;
    toHex(): Hex;
}) & {
    byteLength?: number;
    encode(_: OutPointLike): Bytes;
    decode(_: BytesLike): OutPoint;
    fromBytes(_bytes: BytesLike): OutPoint;
    from(_: OutPointLike): OutPoint;
};
/**
 * @public
 */
export declare class OutPoint extends OutPoint_base {
    txHash: Hex;
    index: Num;
    /**
     * Creates an instance of OutPoint.
     *
     * @param txHash - The transaction hash.
     * @param index - The index of the output in the transaction.
     */
    constructor(txHash: Hex, index: Num);
    /**
     * Creates an OutPoint instance from an OutPointLike object.
     *
     * @param outPoint - An OutPointLike object or an instance of OutPoint.
     * @returns An OutPoint instance.
     *
     * @example
     * ```typescript
     * const outPoint = OutPoint.from({ txHash: "0x...", index: 0 });
     * ```
     */
    static from(outPoint: OutPointLike): OutPoint;
    /**
     * Clone a OutPoint.
     *
     * @returns A cloned OutPoint instance.
     *
     * @example
     * ```typescript
     * const outPoint1 = outPoint0.clone();
     * ```
     */
    clone(): OutPoint;
    /**
     * Check if the OutPoint is equal to another OutPoint.
     * @public
     * @param other - The other OutPoint to compare with
     * @returns True if the OutPoints are equal, false otherwise
     *
     * @example
     * ```typescript
     * const isEqual = outPoint0.eq(outPoint1);
     * ```
     */
    eq(other: OutPointLike): boolean;
}
/**
 * @public
 */
export type CellOutputLike = {
    capacity?: NumLike | null;
    lock: ScriptLike;
    type?: ScriptLike | null;
};
declare const CellOutput_base: (abstract new () => {
    toBytes(): Bytes;
    clone(): CellOutput;
    eq(other: CellOutputLike): boolean;
    hash(): Hex;
    toHex(): Hex;
}) & {
    byteLength?: number;
    encode(_: CellOutputLike): Bytes;
    decode(_: BytesLike): CellOutput;
    fromBytes(_bytes: BytesLike): CellOutput;
    from(_: CellOutputLike): CellOutput;
};
/**
 * @public
 */
export declare class CellOutput extends CellOutput_base {
    capacity: Num;
    lock: Script;
    type?: Script | undefined;
    /**
     * Creates an instance of CellOutput.
     *
     * @param capacity - The capacity of the cell.
     * @param lock - The lock script of the cell.
     * @param type - The optional type script of the cell.
     */
    constructor(capacity: Num, lock: Script, type?: Script | undefined);
    get occupiedSize(): number;
    /**
     * Creates a CellOutput instance from a CellOutputLike object.
     * This method supports automatic capacity calculation when outputData is provided and capacity is 0 or omitted.
     *
     * @param cellOutput - A CellOutputLike object or an instance of CellOutput.
     * @param outputData - Optional output data used for automatic capacity calculation.
     *                     When provided and capacity is 0, the capacity will be calculated
     *                     as occupiedSize + outputData.length.
     * @returns A CellOutput instance.
     *
     * @example
     * ```typescript
     * // Basic usage with explicit capacity
     * const cellOutput1 = CellOutput.from({
     *   capacity: 1000n,
     *   lock: { codeHash: "0x...", hashType: "type", args: "0x..." },
     *   type: { codeHash: "0x...", hashType: "type", args: "0x..." }
     * });
     *
     * // Automatic capacity calculation
     * const cellOutput2 = CellOutput.from({
     *   lock: { codeHash: "0x...", hashType: "type", args: "0x..." }
     * }, "0x1234"); // Capacity will be calculated automatically
     * ```
     */
    static from(cellOutput: CellOutputLike, outputData?: HexLike | null): CellOutput;
    /**
     * Clone a CellOutput.
     *
     * @returns A cloned CellOutput instance.
     *
     * @example
     * ```typescript
     * const cellOutput1 = cellOutput0.clone();
     * ```
     */
    clone(): CellOutput;
}
export declare const CellOutputVec: Codec<CellOutputLike[], CellOutput[]>;
/**
 * @public
 * Represents a cell-like object that may or may not be on-chain.
 * It can optionally have an `outPoint` (or `previousOutput`).
 * This is used as a flexible input for creating `CellAny` instances.
 * @see CellAny
 */
export type CellAnyLike = {
    outPoint?: OutPointLike | null;
    previousOutput?: OutPointLike | null;
    cellOutput: CellOutputLike;
    outputData?: HexLike | null;
};
/**
 * Represents a CKB cell that can be either on-chain (with an `outPoint`) or off-chain (without an `outPoint`).
 * This class provides a unified interface for handling cells before they are included in a transaction,
 * or for cells that are already part of the blockchain state.
 *
 * @public
 */
export declare class CellAny {
    cellOutput: CellOutput;
    outputData: Hex;
    outPoint: OutPoint | undefined;
    /**
     * Creates an instance of CellAny.
     *
     * @param cellOutput - The cell output of the cell.
     * @param outputData - The output data of the cell.
     * @param outPoint - The optional output point of the cell. If provided, the cell is considered on-chain.
     */
    constructor(cellOutput: CellOutput, outputData: Hex, outPoint?: OutPoint);
    /**
     * Creates a `CellAny` instance from a `CellAnyLike` object.
     * This factory method provides a convenient way to create `CellAny` instances
     * from plain objects, automatically handling the optional `outPoint` or `previousOutput`.
     *
     * @param cell - A `CellAnyLike` object.
     * @returns A new `CellAny` instance.
     *
     * @example
     * ```typescript
     * // Create an off-chain cell (e.g., a new output)
     * const offChainCell = CellAny.from({
     *   cellOutput: { capacity: 1000n, lock: lockScript },
     *   outputData: "0x"
     * });
     *
     * // Create an on-chain cell from an input
     * const onChainCell = CellAny.from({
     *   outPoint: { txHash: "0x...", index: 0 },
     *   cellOutput: { capacity: 2000n, lock: lockScript },
     *   outputData: "0x1234"
     * });
     * ```
     */
    static from(cell: CellAnyLike): CellAny;
    /**
     * Calculates the total occupied size of the cell in bytes.
     * This includes the size of the `CellOutput` structure plus the size of the `outputData`.
     *
     * @returns The total occupied size in bytes.
     */
    get occupiedSize(): number;
    /**
     * Calculates the free capacity of the cell.
     * Free capacity is the total capacity minus the capacity occupied by the cell's structure and data.
     *
     * @returns The free capacity in shannons as a `Num`.
     */
    get capacityFree(): bigint;
    /**
     * Checks if the cell is a Nervos DAO cell and optionally checks its phase.
     *
     * @param client - A CKB client instance to fetch known script information.
     * @param phase - Optional phase to check: "deposited" or "withdrew".
     *                If omitted, it checks if the cell is a DAO cell regardless of phase.
     * @returns A promise that resolves to `true` if the cell is a matching Nervos DAO cell, `false` otherwise.
     */
    isNervosDao(client: Client, phase?: "deposited" | "withdrew"): Promise<boolean>;
    /**
     * Clones the `CellAny` instance.
     *
     * @returns A new `CellAny` instance that is a deep copy of the current one.
     *
     * @example
     * ```typescript
     * const clonedCell = cellAny.clone();
     * ```
     */
    clone(): CellAny;
}
/**
 * Represents a cell-like object that is guaranteed to be on-chain.
 * It must have an `outPoint` (or its alias `previousOutput`).
 * This is used as a type constraint for creating `Cell` instances.
 * @see Cell
 * @public
 */
export type CellLike = CellAnyLike & ({
    outPoint: OutPointLike;
    previousOutput?: undefined | null;
} | {
    outPoint?: undefined | null;
    previousOutput: OutPointLike;
});
/**
 * Represents an on-chain CKB cell, which is a `CellAny` that is guaranteed to have an `outPoint`.
 * This class is typically used for cells that are already part of the blockchain state, such as transaction inputs.
 * @public
 */
export declare class Cell extends CellAny {
    outPoint: OutPoint;
    /**
     * Creates an instance of an on-chain Cell.
     *
     * @param outPoint - The output point of the cell.
     * @param cellOutput - The cell output of the cell.
     * @param outputData - The output data of the cell.
     */
    constructor(outPoint: OutPoint, cellOutput: CellOutput, outputData: Hex);
    /**
     * Creates a Cell instance from a CellLike object.
     * This method accepts either `outPoint` or `previousOutput` to specify the cell's location,
     * and supports automatic capacity calculation for the cell output.
     *
     * @param cell - A CellLike object or an instance of Cell. The object can use either:
     *               - `outPoint`: For referencing a cell output
     *               - `previousOutput`: For referencing a cell input (alternative name for outPoint)
     *               The cellOutput can omit capacity for automatic calculation.
     * @returns A Cell instance.
     *
     * @example
     * ```typescript
     * // Using outPoint with explicit capacity
     * const cell1 = Cell.from({
     *   outPoint: { txHash: "0x...", index: 0 },
     *   cellOutput: {
     *     capacity: 1000n,
     *     lock: { codeHash: "0x...", hashType: "type", args: "0x..." }
     *   },
     *   outputData: "0x"
     * });
     *
     * // Using previousOutput with automatic capacity calculation
     * const cell2 = Cell.from({
     *   previousOutput: { txHash: "0x...", index: 0 },
     *   cellOutput: {
     *     lock: { codeHash: "0x...", hashType: "type", args: "0x..." }
     *     // capacity will be calculated automatically
     *   },
     *   outputData: "0x1234"
     * });
     * ```
     */
    static from(cell: CellLike): Cell;
    /**
     * Gets confirmed Nervos DAO profit of a Cell
     * It returns non-zero value only when the cell is in withdrawal phase 2
     * See https://github.com/nervosnetwork/rfcs/blob/master/rfcs/0023-dao-deposit-withdraw/0023-dao-deposit-withdraw.md
     *
     * @param client - A client for searching DAO related headers
     * @returns Profit
     *
     * @example
     * ```typescript
     * const profit = await cell.getDaoProfit(client);
     * ```
     */
    getDaoProfit(client: Client): Promise<Num>;
    /**
     * Retrieves detailed information about a Nervos DAO cell, including its deposit and withdrawal headers.
     *
     * @param client - A CKB client instance to fetch cell and header data.
     * @returns A promise that resolves to an object containing header information.
     *          - If not a DAO cell, returns `{}`.
     *          - If a deposited DAO cell, returns `{ depositHeader }`.
     *          - If a withdrawn DAO cell, returns `{ depositHeader, withdrawHeader }`.
     *
     * @throws If the cell is a DAO cell but its corresponding headers cannot be fetched.
     *
     * @example
     * ```typescript
     * const daoInfo = await cell.getNervosDaoInfo(client);
     * ```
     */
    getNervosDaoInfo(client: Client): Promise<{
        depositHeader?: undefined;
        withdrawHeader?: undefined;
    } | {
        depositHeader: ClientBlockHeader;
        withdrawHeader?: undefined;
    } | {
        depositHeader: ClientBlockHeader;
        withdrawHeader: ClientBlockHeader;
    }>;
    /**
     * Clone a Cell
     *
     * @returns A cloned Cell instance.
     *
     * @example
     * ```typescript
     * const cell1 = cell0.clone();
     * ```
     */
    clone(): Cell;
}
/**
 * @public
 */
export type SinceLike = {
    relative: "absolute" | "relative";
    metric: "blockNumber" | "epoch" | "timestamp";
    value: NumLike;
} | NumLike;
declare const Since_base: (abstract new () => {
    toBytes(): Bytes;
    clone(): Since;
    eq(other: SinceLike): boolean;
    hash(): Hex;
    toHex(): Hex;
}) & {
    byteLength?: number;
    encode(_: SinceLike): Bytes;
    decode(_: BytesLike): Since;
    fromBytes(_bytes: BytesLike): Since;
    from(_: SinceLike): Since;
};
/**
 * @public
 */
export declare class Since extends Since_base {
    relative: "absolute" | "relative";
    metric: "blockNumber" | "epoch" | "timestamp";
    value: Num;
    /**
     * Creates an instance of Since.
     *
     * @param relative - Absolute or relative
     * @param metric - The metric of since
     * @param value - The value of since
     */
    constructor(relative: "absolute" | "relative", metric: "blockNumber" | "epoch" | "timestamp", value: Num);
    /**
     * Clone a Since.
     *
     * @returns A cloned Since instance.
     *
     * @example
     * ```typescript
     * const since1 = since0.clone();
     * ```
     */
    clone(): Since;
    /**
     * Creates a Since instance from a SinceLike object.
     *
     * @param since - A SinceLike object or an instance of Since.
     * @returns A Since instance.
     *
     * @example
     * ```typescript
     * const since = Since.from("0x1234567812345678");
     * ```
     */
    static from(since: SinceLike): Since;
    /**
     * Converts the Since instance to num.
     *
     * @returns A num
     *
     * @example
     * ```typescript
     * const num = since.toNum();
     * ```
     */
    toNum(): Num;
    /**
     * Creates a Since instance from a num-like value.
     *
     * @param numLike - The num-like value to convert.
     * @returns A Since instance.
     *
     * @example
     * ```typescript
     * const since = Since.fromNum("0x0");
     * ```
     */
    static fromNum(numLike: NumLike): Since;
}
/**
 * @public
 */
export type CellInputLike = ({
    previousOutput: OutPointLike;
} | {
    outPoint: OutPointLike;
}) & {
    since?: SinceLike | NumLike | null;
    cellOutput?: CellOutputLike | null;
    outputData?: HexLike | null;
};
declare const CellInput_base: (abstract new () => {
    toBytes(): Bytes;
    clone(): CellInput;
    eq(other: CellInputLike): boolean;
    hash(): Hex;
    toHex(): Hex;
}) & {
    byteLength?: number;
    encode(_: CellInputLike): Bytes;
    decode(_: BytesLike): CellInput;
    fromBytes(_bytes: BytesLike): CellInput;
    from(_: CellInputLike): CellInput;
};
/**
 * @public
 */
export declare class CellInput extends CellInput_base {
    previousOutput: OutPoint;
    since: Num;
    cellOutput?: CellOutput | undefined;
    outputData?: Hex | undefined;
    /**
     * Creates an instance of CellInput.
     *
     * @param previousOutput - The previous outpoint of the cell.
     * @param since - The since value of the cell input.
     * @param cellOutput - The optional cell output associated with the cell input.
     * @param outputData - The optional output data associated with the cell input.
     */
    constructor(previousOutput: OutPoint, since: Num, cellOutput?: CellOutput | undefined, outputData?: Hex | undefined);
    /**
     * Creates a CellInput instance from a CellInputLike object.
     *
     * @param cellInput - A CellInputLike object or an instance of CellInput.
     * @returns A CellInput instance.
     *
     * @example
     * ```typescript
     * const cellInput = CellInput.from({
     *   previousOutput: { txHash: "0x...", index: 0 },
     *   since: 0n
     * });
     * ```
     */
    static from(cellInput: CellInputLike): CellInput;
    getCell(client: Client): Promise<Cell>;
    /**
     * Complete extra infos in the input. Including
     * - Previous cell output
     * - Previous cell data
     * The instance will be modified.
     *
     * @returns true if succeed.
     * @example
     * ```typescript
     * await cellInput.completeExtraInfos(client);
     * ```
     */
    completeExtraInfos(client: Client): Promise<void>;
    /**
     * The extra capacity created when consume this input.
     * This is usually NervosDAO interest, see https://github.com/nervosnetwork/rfcs/blob/master/rfcs/0023-dao-deposit-withdraw/0023-dao-deposit-withdraw.md.
     * And it can also be miners' income. (But this is not implemented yet)
     */
    getExtraCapacity(client: Client): Promise<Num>;
    /**
     * Clone a CellInput.
     *
     * @returns A cloned CellInput instance.
     *
     * @example
     * ```typescript
     * const cellInput1 = cellInput0.clone();
     * ```
     */
    clone(): CellInput;
}
export declare const CellInputVec: Codec<CellInputLike[], CellInput[]>;
/**
 * @public
 */
export type CellDepLike = {
    outPoint: OutPointLike;
    depType: DepTypeLike;
};
declare const CellDep_base: (abstract new () => {
    toBytes(): Bytes;
    clone(): CellDep;
    eq(other: CellDepLike): boolean;
    hash(): Hex;
    toHex(): Hex;
}) & {
    byteLength?: number;
    encode(_: CellDepLike): Bytes;
    decode(_: BytesLike): CellDep;
    fromBytes(_bytes: BytesLike): CellDep;
    from(_: CellDepLike): CellDep;
};
/**
 * @public
 */
export declare class CellDep extends CellDep_base {
    outPoint: OutPoint;
    depType: DepType;
    /**
     * Creates an instance of CellDep.
     *
     * @param outPoint - The outpoint of the cell dependency.
     * @param depType - The dependency type.
     */
    constructor(outPoint: OutPoint, depType: DepType);
    /**
     * Creates a CellDep instance from a CellDepLike object.
     *
     * @param cellDep - A CellDepLike object or an instance of CellDep.
     * @returns A CellDep instance.
     *
     * @example
     * ```typescript
     * const cellDep = CellDep.from({
     *   outPoint: { txHash: "0x...", index: 0 },
     *   depType: "depGroup"
     * });
     * ```
     */
    static from(cellDep: CellDepLike): CellDep;
    /**
     * Clone a CellDep.
     *
     * @returns A cloned CellDep instance.
     *
     * @example
     * ```typescript
     * const cellDep1 = cellDep0.clone();
     * ```
     */
    clone(): CellDep;
}
export declare const CellDepVec: Codec<CellDepLike[], CellDep[]>;
/**
 * @public
 */
export type WitnessArgsLike = {
    lock?: HexLike | null;
    inputType?: HexLike | null;
    outputType?: HexLike | null;
};
declare const WitnessArgs_base: (abstract new () => {
    toBytes(): Bytes;
    clone(): WitnessArgs;
    eq(other: WitnessArgsLike): boolean;
    hash(): Hex;
    toHex(): Hex;
}) & {
    byteLength?: number;
    encode(_: WitnessArgsLike): Bytes;
    decode(_: BytesLike): WitnessArgs;
    fromBytes(_bytes: BytesLike): WitnessArgs;
    from(_: WitnessArgsLike): WitnessArgs;
};
/**
 * @public
 */
export declare class WitnessArgs extends WitnessArgs_base {
    lock?: Hex | undefined;
    inputType?: Hex | undefined;
    outputType?: Hex | undefined;
    /**
     * Creates an instance of WitnessArgs.
     *
     * @param lock - The optional lock field of the witness.
     * @param inputType - The optional input type field of the witness.
     * @param outputType - The optional output type field of the witness.
     */
    constructor(lock?: Hex | undefined, inputType?: Hex | undefined, outputType?: Hex | undefined);
    /**
     * Creates a WitnessArgs instance from a WitnessArgsLike object.
     *
     * @param witnessArgs - A WitnessArgsLike object or an instance of WitnessArgs.
     * @returns A WitnessArgs instance.
     *
     * @example
     * ```typescript
     * const witnessArgs = WitnessArgs.from({
     *   lock: "0x...",
     *   inputType: "0x...",
     *   outputType: "0x..."
     * });
     * ```
     */
    static from(witnessArgs: WitnessArgsLike): WitnessArgs;
}
/**
 * Convert a bytes to a num.
 *
 * @public
 */
export declare function udtBalanceFrom(dataLike: BytesLike): Num;
export declare const RawTransaction: Codec<mol.EncodableRecord<{
    version: Codec<NumLike, number>;
    cellDeps: Codec<CellDepLike[], CellDep[]>;
    headerDeps: Codec<BytesLike[], `0x${string}`[]>;
    inputs: Codec<CellInputLike[], CellInput[]>;
    outputs: Codec<CellOutputLike[], CellOutput[]>;
    outputsData: Codec<BytesLike[], `0x${string}`[]>;
}>, mol.DecodedRecord<{
    version: Codec<NumLike, number>;
    cellDeps: Codec<CellDepLike[], CellDep[]>;
    headerDeps: Codec<BytesLike[], `0x${string}`[]>;
    inputs: Codec<CellInputLike[], CellInput[]>;
    outputs: Codec<CellOutputLike[], CellOutput[]>;
    outputsData: Codec<BytesLike[], `0x${string}`[]>;
}>>;
/**
 * @public
 */
export type TransactionLike = {
    version?: NumLike | null;
    cellDeps?: CellDepLike[] | null;
    headerDeps?: HexLike[] | null;
    inputs?: CellInputLike[] | null;
    outputs?: (Omit<CellOutputLike, "capacity"> & Partial<Pick<CellOutputLike, "capacity">>)[] | null;
    outputsData?: HexLike[] | null;
    witnesses?: HexLike[] | null;
};
declare const Transaction_base: (abstract new () => {
    toBytes(): Bytes;
    clone(): Transaction;
    eq(other: TransactionLike): boolean;
    hash(): Hex;
    toHex(): Hex;
}) & {
    byteLength?: number;
    encode(_: TransactionLike): Bytes;
    decode(_: BytesLike): Transaction;
    fromBytes(_bytes: BytesLike): Transaction;
    from(_: TransactionLike): Transaction;
};
/**
 * @public
 */
export declare class Transaction extends Transaction_base {
    version: Num;
    cellDeps: CellDep[];
    headerDeps: Hex[];
    inputs: CellInput[];
    outputs: CellOutput[];
    outputsData: Hex[];
    witnesses: Hex[];
    /**
     * Creates an instance of Transaction.
     *
     * @param version - The version of the transaction.
     * @param cellDeps - The cell dependencies of the transaction.
     * @param headerDeps - The header dependencies of the transaction.
     * @param inputs - The inputs of the transaction.
     * @param outputs - The outputs of the transaction.
     * @param outputsData - The data associated with the outputs.
     * @param witnesses - The witnesses of the transaction.
     */
    constructor(version: Num, cellDeps: CellDep[], headerDeps: Hex[], inputs: CellInput[], outputs: CellOutput[], outputsData: Hex[], witnesses: Hex[]);
    /**
     * Creates a default Transaction instance with empty fields.
     *
     * @returns A default Transaction instance.
     *
     * @example
     * ```typescript
     * const defaultTx = Transaction.default();
     * ```
     */
    static default(): Transaction;
    /**
     * Copy every properties from another transaction.
     * This method replaces all properties of the current transaction with those from the provided transaction.
     *
     * @param txLike - The transaction-like object to copy properties from.
     *
     * @example
     * ```typescript
     * this.copy(Transaction.default());
     * ```
     */
    copy(txLike: TransactionLike): void;
    /**
     * Creates a deep copy of the transaction.
     * This method creates a new Transaction instance with all nested objects cloned,
     * ensuring that modifications to the cloned transaction do not affect the original.
     *
     * @returns A new Transaction instance that is a deep copy of the current transaction.
     *
     * @example
     * ```typescript
     * const originalTx = Transaction.from({
     *   version: 0,
     *   inputs: [{ previousOutput: { txHash: "0x...", index: 0 } }],
     *   outputs: [{ capacity: 1000n, lock: lockScript }],
     *   outputsData: ["0x"],
     *   witnesses: ["0x"]
     * });
     *
     * const clonedTx = originalTx.clone();
     *
     * // Modifications to clonedTx won't affect originalTx
     * clonedTx.addOutput({ capacity: 2000n, lock: anotherLockScript });
     * console.log(originalTx.outputs.length); // Still 1
     * console.log(clonedTx.outputs.length);   // Now 2
     * ```
     *
     * @remarks
     * The clone operation performs deep copying for:
     * - Cell dependencies (cellDeps) - each CellDep is cloned
     * - Inputs - each CellInput is cloned
     * - Outputs - each CellOutput is cloned
     *
     * The following are shallow copied (references to immutable data):
     * - Header dependencies (headerDeps) - Hex strings are immutable
     * - Output data (outputsData) - Hex strings are immutable
     * - Witnesses - Hex strings are immutable
     * - Version - bigint is immutable
     */
    clone(): Transaction;
    /**
     * Creates a Transaction instance from a TransactionLike object.
     *
     * @param tx - A TransactionLike object or an instance of Transaction.
     * @returns A Transaction instance.
     *
     * @example
     * ```typescript
     * const transaction = Transaction.from({
     *   version: 0,
     *   cellDeps: [],
     *   headerDeps: [],
     *   inputs: [],
     *   outputs: [],
     *   outputsData: [],
     *   witnesses: []
     * });
     * ```
     */
    static from(tx: TransactionLike): Transaction;
    /**
     * Creates a Transaction instance from a Lumos skeleton.
     *
     * @param skeleton - The Lumos transaction skeleton.
     * @returns A Transaction instance.
     *
     * @throws Will throw an error if an input's outPoint is missing.
     *
     * @example
     * ```typescript
     * const transaction = Transaction.fromLumosSkeleton(skeleton);
     * ```
     */
    static fromLumosSkeleton(skeleton: LumosTransactionSkeletonType): Transaction;
    /**
     * @deprecated
     * Use ccc.stringify instead.
     * stringify the tx to JSON string.
     */
    stringify(): string;
    /**
     * Converts the raw transaction data to bytes.
     *
     * @returns A Uint8Array containing the raw transaction bytes.
     *
     * @example
     * ```typescript
     * const rawTxBytes = transaction.rawToBytes();
     * ```
     */
    rawToBytes(): Bytes;
    /**
     * Calculates the hash of the transaction without witnesses. This is the transaction hash in the usual sense.
     * To calculate the hash of the whole transaction including the witnesses, use transaction.hashFull() instead.
     *
     * @returns The hash of the transaction.
     *
     * @example
     * ```typescript
     * const txHash = transaction.hash();
     * ```
     */
    hash(): Hex;
    /**
     * Calculates the hash of the transaction with witnesses.
     *
     * @returns The hash of the transaction with witnesses.
     *
     * @example
     * ```typescript
     * const txFullHash = transaction.hashFull();
     * ```
     */
    hashFull(): Hex;
    /**
     * Hashes a witness and updates the hasher.
     *
     * @param witness - The witness to hash.
     * @param hasher - The hasher instance to update.
     *
     * @example
     * ```typescript
     * Transaction.hashWitnessToHasher("0x...", hasher);
     * ```
     */
    static hashWitnessToHasher(witness: HexLike, hasher: Hasher): void;
    /**
     * Computes the signing hash information for a given script.
     *
     * @param scriptLike - The script associated with the transaction, represented as a ScriptLike object.
     * @param client - The client for complete extra infos in the transaction.
     * @returns A promise that resolves to an object containing the signing message and the witness position,
     *          or undefined if no matching input is found.
     *
     * @example
     * ```typescript
     * const signHashInfo = await tx.getSignHashInfo(scriptLike, client);
     * if (signHashInfo) {
     *   console.log(signHashInfo.message); // Outputs the signing message
     *   console.log(signHashInfo.position); // Outputs the witness position
     * }
     * ```
     */
    getSignHashInfo(scriptLike: ScriptLike, client: Client, hasher?: Hasher): Promise<{
        message: Hex;
        position: number;
    } | undefined>;
    /**
     * Find the first occurrence of a input with the specified lock id
     *
     * @param scriptIdLike - The script associated with the transaction, represented as a ScriptLike object without args.
     * @param client - The client for complete extra infos in the transaction.
     * @returns A promise that resolves to the found index
     *
     * @example
     * ```typescript
     * const index = await tx.findInputIndexByLockId(scriptIdLike, client);
     * ```
     */
    findInputIndexByLockId(scriptIdLike: Pick<ScriptLike, "codeHash" | "hashType">, client: Client): Promise<number | undefined>;
    /**
     * Find the first occurrence of a input with the specified lock
     *
     * @param scriptLike - The script associated with the transaction, represented as a ScriptLike object.
     * @param client - The client for complete extra infos in the transaction.
     * @returns A promise that resolves to the found index, or undefined if no matching input is found.
     *
     * @example
     * ```typescript
     * const index = await tx.findInputIndexByLock(scriptLike, client);
     * ```
     */
    findInputIndexByLock(scriptLike: ScriptLike, client: Client): Promise<number | undefined>;
    /**
     * Find the last occurrence of a input with the specified lock
     *
     * @param scriptLike - The script associated with the transaction, represented as a ScriptLike object.
     * @param client - The client for complete extra infos in the transaction.
     * @returns A promise that resolves to the found index, or undefined if no matching input is found.
     *
     * @example
     * ```typescript
     * const index = await tx.findLastInputIndexByLock(scriptLike, client);
     * ```
     */
    findLastInputIndexByLock(scriptLike: ScriptLike, client: Client): Promise<number | undefined>;
    /**
     * Add cell deps if they are not existed
     *
     * @param cellDepLikes - The cell deps to add
     *
     * @example
     * ```typescript
     * tx.addCellDeps(cellDep);
     * ```
     */
    addCellDeps(...cellDepLikes: (CellDepLike | CellDepLike[])[]): void;
    /**
     * Add cell deps at the start if they are not existed
     *
     * @param cellDepLikes - The cell deps to add
     *
     * @example
     * ```typescript
     * tx.addCellDepsAtBegin(cellDep);
     * ```
     */
    addCellDepsAtStart(...cellDepLikes: (CellDepLike | CellDepLike[])[]): void;
    /**
     * Add cell dep from infos if they are not existed
     *
     * @param client - A client for searching cell deps
     * @param cellDepInfoLikes - The cell dep infos to add
     *
     * @example
     * ```typescript
     * tx.addCellDepInfos(client, cellDepInfos);
     * ```
     */
    addCellDepInfos(client: Client, ...cellDepInfoLikes: (CellDepInfoLike | CellDepInfoLike[])[]): Promise<void>;
    /**
     * Add cell deps from known script
     *
     * @param client - The client for searching known script and cell deps
     * @param scripts - The known scripts to add
     *
     * @example
     * ```typescript
     * tx.addCellDepsOfKnownScripts(client, KnownScript.OmniLock);
     * ```
     */
    addCellDepsOfKnownScripts(client: Client, ...scripts: (KnownScript | KnownScript[])[]): Promise<void>;
    /**
     * Set output data at index.
     *
     * @param index - The index of the output data.
     * @param data - The data to set.
     *
     * @example
     * ```typescript
     * tx.setOutputDataAt(0, "0x00");
     * ```
     */
    setOutputDataAt(index: number, data: HexLike): void;
    /**
     * get input
     *
     * @param index - The cell input index
     *
     * @example
     * ```typescript
     * await tx.getInput(0);
     * ```
     */
    getInput(index: NumLike): CellInput | undefined;
    /**
     * add input
     *
     * @param inputLike - The cell input.
     *
     * @example
     * ```typescript
     * await tx.addInput({ });
     * ```
     */
    addInput(inputLike: CellInputLike): number;
    /**
     * get output
     *
     * @param index - The cell output index
     *
     * @example
     * ```typescript
     * await tx.getOutput(0);
     * ```
     */
    getOutput(index: NumLike): CellAny | undefined;
    /**
     * Provides an iterable over the transaction's output cells.
     *
     * This getter is a convenient way to iterate through all the output cells (`CellAny`)
     * of the transaction, combining the `outputs` and `outputsData` arrays.
     * It can be used with `for...of` loops or other iterable-consuming patterns.
     *
     * @public
     * @category Getter
     * @returns An `Iterable<CellAny>` that yields each output cell of the transaction.
     *
     * @example
     * ```typescript
     * for (const cell of tx.outputCells) {
     *   console.log(`Output cell capacity: ${cell.cellOutput.capacity}`);
     * }
     * ```
     */
    get outputCells(): Iterable<CellAny>;
    /**
     * Adds an output to the transaction.
     *
     * This method supports two overloads for adding an output:
     * 1. By providing a `CellAnyLike` object, which encapsulates both `cellOutput` and `outputData`.
     * 2. By providing a `CellOutputLike` object and an optional `outputData`.
     *
     * @param cellOrOutputLike - A cell-like object containing both cell output and data, or just the cell output object.
     * @param outputDataLike - Optional data for the cell output. Defaults to "0x" if not provided in the first argument.
     * @returns The new number of outputs in the transaction.
     *
     * @example
     * ```typescript
     * // 1. Add an output using a CellAnyLike object
     * const newLength1 = tx.addOutput({
     *   cellOutput: { lock: recipientLock }, // capacity is calculated automatically
     *   outputData: "0x1234",
     * });
     *
     * // 2. Add an output using CellOutputLike and data separately
     * const newLength2 = tx.addOutput({ lock: recipientLock }, "0xabcd");
     * ```
     */
    addOutput(cellLike: CellAnyLike): number;
    addOutput(outputLike: CellOutputLike, outputDataLike?: HexLike | null): number;
    /**
     * Get witness at index as WitnessArgs
     *
     * @param index - The index of the witness.
     * @returns The witness parsed as WitnessArgs.
     *
     * @example
     * ```typescript
     * const witnessArgs = await tx.getWitnessArgsAt(0);
     * ```
     */
    getWitnessArgsAt(index: number): WitnessArgs | undefined;
    /**
     * Set witness at index by WitnessArgs
     *
     * @param index - The index of the witness.
     * @param witness - The WitnessArgs to set.
     *
     * @example
     * ```typescript
     * await tx.setWitnessArgsAt(0, witnessArgs);
     * ```
     */
    setWitnessArgsAt(index: number, witness: WitnessArgs): void;
    /**
     * Set witness at index
     *
     * @param index - The index of the witness.
     * @param witness - The witness to set.
     *
     * @example
     * ```typescript
     * await tx.setWitnessAt(0, witness);
     * ```
     */
    setWitnessAt(index: number, witness: HexLike): void;
    /**
     * Prepare dummy witness for sighash all method
     *
     * @param scriptLike - The script associated with the transaction, represented as a ScriptLike object.
     * @param lockLen - The length of dummy lock bytes.
     * @param client - The client for complete extra infos in the transaction.
     * @returns A promise that resolves to the prepared transaction
     *
     * @example
     * ```typescript
     * await tx.prepareSighashAllWitness(scriptLike, 85, client);
     * ```
     */
    prepareSighashAllWitness(scriptLike: ScriptLike, lockLen: number, client: Client): Promise<void>;
    getInputsCapacityExtra(client: Client): Promise<Num>;
    getInputsCapacity(client: Client): Promise<Num>;
    getOutputsCapacity(): Num;
    getInputsUdtBalance(client: Client, type: ScriptLike): Promise<Num>;
    getOutputsUdtBalance(type: ScriptLike): Num;
    completeInputs<T>(from: Signer, filter: ClientCollectableSearchKeyFilterLike, accumulator: (acc: T, v: Cell, i: number, array: Cell[]) => Promise<T | undefined> | T | undefined, init: T): Promise<{
        addedCount: number;
        accumulated?: T;
    }>;
    completeInputsByCapacity(from: Signer, capacityTweak?: NumLike, filter?: ClientCollectableSearchKeyFilterLike): Promise<number>;
    completeInputsAll(from: Signer, filter?: ClientCollectableSearchKeyFilterLike): Promise<number>;
    /**
     * Complete inputs by UDT balance
     *
     * This method succeeds only if enough balance is collected.
     *
     * It will try to collect at least two inputs, even when the first input already contains enough balance, to avoid extra occupation fees introduced by the change cell. An edge case: If the first cell has the same amount as the output, a new cell is not needed.
     * @param from - The signer to complete the inputs.
     * @param type - The type script of the UDT.
     * @param balanceTweak - The tweak of the balance.
     * @returns A promise that resolves to the number of inputs added.
     */
    completeInputsByUdt(from: Signer, type: ScriptLike, balanceTweak?: NumLike): Promise<number>;
    completeInputsAddOne(from: Signer, filter?: ClientCollectableSearchKeyFilterLike): Promise<number>;
    completeInputsAtLeastOne(from: Signer, filter?: ClientCollectableSearchKeyFilterLike): Promise<number>;
    getFee(client: Client): Promise<Num>;
    getFeeRate(client: Client): Promise<Num>;
    estimateFee(feeRate: NumLike): Num;
    /**
     * Completes the transaction fee by adding inputs and handling change outputs.
     * This method automatically calculates the required fee based on the transaction size and fee rate,
     * adds necessary inputs to cover the fee, and handles change outputs through the provided change function.
     *
     * @param from - The signer to complete inputs from and prepare the transaction.
     * @param change - A function that handles change capacity. It receives the transaction and excess capacity,
     *                 and should return the additional capacity needed (0 if change is handled successfully,
     *                 positive number if more capacity is needed for change cell creation).
     * @param expectedFeeRate - The expected fee rate in shannons per 1000 bytes. If not provided,
     *                          it will be fetched from the client.
     * @param filter - Optional filter for selecting cells when adding inputs.
     * @param options - Optional configuration object.
     * @param options.feeRateBlockRange - Block range for fee rate calculation when expectedFeeRate is not provided.
     * @param options.maxFeeRate - Maximum allowed fee rate.
     * @param options.shouldAddInputs - Whether to add inputs automatically. Defaults to true.
     * @returns A promise that resolves to a tuple containing:
     *          - The number of inputs added during the process
     *          - A boolean indicating whether change outputs were created (true) or fee was paid without change (false)
     *
     * @throws {ErrorTransactionInsufficientCapacity} When there's not enough capacity to cover the fee.
     * @throws {Error} When the change function doesn't properly handle the available capacity.
     *
     * @example
     * ```typescript
     * const [addedInputs, hasChange] = await tx.completeFee(
     *   signer,
     *   (tx, capacity) => {
     *     if (capacity >= 61_00000000n) { // Minimum for a change cell
     *       tx.addOutput({ capacity, lock: changeScript });
     *       return 0;
     *     }
     *     return 61_00000000n; // Need more capacity for change cell
     *   },
     *   1000n // 1000 shannons per 1000 bytes
     * );
     * ```
     */
    completeFee(from: Signer, change: (tx: Transaction, capacity: Num) => Promise<NumLike> | NumLike, expectedFeeRate?: NumLike, filter?: ClientCollectableSearchKeyFilterLike, options?: {
        feeRateBlockRange?: NumLike;
        maxFeeRate?: NumLike;
        shouldAddInputs?: boolean;
    }): Promise<[number, boolean]>;
    /**
     * Completes the transaction fee by adding inputs and creating a change output with the specified lock script.
     * This is a convenience method that automatically creates a change cell with the provided lock script
     * when there's excess capacity after paying the transaction fee.
     *
     * @param from - The signer to complete inputs from and prepare the transaction.
     * @param change - The lock script for the change output cell.
     * @param feeRate - Optional fee rate in shannons per 1000 bytes. If not provided, it will be fetched from the client.
     * @param filter - Optional filter for selecting cells when adding inputs.
     * @param options - Optional configuration object.
     * @param options.feeRateBlockRange - Block range for fee rate calculation when feeRate is not provided.
     * @param options.maxFeeRate - Maximum allowed fee rate.
     * @param options.shouldAddInputs - Whether to add inputs automatically. Defaults to true.
     * @returns A promise that resolves to a tuple containing:
     *          - The number of inputs added during the process
     *          - A boolean indicating whether change outputs were created (true) or fee was paid without change (false)
     *
     * @example
     * ```typescript
     * const changeScript = Script.from({
     *   codeHash: "0x...",
     *   hashType: "type",
     *   args: "0x..."
     * });
     *
     * const [addedInputs, hasChange] = await tx.completeFeeChangeToLock(
     *   signer,
     *   changeScript,
     *   1000n // 1000 shannons per 1000 bytes
     * );
     * ```
     */
    completeFeeChangeToLock(from: Signer, change: ScriptLike, feeRate?: NumLike, filter?: ClientCollectableSearchKeyFilterLike, options?: {
        feeRateBlockRange?: NumLike;
        maxFeeRate?: NumLike;
        shouldAddInputs?: boolean;
    }): Promise<[number, boolean]>;
    /**
     * Completes the transaction fee using the signer's recommended address for change.
     * This is a convenience method that automatically uses the signer's recommended
     * address as the change destination, making it easier to complete transactions
     * without manually specifying a change address.
     *
     * @param from - The signer to complete inputs from and prepare the transaction.
     * @param feeRate - Optional fee rate in shannons per 1000 bytes. If not provided, it will be fetched from the client.
     * @param filter - Optional filter for selecting cells when adding inputs.
     * @param options - Optional configuration object.
     * @param options.feeRateBlockRange - Block range for fee rate calculation when feeRate is not provided.
     * @param options.maxFeeRate - Maximum allowed fee rate.
     * @param options.shouldAddInputs - Whether to add inputs automatically. Defaults to true.
     * @returns A promise that resolves to a tuple containing:
     *          - The number of inputs added during the process
     *          - A boolean indicating whether change outputs were created (true) or fee was paid without change (false)
     *
     * @example
     * ```typescript
     * const [addedInputs, hasChange] = await tx.completeFeeBy(
     *   signer,
     *   1000n // 1000 shannons per 1000 bytes
     * );
     *
     * // Change will automatically go to signer's recommended address
     * ```
     */
    completeFeeBy(from: Signer, feeRate?: NumLike, filter?: ClientCollectableSearchKeyFilterLike, options?: {
        feeRateBlockRange?: NumLike;
        maxFeeRate?: NumLike;
        shouldAddInputs?: boolean;
    }): Promise<[number, boolean]>;
    /**
     * Completes the transaction fee by adding excess capacity to an existing output.
     * Instead of creating a new change output, this method adds any excess capacity
     * to the specified existing output in the transaction.
     *
     * @param from - The signer to complete inputs from and prepare the transaction.
     * @param index - The index of the existing output to add excess capacity to.
     * @param feeRate - Optional fee rate in shannons per 1000 bytes. If not provided, it will be fetched from the client.
     * @param filter - Optional filter for selecting cells when adding inputs.
     * @param options - Optional configuration object.
     * @param options.feeRateBlockRange - Block range for fee rate calculation when feeRate is not provided.
     * @param options.maxFeeRate - Maximum allowed fee rate.
     * @param options.shouldAddInputs - Whether to add inputs automatically. Defaults to true.
     * @returns A promise that resolves to a tuple containing:
     *          - The number of inputs added during the process
     *          - A boolean indicating whether change was applied (true) or fee was paid without change (false)
     *
     * @throws {Error} When the specified output index doesn't exist.
     *
     * @example
     * ```typescript
     * // Add excess capacity to the first output (index 0)
     * const [addedInputs, hasChange] = await tx.completeFeeChangeToOutput(
     *   signer,
     *   0, // Output index
     *   1000n // 1000 shannons per 1000 bytes
     * );
     * ```
     */
    completeFeeChangeToOutput(from: Signer, index: NumLike, feeRate?: NumLike, filter?: ClientCollectableSearchKeyFilterLike, options?: {
        feeRateBlockRange?: NumLike;
        maxFeeRate?: NumLike;
        shouldAddInputs?: boolean;
    }): Promise<[number, boolean]>;
}
/**
 * Checks whether a NervosDAO transaction exceeds the 64-output limit.
 * Returns true if the transaction is DAO-related and has more than 64 outputs.
 * Short-circuits to false when outputs <= 64.
 *
 * @param tx - The transaction to check
 * @param client - CKB client for resolving the NervosDAO script and input cell info
 * @returns true if the DAO output limit is exceeded
 */
export declare function isDaoOutputLimitExceeded(tx: Transaction, client: Client): Promise<boolean>;
/**
 * Calculate Nervos DAO profit between two blocks.
 * This function computes the profit earned from a Nervos DAO deposit
 * based on the capacity and the time period between deposit and withdrawal.
 *
 * @param profitableCapacity - The capacity that earns profit (total capacity minus occupied capacity).
 * @param depositHeaderLike - The block header when the DAO deposit was made.
 * @param withdrawHeaderLike - The block header when the DAO withdrawal is made.
 * @returns The profit amount in CKB (capacity units).
 *
 * @example
 * ```typescript
 * const profit = calcDaoProfit(
 *   ccc.fixedPointFrom(100), // 100 CKB profitable capacity
 *   depositHeader,
 *   withdrawHeader
 * );
 * console.log(`Profit: ${profit} shannons`);
 * ```
 *
 * @see {@link https://github.com/nervosnetwork/rfcs/blob/master/rfcs/0023-dao-deposit-withdraw/0023-dao-deposit-withdraw.md | Nervos DAO RFC}
 */
export declare function calcDaoProfit(profitableCapacity: NumLike, depositHeaderLike: ClientBlockHeaderLike, withdrawHeaderLike: ClientBlockHeaderLike): Num;
/**
 * Calculate claimable epoch for Nervos DAO withdrawal.
 * This function determines the earliest epoch when a Nervos DAO withdrawal
 * can be claimed based on the deposit and withdrawal epochs.
 *
 * @param depositHeader - The block header when the DAO deposit was made.
 * @param withdrawHeader - The block header when the DAO withdrawal was initiated.
 * @returns The epoch when the withdrawal can be claimed, represented as an Epoch instance.
 *
 * @example
 * ```typescript
 * const epoch = calcDaoClaimEpoch(depositHeader, withdrawHeader);
 * console.log(`Can claim at epoch: ${epoch.integer}, numerator: ${epoch.numerator}, denominator: ${epoch.denominator}`);
 * ```
 *
 * @remarks
 * The Nervos DAO has a minimum lock period of 180 epochs (~30 days).
 * This function calculates the exact epoch when the withdrawal becomes claimable
 * based on the deposit epoch and withdrawal epoch timing.
 *
 * @see {@link https://github.com/nervosnetwork/rfcs/blob/master/rfcs/0023-dao-deposit-withdraw/0023-dao-deposit-withdraw.md | Nervos DAO RFC}
 */
export declare function calcDaoClaimEpoch(depositHeader: ClientBlockHeaderLike, withdrawHeader: ClientBlockHeaderLike): Epoch;
export {};
//# sourceMappingURL=transaction.d.ts.map