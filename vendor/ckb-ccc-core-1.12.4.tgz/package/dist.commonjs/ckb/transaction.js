"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var OutPoint_1, CellOutput_1, Since_1, CellInput_1, CellDep_1, WitnessArgs_1, Transaction_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.Transaction = exports.RawTransaction = exports.WitnessArgs = exports.CellDepVec = exports.CellDep = exports.CellInputVec = exports.CellInput = exports.Since = exports.Cell = exports.CellAny = exports.CellOutputVec = exports.CellOutput = exports.OutPoint = exports.DepTypeCodec = void 0;
exports.depTypeFrom = depTypeFrom;
exports.depTypeToBytes = depTypeToBytes;
exports.depTypeFromBytes = depTypeFromBytes;
exports.udtBalanceFrom = udtBalanceFrom;
exports.isDaoOutputLimitExceeded = isDaoOutputLimitExceeded;
exports.calcDaoProfit = calcDaoProfit;
exports.calcDaoClaimEpoch = calcDaoClaimEpoch;
const index_js_1 = require("../bytes/index.js");
const index_js_2 = require("../client/index.js");
const knownScript_js_1 = require("../client/knownScript.js");
const index_js_3 = require("../codec/index.js");
const index_js_4 = require("../fixedPoint/index.js");
const index_js_5 = require("../hasher/index.js");
const index_js_6 = require("../hex/index.js");
const index_js_7 = require("../molecule/index.js");
const index_js_8 = require("../num/index.js");
const index_js_9 = require("../utils/index.js");
const epoch_js_1 = require("./epoch.js");
const script_js_1 = require("./script.js");
const transaction_advanced_js_1 = require("./transaction.advanced.js");
const transactionErrors_js_1 = require("./transactionErrors.js");
exports.DepTypeCodec = index_js_3.Codec.from({
    byteLength: 1,
    encode: depTypeToBytes,
    decode: depTypeFromBytes,
});
/**
 * Converts a DepTypeLike value to a DepType.
 * @public
 *
 * @param val - The value to convert, which can be a string, number, or bigint.
 * @returns The corresponding DepType.
 *
 * @throws Will throw an error if the input value is not a valid dep type.
 *
 * @example
 * ```typescript
 * const depType = depTypeFrom(1); // Outputs "code"
 * const depType = depTypeFrom("depGroup"); // Outputs "depGroup"
 * ```
 */
function depTypeFrom(val) {
    const depType = (() => {
        if (typeof val === "number") {
            return transaction_advanced_js_1.NUM_TO_DEP_TYPE[val];
        }
        if (typeof val === "bigint") {
            return transaction_advanced_js_1.NUM_TO_DEP_TYPE[Number(val)];
        }
        return val;
    })();
    if (depType === undefined) {
        throw new Error(`Invalid dep type ${val}`);
    }
    return depType;
}
/**
 * Converts a DepTypeLike value to its corresponding byte representation.
 * @public
 *
 * @param depType - The dep type value to convert.
 * @returns A Uint8Array containing the byte representation of the dep type.
 *
 * @example
 * ```typescript
 * const depTypeBytes = depTypeToBytes("code"); // Outputs Uint8Array [1]
 * ```
 */
function depTypeToBytes(depType) {
    return (0, index_js_1.bytesFrom)([transaction_advanced_js_1.DEP_TYPE_TO_NUM[depTypeFrom(depType)]]);
}
/**
 * Converts a byte-like value to a DepType.
 * @public
 *
 * @param bytes - The byte-like value to convert.
 * @returns The corresponding DepType.
 *
 * @throws Will throw an error if the input bytes do not correspond to a valid dep type.
 *
 * @example
 * ```typescript
 * const depType = depTypeFromBytes(new Uint8Array([1])); // Outputs "code"
 * ```
 */
function depTypeFromBytes(bytes) {
    return transaction_advanced_js_1.NUM_TO_DEP_TYPE[(0, index_js_1.bytesFrom)(bytes)[0]];
}
/**
 * @public
 */
let OutPoint = OutPoint_1 = class OutPoint extends index_js_3.Entity.Base() {
    /**
     * Creates an instance of OutPoint.
     *
     * @param txHash - The transaction hash.
     * @param index - The index of the output in the transaction.
     */
    constructor(txHash, index) {
        super();
        this.txHash = txHash;
        this.index = index;
    }
    /**
     * Creates an OutPoint instance from an OutPointLike object.
     *
     * @param outPoint - An OutPointLike object or an instance of OutPoint.
     * @returns An OutPoint instance.
     *
     * @example
     * ```typescript
     * const outPoint = OutPoint.from({ txHash: "0x...", index: 0 });
     * ```
     */
    static from(outPoint) {
        if (outPoint instanceof OutPoint_1) {
            return outPoint;
        }
        return new OutPoint_1((0, index_js_6.hexFrom)(outPoint.txHash), (0, index_js_8.numFrom)(outPoint.index));
    }
    /**
     * Clone a OutPoint.
     *
     * @returns A cloned OutPoint instance.
     *
     * @example
     * ```typescript
     * const outPoint1 = outPoint0.clone();
     * ```
     */
    clone() {
        return new OutPoint_1(this.txHash, this.index);
    }
    /**
     * Check if the OutPoint is equal to another OutPoint.
     * @public
     * @param other - The other OutPoint to compare with
     * @returns True if the OutPoints are equal, false otherwise
     *
     * @example
     * ```typescript
     * const isEqual = outPoint0.eq(outPoint1);
     * ```
     */
    eq(other) {
        other = OutPoint_1.from(other);
        return this.txHash === other.txHash && this.index === other.index;
    }
};
exports.OutPoint = OutPoint;
exports.OutPoint = OutPoint = OutPoint_1 = __decorate([
    (0, index_js_3.codec)(index_js_7.mol.struct({
        txHash: index_js_7.mol.Byte32,
        index: index_js_7.mol.Uint32,
    }))
], OutPoint);
/**
 * @public
 */
let CellOutput = CellOutput_1 = class CellOutput extends index_js_3.Entity.Base() {
    /**
     * Creates an instance of CellOutput.
     *
     * @param capacity - The capacity of the cell.
     * @param lock - The lock script of the cell.
     * @param type - The optional type script of the cell.
     */
    constructor(capacity, lock, type) {
        super();
        this.capacity = capacity;
        this.lock = lock;
        this.type = type;
    }
    get occupiedSize() {
        return 8 + this.lock.occupiedSize + (this.type?.occupiedSize ?? 0);
    }
    /**
     * Creates a CellOutput instance from a CellOutputLike object.
     * This method supports automatic capacity calculation when outputData is provided and capacity is 0 or omitted.
     *
     * @param cellOutput - A CellOutputLike object or an instance of CellOutput.
     * @param outputData - Optional output data used for automatic capacity calculation.
     *                     When provided and capacity is 0, the capacity will be calculated
     *                     as occupiedSize + outputData.length.
     * @returns A CellOutput instance.
     *
     * @example
     * ```typescript
     * // Basic usage with explicit capacity
     * const cellOutput1 = CellOutput.from({
     *   capacity: 1000n,
     *   lock: { codeHash: "0x...", hashType: "type", args: "0x..." },
     *   type: { codeHash: "0x...", hashType: "type", args: "0x..." }
     * });
     *
     * // Automatic capacity calculation
     * const cellOutput2 = CellOutput.from({
     *   lock: { codeHash: "0x...", hashType: "type", args: "0x..." }
     * }, "0x1234"); // Capacity will be calculated automatically
     * ```
     */
    static from(cellOutput, outputData) {
        const output = (() => {
            if (cellOutput instanceof CellOutput_1) {
                return cellOutput;
            }
            return new CellOutput_1((0, index_js_8.numFrom)(cellOutput.capacity ?? 0), script_js_1.Script.from(cellOutput.lock), (0, index_js_9.apply)(script_js_1.Script.from, cellOutput.type));
        })();
        if (outputData != null) {
            output.capacity = (0, index_js_8.numMax)(output.capacity, (0, index_js_4.fixedPointFrom)(output.occupiedSize + (0, index_js_1.bytesFrom)(outputData).length));
        }
        return output;
    }
    /**
     * Clone a CellOutput.
     *
     * @returns A cloned CellOutput instance.
     *
     * @example
     * ```typescript
     * const cellOutput1 = cellOutput0.clone();
     * ```
     */
    clone() {
        return new CellOutput_1(this.capacity, this.lock.clone(), this.type?.clone());
    }
};
exports.CellOutput = CellOutput;
exports.CellOutput = CellOutput = CellOutput_1 = __decorate([
    (0, index_js_3.codec)(index_js_7.mol.table({
        capacity: index_js_7.mol.Uint64,
        lock: script_js_1.Script,
        type: script_js_1.ScriptOpt,
    }))
], CellOutput);
exports.CellOutputVec = index_js_7.mol.vector(CellOutput);
/**
 * Represents a CKB cell that can be either on-chain (with an `outPoint`) or off-chain (without an `outPoint`).
 * This class provides a unified interface for handling cells before they are included in a transaction,
 * or for cells that are already part of the blockchain state.
 *
 * @public
 */
class CellAny {
    /**
     * Creates an instance of CellAny.
     *
     * @param cellOutput - The cell output of the cell.
     * @param outputData - The output data of the cell.
     * @param outPoint - The optional output point of the cell. If provided, the cell is considered on-chain.
     */
    constructor(cellOutput, outputData, outPoint) {
        this.cellOutput = cellOutput;
        this.outputData = outputData;
        this.outPoint = outPoint;
    }
    /**
     * Creates a `CellAny` instance from a `CellAnyLike` object.
     * This factory method provides a convenient way to create `CellAny` instances
     * from plain objects, automatically handling the optional `outPoint` or `previousOutput`.
     *
     * @param cell - A `CellAnyLike` object.
     * @returns A new `CellAny` instance.
     *
     * @example
     * ```typescript
     * // Create an off-chain cell (e.g., a new output)
     * const offChainCell = CellAny.from({
     *   cellOutput: { capacity: 1000n, lock: lockScript },
     *   outputData: "0x"
     * });
     *
     * // Create an on-chain cell from an input
     * const onChainCell = CellAny.from({
     *   outPoint: { txHash: "0x...", index: 0 },
     *   cellOutput: { capacity: 2000n, lock: lockScript },
     *   outputData: "0x1234"
     * });
     * ```
     */
    static from(cell) {
        if (cell instanceof CellAny) {
            return cell;
        }
        const outputData = (0, index_js_6.hexFrom)(cell.outputData ?? "0x");
        return new CellAny(CellOutput.from(cell.cellOutput, outputData), outputData, (0, index_js_9.apply)(OutPoint.from, cell.outPoint ?? cell.previousOutput));
    }
    /**
     * Calculates the total occupied size of the cell in bytes.
     * This includes the size of the `CellOutput` structure plus the size of the `outputData`.
     *
     * @returns The total occupied size in bytes.
     */
    get occupiedSize() {
        return this.cellOutput.occupiedSize + (0, index_js_1.bytesFrom)(this.outputData).byteLength;
    }
    /**
     * Calculates the free capacity of the cell.
     * Free capacity is the total capacity minus the capacity occupied by the cell's structure and data.
     *
     * @returns The free capacity in shannons as a `Num`.
     */
    get capacityFree() {
        return this.cellOutput.capacity - (0, index_js_4.fixedPointFrom)(this.occupiedSize);
    }
    /**
     * Checks if the cell is a Nervos DAO cell and optionally checks its phase.
     *
     * @param client - A CKB client instance to fetch known script information.
     * @param phase - Optional phase to check: "deposited" or "withdrew".
     *                If omitted, it checks if the cell is a DAO cell regardless of phase.
     * @returns A promise that resolves to `true` if the cell is a matching Nervos DAO cell, `false` otherwise.
     */
    async isNervosDao(client, phase) {
        const { type } = this.cellOutput;
        const daoType = await client.getKnownScript(knownScript_js_1.KnownScript.NervosDao);
        if (!type ||
            type.codeHash !== daoType.codeHash ||
            type.hashType !== daoType.hashType) {
            // Non Nervos DAO cell
            return false;
        }
        const hasWithdrew = (0, index_js_8.numFrom)(this.outputData) !== index_js_4.Zero;
        return (!phase ||
            (phase === "deposited" && !hasWithdrew) ||
            (phase === "withdrew" && hasWithdrew));
    }
    /**
     * Clones the `CellAny` instance.
     *
     * @returns A new `CellAny` instance that is a deep copy of the current one.
     *
     * @example
     * ```typescript
     * const clonedCell = cellAny.clone();
     * ```
     */
    clone() {
        return new CellAny(this.cellOutput.clone(), this.outputData, this.outPoint?.clone());
    }
}
exports.CellAny = CellAny;
/**
 * Represents an on-chain CKB cell, which is a `CellAny` that is guaranteed to have an `outPoint`.
 * This class is typically used for cells that are already part of the blockchain state, such as transaction inputs.
 * @public
 */
class Cell extends CellAny {
    /**
     * Creates an instance of an on-chain Cell.
     *
     * @param outPoint - The output point of the cell.
     * @param cellOutput - The cell output of the cell.
     * @param outputData - The output data of the cell.
     */
    constructor(outPoint, cellOutput, outputData) {
        super(cellOutput, outputData, outPoint);
        this.outPoint = outPoint;
    }
    /**
     * Creates a Cell instance from a CellLike object.
     * This method accepts either `outPoint` or `previousOutput` to specify the cell's location,
     * and supports automatic capacity calculation for the cell output.
     *
     * @param cell - A CellLike object or an instance of Cell. The object can use either:
     *               - `outPoint`: For referencing a cell output
     *               - `previousOutput`: For referencing a cell input (alternative name for outPoint)
     *               The cellOutput can omit capacity for automatic calculation.
     * @returns A Cell instance.
     *
     * @example
     * ```typescript
     * // Using outPoint with explicit capacity
     * const cell1 = Cell.from({
     *   outPoint: { txHash: "0x...", index: 0 },
     *   cellOutput: {
     *     capacity: 1000n,
     *     lock: { codeHash: "0x...", hashType: "type", args: "0x..." }
     *   },
     *   outputData: "0x"
     * });
     *
     * // Using previousOutput with automatic capacity calculation
     * const cell2 = Cell.from({
     *   previousOutput: { txHash: "0x...", index: 0 },
     *   cellOutput: {
     *     lock: { codeHash: "0x...", hashType: "type", args: "0x..." }
     *     // capacity will be calculated automatically
     *   },
     *   outputData: "0x1234"
     * });
     * ```
     */
    static from(cell) {
        if (cell instanceof Cell) {
            return cell;
        }
        return new Cell(OutPoint.from(cell.outPoint ?? cell.previousOutput), CellOutput.from(cell.cellOutput, cell.outputData), (0, index_js_6.hexFrom)(cell.outputData ?? "0x"));
    }
    /**
     * Gets confirmed Nervos DAO profit of a Cell
     * It returns non-zero value only when the cell is in withdrawal phase 2
     * See https://github.com/nervosnetwork/rfcs/blob/master/rfcs/0023-dao-deposit-withdraw/0023-dao-deposit-withdraw.md
     *
     * @param client - A client for searching DAO related headers
     * @returns Profit
     *
     * @example
     * ```typescript
     * const profit = await cell.getDaoProfit(client);
     * ```
     */
    async getDaoProfit(client) {
        if (!(await this.isNervosDao(client, "withdrew"))) {
            return index_js_4.Zero;
        }
        const { depositHeader, withdrawHeader } = await this.getNervosDaoInfo(client);
        if (!withdrawHeader || !depositHeader) {
            throw new Error(`Unable to get headers of a Nervos DAO cell ${this.outPoint.txHash}:${this.outPoint.index.toString()}`);
        }
        return calcDaoProfit(this.capacityFree, depositHeader, withdrawHeader);
    }
    /**
     * Retrieves detailed information about a Nervos DAO cell, including its deposit and withdrawal headers.
     *
     * @param client - A CKB client instance to fetch cell and header data.
     * @returns A promise that resolves to an object containing header information.
     *          - If not a DAO cell, returns `{}`.
     *          - If a deposited DAO cell, returns `{ depositHeader }`.
     *          - If a withdrawn DAO cell, returns `{ depositHeader, withdrawHeader }`.
     *
     * @throws If the cell is a DAO cell but its corresponding headers cannot be fetched.
     *
     * @example
     * ```typescript
     * const daoInfo = await cell.getNervosDaoInfo(client);
     * ```
     */
    async getNervosDaoInfo(client) {
        if (!(await this.isNervosDao(client))) {
            // Non Nervos DAO cell
            return {};
        }
        if ((0, index_js_8.numFrom)(this.outputData) === index_js_4.Zero) {
            // Deposited Nervos DAO cell
            const depositRes = await client.getCellWithHeader(this.outPoint);
            if (!depositRes?.header) {
                throw new Error(`Unable to get header of a Nervos DAO deposited cell ${this.outPoint.txHash}:${this.outPoint.index.toString()}`);
            }
            return {
                depositHeader: depositRes.header,
            };
        }
        // Withdrew Nervos DAO cell
        const [depositHeader, withdrawRes] = await Promise.all([
            client.getHeaderByNumber((0, index_js_8.numFromBytes)(this.outputData)),
            client.getCellWithHeader(this.outPoint),
        ]);
        if (!withdrawRes?.header || !depositHeader) {
            throw new Error(`Unable to get headers of a Nervos DAO withdrew cell ${this.outPoint.txHash}:${this.outPoint.index.toString()}`);
        }
        return {
            depositHeader,
            withdrawHeader: withdrawRes.header,
        };
    }
    /**
     * Clone a Cell
     *
     * @returns A cloned Cell instance.
     *
     * @example
     * ```typescript
     * const cell1 = cell0.clone();
     * ```
     */
    clone() {
        return new Cell(this.outPoint.clone(), this.cellOutput.clone(), this.outputData);
    }
}
exports.Cell = Cell;
/**
 * @public
 */
let Since = Since_1 = class Since extends index_js_3.Entity.Base() {
    /**
     * Creates an instance of Since.
     *
     * @param relative - Absolute or relative
     * @param metric - The metric of since
     * @param value - The value of since
     */
    constructor(relative, metric, value) {
        super();
        this.relative = relative;
        this.metric = metric;
        this.value = value;
    }
    /**
     * Clone a Since.
     *
     * @returns A cloned Since instance.
     *
     * @example
     * ```typescript
     * const since1 = since0.clone();
     * ```
     */
    clone() {
        return new Since_1(this.relative, this.metric, this.value);
    }
    /**
     * Creates a Since instance from a SinceLike object.
     *
     * @param since - A SinceLike object or an instance of Since.
     * @returns A Since instance.
     *
     * @example
     * ```typescript
     * const since = Since.from("0x1234567812345678");
     * ```
     */
    static from(since) {
        if (since instanceof Since_1) {
            return since;
        }
        if (typeof since === "object" && "relative" in since) {
            return new Since_1(since.relative, since.metric, (0, index_js_8.numFrom)(since.value));
        }
        return Since_1.fromNum(since);
    }
    /**
     * Converts the Since instance to num.
     *
     * @returns A num
     *
     * @example
     * ```typescript
     * const num = since.toNum();
     * ```
     */
    toNum() {
        return (this.value |
            (this.relative === "absolute" ? index_js_4.Zero : (0, index_js_8.numFrom)("0x8000000000000000")) |
            {
                blockNumber: (0, index_js_8.numFrom)("0x0000000000000000"),
                epoch: (0, index_js_8.numFrom)("0x2000000000000000"),
                timestamp: (0, index_js_8.numFrom)("0x4000000000000000"),
            }[this.metric]);
    }
    /**
     * Creates a Since instance from a num-like value.
     *
     * @param numLike - The num-like value to convert.
     * @returns A Since instance.
     *
     * @example
     * ```typescript
     * const since = Since.fromNum("0x0");
     * ```
     */
    static fromNum(numLike) {
        const num = (0, index_js_8.numFrom)(numLike);
        const relative = num >> (0, index_js_8.numFrom)(63) === index_js_4.Zero ? "absolute" : "relative";
        const metric = ["blockNumber", "epoch", "timestamp"][Number((num >> (0, index_js_8.numFrom)(61)) & (0, index_js_8.numFrom)(3))];
        const value = num & (0, index_js_8.numFrom)("0x00ffffffffffffff");
        return new Since_1(relative, metric, value);
    }
};
exports.Since = Since;
exports.Since = Since = Since_1 = __decorate([
    (0, index_js_3.codec)(index_js_7.mol.Uint64.mapIn((encodable) => Since.from(encodable).toNum()))
], Since);
/**
 * @public
 */
let CellInput = CellInput_1 = class CellInput extends index_js_3.Entity.Base() {
    /**
     * Creates an instance of CellInput.
     *
     * @param previousOutput - The previous outpoint of the cell.
     * @param since - The since value of the cell input.
     * @param cellOutput - The optional cell output associated with the cell input.
     * @param outputData - The optional output data associated with the cell input.
     */
    constructor(previousOutput, since, cellOutput, outputData) {
        super();
        this.previousOutput = previousOutput;
        this.since = since;
        this.cellOutput = cellOutput;
        this.outputData = outputData;
    }
    /**
     * Creates a CellInput instance from a CellInputLike object.
     *
     * @param cellInput - A CellInputLike object or an instance of CellInput.
     * @returns A CellInput instance.
     *
     * @example
     * ```typescript
     * const cellInput = CellInput.from({
     *   previousOutput: { txHash: "0x...", index: 0 },
     *   since: 0n
     * });
     * ```
     */
    static from(cellInput) {
        if (cellInput instanceof CellInput_1) {
            return cellInput;
        }
        return new CellInput_1(OutPoint.from("previousOutput" in cellInput
            ? cellInput.previousOutput
            : cellInput.outPoint), Since.from(cellInput.since ?? 0).toNum(), (0, index_js_9.apply)(CellOutput.from, cellInput.cellOutput), (0, index_js_9.apply)(index_js_6.hexFrom, cellInput.outputData));
    }
    async getCell(client) {
        await this.completeExtraInfos(client);
        if (!this.cellOutput || !this.outputData) {
            throw new Error("Unable to complete input");
        }
        return Cell.from({
            outPoint: this.previousOutput,
            cellOutput: this.cellOutput,
            outputData: this.outputData,
        });
    }
    /**
     * Complete extra infos in the input. Including
     * - Previous cell output
     * - Previous cell data
     * The instance will be modified.
     *
     * @returns true if succeed.
     * @example
     * ```typescript
     * await cellInput.completeExtraInfos(client);
     * ```
     */
    async completeExtraInfos(client) {
        if (this.cellOutput && this.outputData) {
            return;
        }
        const cell = await client.getCell(this.previousOutput);
        if (!cell) {
            return;
        }
        this.cellOutput = cell.cellOutput;
        this.outputData = cell.outputData;
    }
    /**
     * The extra capacity created when consume this input.
     * This is usually NervosDAO interest, see https://github.com/nervosnetwork/rfcs/blob/master/rfcs/0023-dao-deposit-withdraw/0023-dao-deposit-withdraw.md.
     * And it can also be miners' income. (But this is not implemented yet)
     */
    async getExtraCapacity(client) {
        return (await this.getCell(client)).getDaoProfit(client);
    }
    /**
     * Clone a CellInput.
     *
     * @returns A cloned CellInput instance.
     *
     * @example
     * ```typescript
     * const cellInput1 = cellInput0.clone();
     * ```
     */
    clone() {
        return new CellInput_1(this.previousOutput.clone(), this.since, this.cellOutput?.clone(), this.outputData);
    }
};
exports.CellInput = CellInput;
exports.CellInput = CellInput = CellInput_1 = __decorate([
    (0, index_js_3.codec)(index_js_7.mol
        .struct({
        since: Since,
        previousOutput: OutPoint,
    })
        .mapIn((encodable) => CellInput.from(encodable)))
], CellInput);
exports.CellInputVec = index_js_7.mol.vector(CellInput);
/**
 * @public
 */
let CellDep = CellDep_1 = class CellDep extends index_js_3.Entity.Base() {
    /**
     * Creates an instance of CellDep.
     *
     * @param outPoint - The outpoint of the cell dependency.
     * @param depType - The dependency type.
     */
    constructor(outPoint, depType) {
        super();
        this.outPoint = outPoint;
        this.depType = depType;
    }
    /**
     * Creates a CellDep instance from a CellDepLike object.
     *
     * @param cellDep - A CellDepLike object or an instance of CellDep.
     * @returns A CellDep instance.
     *
     * @example
     * ```typescript
     * const cellDep = CellDep.from({
     *   outPoint: { txHash: "0x...", index: 0 },
     *   depType: "depGroup"
     * });
     * ```
     */
    static from(cellDep) {
        if (cellDep instanceof CellDep_1) {
            return cellDep;
        }
        return new CellDep_1(OutPoint.from(cellDep.outPoint), depTypeFrom(cellDep.depType));
    }
    /**
     * Clone a CellDep.
     *
     * @returns A cloned CellDep instance.
     *
     * @example
     * ```typescript
     * const cellDep1 = cellDep0.clone();
     * ```
     */
    clone() {
        return new CellDep_1(this.outPoint.clone(), this.depType);
    }
};
exports.CellDep = CellDep;
exports.CellDep = CellDep = CellDep_1 = __decorate([
    (0, index_js_3.codec)(index_js_7.mol.struct({
        outPoint: OutPoint,
        depType: exports.DepTypeCodec,
    }))
], CellDep);
exports.CellDepVec = index_js_7.mol.vector(CellDep);
/**
 * @public
 */
let WitnessArgs = WitnessArgs_1 = class WitnessArgs extends index_js_3.Entity.Base() {
    /**
     * Creates an instance of WitnessArgs.
     *
     * @param lock - The optional lock field of the witness.
     * @param inputType - The optional input type field of the witness.
     * @param outputType - The optional output type field of the witness.
     */
    constructor(lock, inputType, outputType) {
        super();
        this.lock = lock;
        this.inputType = inputType;
        this.outputType = outputType;
    }
    /**
     * Creates a WitnessArgs instance from a WitnessArgsLike object.
     *
     * @param witnessArgs - A WitnessArgsLike object or an instance of WitnessArgs.
     * @returns A WitnessArgs instance.
     *
     * @example
     * ```typescript
     * const witnessArgs = WitnessArgs.from({
     *   lock: "0x...",
     *   inputType: "0x...",
     *   outputType: "0x..."
     * });
     * ```
     */
    static from(witnessArgs) {
        if (witnessArgs instanceof WitnessArgs_1) {
            return witnessArgs;
        }
        return new WitnessArgs_1((0, index_js_9.apply)(index_js_6.hexFrom, witnessArgs.lock), (0, index_js_9.apply)(index_js_6.hexFrom, witnessArgs.inputType), (0, index_js_9.apply)(index_js_6.hexFrom, witnessArgs.outputType));
    }
};
exports.WitnessArgs = WitnessArgs;
exports.WitnessArgs = WitnessArgs = WitnessArgs_1 = __decorate([
    (0, index_js_3.codec)(index_js_7.mol.table({
        lock: index_js_7.mol.BytesOpt,
        inputType: index_js_7.mol.BytesOpt,
        outputType: index_js_7.mol.BytesOpt,
    }))
], WitnessArgs);
/**
 * Convert a bytes to a num.
 *
 * @public
 */
function udtBalanceFrom(dataLike) {
    const data = (0, index_js_1.bytesFrom)(dataLike).slice(0, 16);
    return data.length === 0 ? index_js_4.Zero : (0, index_js_8.numFromBytes)(data);
}
exports.RawTransaction = index_js_7.mol.table({
    version: index_js_7.mol.Uint32,
    cellDeps: exports.CellDepVec,
    headerDeps: index_js_7.mol.Byte32Vec,
    inputs: exports.CellInputVec,
    outputs: exports.CellOutputVec,
    outputsData: index_js_7.mol.BytesVec,
});
/**
 * @public
 */
let Transaction = Transaction_1 = class Transaction extends index_js_3.Entity.Base() {
    /**
     * Creates an instance of Transaction.
     *
     * @param version - The version of the transaction.
     * @param cellDeps - The cell dependencies of the transaction.
     * @param headerDeps - The header dependencies of the transaction.
     * @param inputs - The inputs of the transaction.
     * @param outputs - The outputs of the transaction.
     * @param outputsData - The data associated with the outputs.
     * @param witnesses - The witnesses of the transaction.
     */
    constructor(version, cellDeps, headerDeps, inputs, outputs, outputsData, witnesses) {
        super();
        this.version = version;
        this.cellDeps = cellDeps;
        this.headerDeps = headerDeps;
        this.inputs = inputs;
        this.outputs = outputs;
        this.outputsData = outputsData;
        this.witnesses = witnesses;
    }
    /**
     * Creates a default Transaction instance with empty fields.
     *
     * @returns A default Transaction instance.
     *
     * @example
     * ```typescript
     * const defaultTx = Transaction.default();
     * ```
     */
    static default() {
        return new Transaction_1(0n, [], [], [], [], [], []);
    }
    /**
     * Copy every properties from another transaction.
     * This method replaces all properties of the current transaction with those from the provided transaction.
     *
     * @param txLike - The transaction-like object to copy properties from.
     *
     * @example
     * ```typescript
     * this.copy(Transaction.default());
     * ```
     */
    copy(txLike) {
        const tx = Transaction_1.from(txLike);
        this.version = tx.version;
        this.cellDeps = tx.cellDeps;
        this.headerDeps = tx.headerDeps;
        this.inputs = tx.inputs;
        this.outputs = tx.outputs;
        this.outputsData = tx.outputsData;
        this.witnesses = tx.witnesses;
    }
    /**
     * Creates a deep copy of the transaction.
     * This method creates a new Transaction instance with all nested objects cloned,
     * ensuring that modifications to the cloned transaction do not affect the original.
     *
     * @returns A new Transaction instance that is a deep copy of the current transaction.
     *
     * @example
     * ```typescript
     * const originalTx = Transaction.from({
     *   version: 0,
     *   inputs: [{ previousOutput: { txHash: "0x...", index: 0 } }],
     *   outputs: [{ capacity: 1000n, lock: lockScript }],
     *   outputsData: ["0x"],
     *   witnesses: ["0x"]
     * });
     *
     * const clonedTx = originalTx.clone();
     *
     * // Modifications to clonedTx won't affect originalTx
     * clonedTx.addOutput({ capacity: 2000n, lock: anotherLockScript });
     * console.log(originalTx.outputs.length); // Still 1
     * console.log(clonedTx.outputs.length);   // Now 2
     * ```
     *
     * @remarks
     * The clone operation performs deep copying for:
     * - Cell dependencies (cellDeps) - each CellDep is cloned
     * - Inputs - each CellInput is cloned
     * - Outputs - each CellOutput is cloned
     *
     * The following are shallow copied (references to immutable data):
     * - Header dependencies (headerDeps) - Hex strings are immutable
     * - Output data (outputsData) - Hex strings are immutable
     * - Witnesses - Hex strings are immutable
     * - Version - bigint is immutable
     */
    clone() {
        return new Transaction_1(this.version, this.cellDeps.map((c) => c.clone()), this.headerDeps.map((h) => h), this.inputs.map((i) => i.clone()), this.outputs.map((o) => o.clone()), this.outputsData.map((o) => o), this.witnesses.map((w) => w));
    }
    /**
     * Creates a Transaction instance from a TransactionLike object.
     *
     * @param tx - A TransactionLike object or an instance of Transaction.
     * @returns A Transaction instance.
     *
     * @example
     * ```typescript
     * const transaction = Transaction.from({
     *   version: 0,
     *   cellDeps: [],
     *   headerDeps: [],
     *   inputs: [],
     *   outputs: [],
     *   outputsData: [],
     *   witnesses: []
     * });
     * ```
     */
    static from(tx) {
        if (tx instanceof Transaction_1) {
            return tx;
        }
        const outputs = tx.outputs?.map((output, i) => CellOutput.from(output, tx.outputsData?.[i] ?? [])) ?? [];
        const outputsData = outputs.map((_, i) => (0, index_js_6.hexFrom)(tx.outputsData?.[i] ?? "0x"));
        if (tx.outputsData != null && outputsData.length < tx.outputsData.length) {
            outputsData.push(...tx.outputsData.slice(outputsData.length).map((d) => (0, index_js_6.hexFrom)(d)));
        }
        return new Transaction_1((0, index_js_8.numFrom)(tx.version ?? 0), tx.cellDeps?.map((cellDep) => CellDep.from(cellDep)) ?? [], tx.headerDeps?.map(index_js_6.hexFrom) ?? [], tx.inputs?.map((input) => CellInput.from(input)) ?? [], outputs, outputsData, tx.witnesses?.map(index_js_6.hexFrom) ?? []);
    }
    /**
     * Creates a Transaction instance from a Lumos skeleton.
     *
     * @param skeleton - The Lumos transaction skeleton.
     * @returns A Transaction instance.
     *
     * @throws Will throw an error if an input's outPoint is missing.
     *
     * @example
     * ```typescript
     * const transaction = Transaction.fromLumosSkeleton(skeleton);
     * ```
     */
    static fromLumosSkeleton(skeleton) {
        return Transaction_1.from({
            version: 0n,
            cellDeps: skeleton.cellDeps.toArray(),
            headerDeps: skeleton.headerDeps.toArray(),
            inputs: skeleton.inputs.toArray().map((input, i) => {
                if (!input.outPoint) {
                    throw new Error("outPoint is required in input");
                }
                return CellInput.from({
                    previousOutput: input.outPoint,
                    since: skeleton.inputSinces.get(i, "0x0"),
                    cellOutput: input.cellOutput,
                    outputData: input.data,
                });
            }),
            outputs: skeleton.outputs.toArray().map((output) => output.cellOutput),
            outputsData: skeleton.outputs.toArray().map((output) => output.data),
            witnesses: skeleton.witnesses.toArray(),
        });
    }
    /**
     * @deprecated
     * Use ccc.stringify instead.
     * stringify the tx to JSON string.
     */
    stringify() {
        return JSON.stringify(this, (_, value) => {
            if (typeof value === "bigint") {
                return (0, index_js_8.numToHex)(value);
            }
            // eslint-disable-next-line @typescript-eslint/no-unsafe-return
            return value;
        });
    }
    /**
     * Converts the raw transaction data to bytes.
     *
     * @returns A Uint8Array containing the raw transaction bytes.
     *
     * @example
     * ```typescript
     * const rawTxBytes = transaction.rawToBytes();
     * ```
     */
    rawToBytes() {
        return exports.RawTransaction.encode(this);
    }
    /**
     * Calculates the hash of the transaction without witnesses. This is the transaction hash in the usual sense.
     * To calculate the hash of the whole transaction including the witnesses, use transaction.hashFull() instead.
     *
     * @returns The hash of the transaction.
     *
     * @example
     * ```typescript
     * const txHash = transaction.hash();
     * ```
     */
    hash() {
        return (0, index_js_5.hashCkb)(this.rawToBytes());
    }
    /**
     * Calculates the hash of the transaction with witnesses.
     *
     * @returns The hash of the transaction with witnesses.
     *
     * @example
     * ```typescript
     * const txFullHash = transaction.hashFull();
     * ```
     */
    hashFull() {
        return (0, index_js_5.hashCkb)(this.toBytes());
    }
    /**
     * Hashes a witness and updates the hasher.
     *
     * @param witness - The witness to hash.
     * @param hasher - The hasher instance to update.
     *
     * @example
     * ```typescript
     * Transaction.hashWitnessToHasher("0x...", hasher);
     * ```
     */
    static hashWitnessToHasher(witness, hasher) {
        const raw = (0, index_js_1.bytesFrom)((0, index_js_6.hexFrom)(witness));
        hasher.update((0, index_js_8.numToBytes)(raw.length, 8));
        hasher.update(raw);
    }
    /**
     * Computes the signing hash information for a given script.
     *
     * @param scriptLike - The script associated with the transaction, represented as a ScriptLike object.
     * @param client - The client for complete extra infos in the transaction.
     * @returns A promise that resolves to an object containing the signing message and the witness position,
     *          or undefined if no matching input is found.
     *
     * @example
     * ```typescript
     * const signHashInfo = await tx.getSignHashInfo(scriptLike, client);
     * if (signHashInfo) {
     *   console.log(signHashInfo.message); // Outputs the signing message
     *   console.log(signHashInfo.position); // Outputs the witness position
     * }
     * ```
     */
    async getSignHashInfo(scriptLike, client, hasher = new index_js_5.HasherCkb()) {
        const script = script_js_1.Script.from(scriptLike);
        let position = -1;
        hasher.update(this.hash());
        for (let i = 0; i < this.witnesses.length; i += 1) {
            const input = this.inputs[i];
            if (input) {
                const { cellOutput } = await input.getCell(client);
                if (!script.eq(cellOutput.lock)) {
                    continue;
                }
                if (position === -1) {
                    position = i;
                }
            }
            if (position === -1) {
                return undefined;
            }
            Transaction_1.hashWitnessToHasher(this.witnesses[i], hasher);
        }
        if (position === -1) {
            return undefined;
        }
        return {
            message: hasher.digest(),
            position,
        };
    }
    /**
     * Find the first occurrence of a input with the specified lock id
     *
     * @param scriptIdLike - The script associated with the transaction, represented as a ScriptLike object without args.
     * @param client - The client for complete extra infos in the transaction.
     * @returns A promise that resolves to the found index
     *
     * @example
     * ```typescript
     * const index = await tx.findInputIndexByLockId(scriptIdLike, client);
     * ```
     */
    async findInputIndexByLockId(scriptIdLike, client) {
        const script = script_js_1.Script.from({ ...scriptIdLike, args: "0x" });
        for (let i = 0; i < this.inputs.length; i += 1) {
            const { cellOutput } = await this.inputs[i].getCell(client);
            if (script.codeHash === cellOutput.lock.codeHash &&
                script.hashType === cellOutput.lock.hashType) {
                return i;
            }
        }
    }
    /**
     * Find the first occurrence of a input with the specified lock
     *
     * @param scriptLike - The script associated with the transaction, represented as a ScriptLike object.
     * @param client - The client for complete extra infos in the transaction.
     * @returns A promise that resolves to the found index, or undefined if no matching input is found.
     *
     * @example
     * ```typescript
     * const index = await tx.findInputIndexByLock(scriptLike, client);
     * ```
     */
    async findInputIndexByLock(scriptLike, client) {
        const script = script_js_1.Script.from(scriptLike);
        for (let i = 0; i < this.inputs.length; i += 1) {
            const { cellOutput } = await this.inputs[i].getCell(client);
            if (script.eq(cellOutput.lock)) {
                return i;
            }
        }
    }
    /**
     * Find the last occurrence of a input with the specified lock
     *
     * @param scriptLike - The script associated with the transaction, represented as a ScriptLike object.
     * @param client - The client for complete extra infos in the transaction.
     * @returns A promise that resolves to the found index, or undefined if no matching input is found.
     *
     * @example
     * ```typescript
     * const index = await tx.findLastInputIndexByLock(scriptLike, client);
     * ```
     */
    async findLastInputIndexByLock(scriptLike, client) {
        const script = script_js_1.Script.from(scriptLike);
        for (let i = this.inputs.length - 1; i >= 0; i -= 1) {
            const { cellOutput } = await this.inputs[i].getCell(client);
            if (script.eq(cellOutput.lock)) {
                return i;
            }
        }
    }
    /**
     * Add cell deps if they are not existed
     *
     * @param cellDepLikes - The cell deps to add
     *
     * @example
     * ```typescript
     * tx.addCellDeps(cellDep);
     * ```
     */
    addCellDeps(...cellDepLikes) {
        cellDepLikes.flat().forEach((cellDepLike) => {
            const cellDep = CellDep.from(cellDepLike);
            if (this.cellDeps.some((c) => c.eq(cellDep))) {
                return;
            }
            this.cellDeps.push(cellDep);
        });
    }
    /**
     * Add cell deps at the start if they are not existed
     *
     * @param cellDepLikes - The cell deps to add
     *
     * @example
     * ```typescript
     * tx.addCellDepsAtBegin(cellDep);
     * ```
     */
    addCellDepsAtStart(...cellDepLikes) {
        cellDepLikes.flat().forEach((cellDepLike) => {
            const cellDep = CellDep.from(cellDepLike);
            if (this.cellDeps.some((c) => c.eq(cellDep))) {
                return;
            }
            this.cellDeps.unshift(cellDep);
        });
    }
    /**
     * Add cell dep from infos if they are not existed
     *
     * @param client - A client for searching cell deps
     * @param cellDepInfoLikes - The cell dep infos to add
     *
     * @example
     * ```typescript
     * tx.addCellDepInfos(client, cellDepInfos);
     * ```
     */
    async addCellDepInfos(client, ...cellDepInfoLikes) {
        this.addCellDeps(await client.getCellDeps(...cellDepInfoLikes));
    }
    /**
     * Add cell deps from known script
     *
     * @param client - The client for searching known script and cell deps
     * @param scripts - The known scripts to add
     *
     * @example
     * ```typescript
     * tx.addCellDepsOfKnownScripts(client, KnownScript.OmniLock);
     * ```
     */
    async addCellDepsOfKnownScripts(client, ...scripts) {
        await Promise.all(scripts
            .flat()
            .map(async (script) => this.addCellDepInfos(client, (await client.getKnownScript(script)).cellDeps)));
    }
    /**
     * Set output data at index.
     *
     * @param index - The index of the output data.
     * @param data - The data to set.
     *
     * @example
     * ```typescript
     * tx.setOutputDataAt(0, "0x00");
     * ```
     */
    setOutputDataAt(index, data) {
        if (this.outputsData.length < index) {
            this.outputsData.push(...Array.from(new Array(index - this.outputsData.length), () => "0x"));
        }
        this.outputsData[index] = (0, index_js_6.hexFrom)(data);
    }
    /**
     * get input
     *
     * @param index - The cell input index
     *
     * @example
     * ```typescript
     * await tx.getInput(0);
     * ```
     */
    getInput(index) {
        return this.inputs[Number((0, index_js_8.numFrom)(index))];
    }
    /**
     * add input
     *
     * @param inputLike - The cell input.
     *
     * @example
     * ```typescript
     * await tx.addInput({ });
     * ```
     */
    addInput(inputLike) {
        if (this.witnesses.length > this.inputs.length) {
            this.witnesses.splice(this.inputs.length, 0, "0x");
        }
        return this.inputs.push(CellInput.from(inputLike));
    }
    /**
     * get output
     *
     * @param index - The cell output index
     *
     * @example
     * ```typescript
     * await tx.getOutput(0);
     * ```
     */
    getOutput(index) {
        const i = Number((0, index_js_8.numFrom)(index));
        if (i >= this.outputs.length) {
            return;
        }
        return CellAny.from({
            cellOutput: this.outputs[i],
            outputData: this.outputsData[i] ?? "0x",
        });
    }
    /**
     * Provides an iterable over the transaction's output cells.
     *
     * This getter is a convenient way to iterate through all the output cells (`CellAny`)
     * of the transaction, combining the `outputs` and `outputsData` arrays.
     * It can be used with `for...of` loops or other iterable-consuming patterns.
     *
     * @public
     * @category Getter
     * @returns An `Iterable<CellAny>` that yields each output cell of the transaction.
     *
     * @example
     * ```typescript
     * for (const cell of tx.outputCells) {
     *   console.log(`Output cell capacity: ${cell.cellOutput.capacity}`);
     * }
     * ```
     */
    get outputCells() {
        const { outputs, outputsData } = this;
        function* generator() {
            for (let i = 0; i < outputs.length; i++) {
                yield CellAny.from({
                    cellOutput: outputs[i],
                    outputData: outputsData[i] ?? "0x",
                });
            }
        }
        return generator();
    }
    addOutput(cellOrOutputLike, outputDataLike) {
        const cell = "cellOutput" in cellOrOutputLike
            ? CellAny.from(cellOrOutputLike)
            : CellAny.from({
                cellOutput: cellOrOutputLike,
                outputData: outputDataLike,
            });
        const len = this.outputs.push(cell.cellOutput);
        this.setOutputDataAt(len - 1, cell.outputData);
        return len;
    }
    /**
     * Get witness at index as WitnessArgs
     *
     * @param index - The index of the witness.
     * @returns The witness parsed as WitnessArgs.
     *
     * @example
     * ```typescript
     * const witnessArgs = await tx.getWitnessArgsAt(0);
     * ```
     */
    getWitnessArgsAt(index) {
        const rawWitness = this.witnesses[index];
        return (rawWitness ?? "0x") !== "0x"
            ? WitnessArgs.fromBytes(rawWitness)
            : undefined;
    }
    /**
     * Set witness at index by WitnessArgs
     *
     * @param index - The index of the witness.
     * @param witness - The WitnessArgs to set.
     *
     * @example
     * ```typescript
     * await tx.setWitnessArgsAt(0, witnessArgs);
     * ```
     */
    setWitnessArgsAt(index, witness) {
        this.setWitnessAt(index, witness.toBytes());
    }
    /**
     * Set witness at index
     *
     * @param index - The index of the witness.
     * @param witness - The witness to set.
     *
     * @example
     * ```typescript
     * await tx.setWitnessAt(0, witness);
     * ```
     */
    setWitnessAt(index, witness) {
        if (this.witnesses.length < index) {
            this.witnesses.push(...Array.from(new Array(index - this.witnesses.length), () => "0x"));
        }
        this.witnesses[index] = (0, index_js_6.hexFrom)(witness);
    }
    /**
     * Prepare dummy witness for sighash all method
     *
     * @param scriptLike - The script associated with the transaction, represented as a ScriptLike object.
     * @param lockLen - The length of dummy lock bytes.
     * @param client - The client for complete extra infos in the transaction.
     * @returns A promise that resolves to the prepared transaction
     *
     * @example
     * ```typescript
     * await tx.prepareSighashAllWitness(scriptLike, 85, client);
     * ```
     */
    async prepareSighashAllWitness(scriptLike, lockLen, client) {
        const position = await this.findInputIndexByLock(scriptLike, client);
        if (position === undefined) {
            return;
        }
        const witness = this.getWitnessArgsAt(position) ?? WitnessArgs.from({});
        witness.lock = (0, index_js_6.hexFrom)(Array.from(new Array(lockLen), () => 0));
        this.setWitnessArgsAt(position, witness);
    }
    async getInputsCapacityExtra(client) {
        return (0, index_js_9.reduceAsync)(this.inputs, async (acc, input) => acc + (await input.getExtraCapacity(client)), index_js_4.Zero);
    }
    // This also includes extra amount
    async getInputsCapacity(client) {
        return ((await (0, index_js_9.reduceAsync)(this.inputs, async (acc, input) => {
            const { cellOutput: { capacity }, } = await input.getCell(client);
            return acc + capacity;
        }, index_js_4.Zero)) + (await this.getInputsCapacityExtra(client)));
    }
    getOutputsCapacity() {
        return this.outputs.reduce((acc, { capacity }) => acc + capacity, index_js_4.Zero);
    }
    async getInputsUdtBalance(client, type) {
        return (0, index_js_9.reduceAsync)(this.inputs, async (acc, input) => {
            const { cellOutput, outputData } = await input.getCell(client);
            if (!cellOutput.type?.eq(type)) {
                return;
            }
            return acc + udtBalanceFrom(outputData);
        }, index_js_4.Zero);
    }
    getOutputsUdtBalance(type) {
        return this.outputs.reduce((acc, output, i) => {
            if (!output.type?.eq(type)) {
                return acc;
            }
            return acc + udtBalanceFrom(this.outputsData[i]);
        }, index_js_4.Zero);
    }
    async completeInputs(from, filter, accumulator, init) {
        const collectedCells = [];
        let acc = init;
        let fulfilled = false;
        for await (const cell of from.findCells(filter, true)) {
            if (this.inputs.some(({ previousOutput }) => previousOutput.eq(cell.outPoint))) {
                continue;
            }
            const i = collectedCells.push(cell);
            const next = await Promise.resolve(accumulator(acc, cell, i - 1, collectedCells));
            if (next === undefined) {
                fulfilled = true;
                break;
            }
            acc = next;
        }
        collectedCells.forEach((cell) => this.addInput(cell));
        if (fulfilled) {
            return {
                addedCount: collectedCells.length,
            };
        }
        return {
            addedCount: collectedCells.length,
            accumulated: acc,
        };
    }
    async completeInputsByCapacity(from, capacityTweak, filter) {
        const expectedCapacity = this.getOutputsCapacity() + (0, index_js_8.numFrom)(capacityTweak ?? 0);
        const inputsCapacity = await this.getInputsCapacity(from.client);
        if (inputsCapacity >= expectedCapacity) {
            return 0;
        }
        const { addedCount, accumulated } = await this.completeInputs(from, filter ?? {
            scriptLenRange: [0, 1],
            outputDataLenRange: [0, 1],
        }, (acc, { cellOutput: { capacity } }) => {
            const sum = acc + capacity;
            return sum >= expectedCapacity ? undefined : sum;
        }, inputsCapacity);
        if (accumulated === undefined) {
            return addedCount;
        }
        throw new transactionErrors_js_1.ErrorTransactionInsufficientCapacity(expectedCapacity - accumulated);
    }
    async completeInputsAll(from, filter) {
        const { addedCount } = await this.completeInputs(from, filter ?? {
            scriptLenRange: [0, 1],
            outputDataLenRange: [0, 1],
        }, (acc, { cellOutput: { capacity } }) => acc + capacity, index_js_4.Zero);
        return addedCount;
    }
    /**
     * Complete inputs by UDT balance
     *
     * This method succeeds only if enough balance is collected.
     *
     * It will try to collect at least two inputs, even when the first input already contains enough balance, to avoid extra occupation fees introduced by the change cell. An edge case: If the first cell has the same amount as the output, a new cell is not needed.
     * @param from - The signer to complete the inputs.
     * @param type - The type script of the UDT.
     * @param balanceTweak - The tweak of the balance.
     * @returns A promise that resolves to the number of inputs added.
     */
    async completeInputsByUdt(from, type, balanceTweak) {
        const expectedBalance = this.getOutputsUdtBalance(type) + (0, index_js_8.numFrom)(balanceTweak ?? 0);
        if (expectedBalance === index_js_4.Zero) {
            return 0;
        }
        const [inputsBalance, inputsCount] = await (0, index_js_9.reduceAsync)(this.inputs, async ([balanceAcc, countAcc], input) => {
            const { cellOutput, outputData } = await input.getCell(from.client);
            if (!cellOutput.type?.eq(type)) {
                return;
            }
            return [balanceAcc + udtBalanceFrom(outputData), countAcc + 1];
        }, [index_js_4.Zero, 0]);
        if (inputsBalance === expectedBalance ||
            (inputsBalance >= expectedBalance && inputsCount >= 2)) {
            return 0;
        }
        const { addedCount, accumulated } = await this.completeInputs(from, {
            script: type,
            outputDataLenRange: [16, (0, index_js_8.numFrom)("0xffffffff")],
        }, (acc, { outputData }, _i, collected) => {
            const balance = udtBalanceFrom(outputData);
            const sum = acc + balance;
            return sum === expectedBalance ||
                (sum >= expectedBalance && inputsCount + collected.length >= 2)
                ? undefined
                : sum;
        }, inputsBalance);
        if (accumulated === undefined || accumulated >= expectedBalance) {
            return addedCount;
        }
        throw new transactionErrors_js_1.ErrorTransactionInsufficientCoin(expectedBalance - accumulated, type);
    }
    async completeInputsAddOne(from, filter) {
        const { addedCount, accumulated } = await this.completeInputs(from, filter ?? {
            scriptLenRange: [0, 1],
            outputDataLenRange: [0, 1],
        }, () => undefined, true);
        if (accumulated === undefined) {
            return addedCount;
        }
        throw new Error(`Insufficient CKB, need at least one new cell`);
    }
    async completeInputsAtLeastOne(from, filter) {
        if (this.inputs.length > 0) {
            return 0;
        }
        return this.completeInputsAddOne(from, filter);
    }
    async getFee(client) {
        return (await this.getInputsCapacity(client)) - this.getOutputsCapacity();
    }
    async getFeeRate(client) {
        return (((await this.getFee(client)) * (0, index_js_8.numFrom)(1000)) /
            (0, index_js_8.numFrom)(this.toBytes().length + 4));
    }
    estimateFee(feeRate) {
        const txSize = this.toBytes().length + 4;
        // + 999 then / 1000 to ceil the calculated fee
        return ((0, index_js_8.numFrom)(txSize) * (0, index_js_8.numFrom)(feeRate) + (0, index_js_8.numFrom)(999)) / (0, index_js_8.numFrom)(1000);
    }
    /**
     * Completes the transaction fee by adding inputs and handling change outputs.
     * This method automatically calculates the required fee based on the transaction size and fee rate,
     * adds necessary inputs to cover the fee, and handles change outputs through the provided change function.
     *
     * @param from - The signer to complete inputs from and prepare the transaction.
     * @param change - A function that handles change capacity. It receives the transaction and excess capacity,
     *                 and should return the additional capacity needed (0 if change is handled successfully,
     *                 positive number if more capacity is needed for change cell creation).
     * @param expectedFeeRate - The expected fee rate in shannons per 1000 bytes. If not provided,
     *                          it will be fetched from the client.
     * @param filter - Optional filter for selecting cells when adding inputs.
     * @param options - Optional configuration object.
     * @param options.feeRateBlockRange - Block range for fee rate calculation when expectedFeeRate is not provided.
     * @param options.maxFeeRate - Maximum allowed fee rate.
     * @param options.shouldAddInputs - Whether to add inputs automatically. Defaults to true.
     * @returns A promise that resolves to a tuple containing:
     *          - The number of inputs added during the process
     *          - A boolean indicating whether change outputs were created (true) or fee was paid without change (false)
     *
     * @throws {ErrorTransactionInsufficientCapacity} When there's not enough capacity to cover the fee.
     * @throws {Error} When the change function doesn't properly handle the available capacity.
     *
     * @example
     * ```typescript
     * const [addedInputs, hasChange] = await tx.completeFee(
     *   signer,
     *   (tx, capacity) => {
     *     if (capacity >= 61_00000000n) { // Minimum for a change cell
     *       tx.addOutput({ capacity, lock: changeScript });
     *       return 0;
     *     }
     *     return 61_00000000n; // Need more capacity for change cell
     *   },
     *   1000n // 1000 shannons per 1000 bytes
     * );
     * ```
     */
    async completeFee(from, change, expectedFeeRate, filter, options) {
        const feeRate = expectedFeeRate ??
            (await from.client.getFeeRate(options?.feeRateBlockRange, options));
        // Complete all inputs extra infos for cache
        await this.getInputsCapacity(from.client);
        let leastFee = index_js_4.Zero;
        let leastExtraCapacity = index_js_4.Zero;
        let collected = 0;
        // ===
        // Usually, for the worst situation, three iterations are needed
        // 1. First attempt to complete the transaction.
        // 2. Not enough capacity for the change cell.
        // 3. Fee increased by the change cell.
        // ===
        while (true) {
            collected += await (async () => {
                if (!(options?.shouldAddInputs ?? true)) {
                    return 0;
                }
                try {
                    return await this.completeInputsByCapacity(from, leastFee + leastExtraCapacity, filter);
                }
                catch (err) {
                    if (err instanceof transactionErrors_js_1.ErrorTransactionInsufficientCapacity &&
                        leastExtraCapacity !== index_js_4.Zero) {
                        throw new transactionErrors_js_1.ErrorTransactionInsufficientCapacity(err.amount, {
                            isForChange: true,
                        });
                    }
                    throw err;
                }
            })();
            const fee = await this.getFee(from.client);
            if (fee < leastFee + leastExtraCapacity) {
                // Not enough capacity are collected, it should only happens when shouldAddInputs is false
                throw new transactionErrors_js_1.ErrorTransactionInsufficientCapacity(leastFee + leastExtraCapacity - fee, { isForChange: leastExtraCapacity !== index_js_4.Zero });
            }
            await from.prepareTransaction(this);
            if (leastFee === index_js_4.Zero) {
                // The initial fee is calculated based on prepared transaction
                // This should only happens during the first iteration
                leastFee = this.estimateFee(feeRate);
            }
            // The extra capacity paid the fee without a change
            // leastExtraCapacity should be 0 here, otherwise we should failed in the previous check
            // So this only happens in the first iteration
            if (fee === leastFee) {
                return [collected, false];
            }
            // Invoke the change function on a transaction multiple times may cause problems, so we clone it
            const tx = this.clone();
            const needed = (0, index_js_8.numFrom)(await Promise.resolve(change(tx, fee - leastFee)));
            if (needed > index_js_4.Zero) {
                // No enough extra capacity to create new cells for change, collect inputs again
                leastExtraCapacity = needed;
                continue;
            }
            if ((await tx.getFee(from.client)) !== leastFee) {
                throw new Error("The change function doesn't use all available capacity");
            }
            // New change cells created, update the fee
            await from.prepareTransaction(tx);
            const changedFee = tx.estimateFee(feeRate);
            if (leastFee > changedFee) {
                throw new Error("The change function removed existed transaction data");
            }
            // The fee has been paid
            if (leastFee === changedFee) {
                this.copy(tx);
                return [collected, true];
            }
            // The fee after changing is more than the original fee
            leastFee = changedFee;
        }
    }
    /**
     * Completes the transaction fee by adding inputs and creating a change output with the specified lock script.
     * This is a convenience method that automatically creates a change cell with the provided lock script
     * when there's excess capacity after paying the transaction fee.
     *
     * @param from - The signer to complete inputs from and prepare the transaction.
     * @param change - The lock script for the change output cell.
     * @param feeRate - Optional fee rate in shannons per 1000 bytes. If not provided, it will be fetched from the client.
     * @param filter - Optional filter for selecting cells when adding inputs.
     * @param options - Optional configuration object.
     * @param options.feeRateBlockRange - Block range for fee rate calculation when feeRate is not provided.
     * @param options.maxFeeRate - Maximum allowed fee rate.
     * @param options.shouldAddInputs - Whether to add inputs automatically. Defaults to true.
     * @returns A promise that resolves to a tuple containing:
     *          - The number of inputs added during the process
     *          - A boolean indicating whether change outputs were created (true) or fee was paid without change (false)
     *
     * @example
     * ```typescript
     * const changeScript = Script.from({
     *   codeHash: "0x...",
     *   hashType: "type",
     *   args: "0x..."
     * });
     *
     * const [addedInputs, hasChange] = await tx.completeFeeChangeToLock(
     *   signer,
     *   changeScript,
     *   1000n // 1000 shannons per 1000 bytes
     * );
     * ```
     */
    completeFeeChangeToLock(from, change, feeRate, filter, options) {
        const script = script_js_1.Script.from(change);
        return this.completeFee(from, (tx, capacity) => {
            const changeCell = CellOutput.from({ capacity: 0, lock: script });
            const occupiedCapacity = (0, index_js_4.fixedPointFrom)(changeCell.occupiedSize);
            if (capacity < occupiedCapacity) {
                return occupiedCapacity;
            }
            changeCell.capacity = capacity;
            tx.addOutput(changeCell);
            return 0;
        }, feeRate, filter, options);
    }
    /**
     * Completes the transaction fee using the signer's recommended address for change.
     * This is a convenience method that automatically uses the signer's recommended
     * address as the change destination, making it easier to complete transactions
     * without manually specifying a change address.
     *
     * @param from - The signer to complete inputs from and prepare the transaction.
     * @param feeRate - Optional fee rate in shannons per 1000 bytes. If not provided, it will be fetched from the client.
     * @param filter - Optional filter for selecting cells when adding inputs.
     * @param options - Optional configuration object.
     * @param options.feeRateBlockRange - Block range for fee rate calculation when feeRate is not provided.
     * @param options.maxFeeRate - Maximum allowed fee rate.
     * @param options.shouldAddInputs - Whether to add inputs automatically. Defaults to true.
     * @returns A promise that resolves to a tuple containing:
     *          - The number of inputs added during the process
     *          - A boolean indicating whether change outputs were created (true) or fee was paid without change (false)
     *
     * @example
     * ```typescript
     * const [addedInputs, hasChange] = await tx.completeFeeBy(
     *   signer,
     *   1000n // 1000 shannons per 1000 bytes
     * );
     *
     * // Change will automatically go to signer's recommended address
     * ```
     */
    async completeFeeBy(from, feeRate, filter, options) {
        const { script } = await from.getRecommendedAddressObj();
        return this.completeFeeChangeToLock(from, script, feeRate, filter, options);
    }
    /**
     * Completes the transaction fee by adding excess capacity to an existing output.
     * Instead of creating a new change output, this method adds any excess capacity
     * to the specified existing output in the transaction.
     *
     * @param from - The signer to complete inputs from and prepare the transaction.
     * @param index - The index of the existing output to add excess capacity to.
     * @param feeRate - Optional fee rate in shannons per 1000 bytes. If not provided, it will be fetched from the client.
     * @param filter - Optional filter for selecting cells when adding inputs.
     * @param options - Optional configuration object.
     * @param options.feeRateBlockRange - Block range for fee rate calculation when feeRate is not provided.
     * @param options.maxFeeRate - Maximum allowed fee rate.
     * @param options.shouldAddInputs - Whether to add inputs automatically. Defaults to true.
     * @returns A promise that resolves to a tuple containing:
     *          - The number of inputs added during the process
     *          - A boolean indicating whether change was applied (true) or fee was paid without change (false)
     *
     * @throws {Error} When the specified output index doesn't exist.
     *
     * @example
     * ```typescript
     * // Add excess capacity to the first output (index 0)
     * const [addedInputs, hasChange] = await tx.completeFeeChangeToOutput(
     *   signer,
     *   0, // Output index
     *   1000n // 1000 shannons per 1000 bytes
     * );
     * ```
     */
    completeFeeChangeToOutput(from, index, feeRate, filter, options) {
        const change = Number((0, index_js_8.numFrom)(index));
        if (!this.outputs[change]) {
            throw new Error("Non-existed output to change");
        }
        return this.completeFee(from, (tx, capacity) => {
            tx.outputs[change].capacity += capacity;
            return 0;
        }, feeRate, filter, options);
    }
};
exports.Transaction = Transaction;
exports.Transaction = Transaction = Transaction_1 = __decorate([
    (0, index_js_3.codec)(index_js_7.mol
        .table({
        raw: exports.RawTransaction,
        witnesses: index_js_7.mol.BytesVec,
    })
        .mapIn((txLike) => {
        const tx = Transaction.from(txLike);
        return {
            raw: tx,
            witnesses: tx.witnesses,
        };
    })
        .mapOut((tx) => Transaction.from({ ...tx.raw, witnesses: tx.witnesses })))
], Transaction);
/**
 * Checks whether a NervosDAO transaction exceeds the 64-output limit.
 * Returns true if the transaction is DAO-related and has more than 64 outputs.
 * Short-circuits to false when outputs <= 64.
 *
 * @param tx - The transaction to check
 * @param client - CKB client for resolving the NervosDAO script and input cell info
 * @returns true if the DAO output limit is exceeded
 */
async function isDaoOutputLimitExceeded(tx, client) {
    if (tx.outputs.length <= 64) {
        return false;
    }
    const { codeHash, hashType } = await client.getKnownScript(knownScript_js_1.KnownScript.NervosDao);
    const dao = script_js_1.Script.from({ codeHash, hashType, args: "0x" });
    if (tx.outputs.some((o) => o.type?.eq(dao))) {
        return true;
    }
    for (const input of tx.inputs) {
        await input.completeExtraInfos(client);
        if (input.cellOutput?.type?.eq(dao)) {
            return true;
        }
    }
    return false;
}
/**
 * Calculate Nervos DAO profit between two blocks.
 * This function computes the profit earned from a Nervos DAO deposit
 * based on the capacity and the time period between deposit and withdrawal.
 *
 * @param profitableCapacity - The capacity that earns profit (total capacity minus occupied capacity).
 * @param depositHeaderLike - The block header when the DAO deposit was made.
 * @param withdrawHeaderLike - The block header when the DAO withdrawal is made.
 * @returns The profit amount in CKB (capacity units).
 *
 * @example
 * ```typescript
 * const profit = calcDaoProfit(
 *   ccc.fixedPointFrom(100), // 100 CKB profitable capacity
 *   depositHeader,
 *   withdrawHeader
 * );
 * console.log(`Profit: ${profit} shannons`);
 * ```
 *
 * @see {@link https://github.com/nervosnetwork/rfcs/blob/master/rfcs/0023-dao-deposit-withdraw/0023-dao-deposit-withdraw.md | Nervos DAO RFC}
 */
function calcDaoProfit(profitableCapacity, depositHeaderLike, withdrawHeaderLike) {
    const depositHeader = index_js_2.ClientBlockHeader.from(depositHeaderLike);
    const withdrawHeader = index_js_2.ClientBlockHeader.from(withdrawHeaderLike);
    const profitableSize = (0, index_js_8.numFrom)(profitableCapacity);
    return ((profitableSize * withdrawHeader.dao.ar) / depositHeader.dao.ar -
        profitableSize);
}
/**
 * Calculate claimable epoch for Nervos DAO withdrawal.
 * This function determines the earliest epoch when a Nervos DAO withdrawal
 * can be claimed based on the deposit and withdrawal epochs.
 *
 * @param depositHeader - The block header when the DAO deposit was made.
 * @param withdrawHeader - The block header when the DAO withdrawal was initiated.
 * @returns The epoch when the withdrawal can be claimed, represented as an Epoch instance.
 *
 * @example
 * ```typescript
 * const epoch = calcDaoClaimEpoch(depositHeader, withdrawHeader);
 * console.log(`Can claim at epoch: ${epoch.integer}, numerator: ${epoch.numerator}, denominator: ${epoch.denominator}`);
 * ```
 *
 * @remarks
 * The Nervos DAO has a minimum lock period of 180 epochs (~30 days).
 * This function calculates the exact epoch when the withdrawal becomes claimable
 * based on the deposit epoch and withdrawal epoch timing.
 *
 * @see {@link https://github.com/nervosnetwork/rfcs/blob/master/rfcs/0023-dao-deposit-withdraw/0023-dao-deposit-withdraw.md | Nervos DAO RFC}
 */
function calcDaoClaimEpoch(depositHeader, withdrawHeader) {
    const deposit = index_js_2.ClientBlockHeader.from(depositHeader).epoch.normalizeBase();
    const withdraw = index_js_2.ClientBlockHeader.from(withdrawHeader).epoch.normalizeBase();
    const fullCycle = (0, index_js_8.numFrom)(180);
    const partialCycle = (withdraw.integer - deposit.integer) % fullCycle;
    let withdrawInteger = withdraw.integer;
    if (partialCycle !== index_js_4.Zero ||
        //  deposit.numerator        withdraw.numerator
        // --------------------- <= ----------------------
        //  deposit.denominator      withdraw.denominator
        deposit.numerator * withdraw.denominator <=
            withdraw.numerator * deposit.denominator) {
        // Need to wait for the next cycle
        withdrawInteger += -partialCycle + fullCycle;
    }
    return new epoch_js_1.Epoch(withdrawInteger, deposit.numerator, deposit.denominator);
}
