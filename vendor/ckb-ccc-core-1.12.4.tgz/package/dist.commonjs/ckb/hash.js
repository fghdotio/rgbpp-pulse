"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.hashTypeId = hashTypeId;
const hasherCkb_js_1 = require("../hasher/hasherCkb.js");
const index_js_1 = require("../num/index.js");
const transaction_js_1 = require("./transaction.js");
/**
 * Computes the Type ID hash of the given data.
 * @public
 *
 * @param cellInputLike - The first cell input of the transaction.
 * @param outputIndex - The output index of the Type ID cell.
 * @returns The hexadecimal string representation of the hash.
 *
 * @example
 * ```typescript
 * const hash = hashTypeId(cellInput, outputIndex); // Outputs something like "0x..."
 * ```
 */
function hashTypeId(cellInputLike, outputIndex) {
    return (0, hasherCkb_js_1.hashCkb)(transaction_js_1.CellInput.from(cellInputLike).toBytes(), (0, index_js_1.numLeToBytes)(outputIndex, 8));
}
