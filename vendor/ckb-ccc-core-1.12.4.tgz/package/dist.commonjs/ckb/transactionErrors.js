"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ErrorTransactionInsufficientCoin = exports.ErrorTransactionInsufficientCapacity = void 0;
const index_js_1 = require("../fixedPoint/index.js");
const index_js_2 = require("../num/index.js");
const script_js_1 = require("./script.js");
class ErrorTransactionInsufficientCapacity extends Error {
    constructor(amountLike, reason) {
        const amount = (0, index_js_2.numFrom)(amountLike);
        const isForChange = reason?.isForChange ?? false;
        super(`Insufficient CKB, need ${(0, index_js_1.fixedPointToString)(amount)} extra CKB${isForChange ? " for the change cell" : ""}`);
        this.amount = amount;
        this.isForChange = isForChange;
    }
}
exports.ErrorTransactionInsufficientCapacity = ErrorTransactionInsufficientCapacity;
class ErrorTransactionInsufficientCoin extends Error {
    constructor(amountLike, typeLike) {
        const amount = (0, index_js_2.numFrom)(amountLike);
        const type = script_js_1.Script.from(typeLike);
        super(`Insufficient coin, need ${amount} extra coin`);
        this.amount = amount;
        this.type = type;
    }
}
exports.ErrorTransactionInsufficientCoin = ErrorTransactionInsufficientCoin;
