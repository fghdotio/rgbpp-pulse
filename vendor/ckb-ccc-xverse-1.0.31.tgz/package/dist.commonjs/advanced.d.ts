export * as XverseA from "./advancedBarrel.js";
//# sourceMappingURL=advanced.d.ts.map