export * as Xverse from "./barrel.js";
//# sourceMappingURL=index.d.ts.map