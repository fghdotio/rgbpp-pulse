"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.Signer = void 0;
const core_1 = require("@ckb-ccc/core");
const bitcoinjs_lib_1 = require("bitcoinjs-lib");
const v = __importStar(require("valibot"));
const advancedBarrel_js_1 = require("./advancedBarrel.js");
async function checkResponse(response) {
    const res = await response;
    if (v.is(advancedBarrel_js_1.rpcErrorResponseMessageSchema, res)) {
        // eslint-disable-next-line @typescript-eslint/only-throw-error
        throw res.error;
    }
    if (v.is(advancedBarrel_js_1.rpcSuccessResponseMessageSchema, res)) {
        return res.result;
    }
    // eslint-disable-next-line @typescript-eslint/only-throw-error
    throw {
        code: advancedBarrel_js_1.RpcErrorCode.INTERNAL_ERROR,
        message: "Received unknown response from provider.",
        data: res,
    };
}
/**
 * Class representing a Bitcoin signer that extends SignerBtc
 * @public
 */
class Signer extends core_1.ccc.SignerBtc {
    /**
     * Creates an instance of Signer.
     * @param client - The client instance.
     * @param provider - The provider instance.
     */
    constructor(client, provider, preferredNetworks = [
        {
            addressPrefix: "ckb",
            signerType: core_1.ccc.SignerType.BTC,
            network: "btc",
        },
        {
            addressPrefix: "ckt",
            signerType: core_1.ccc.SignerType.BTC,
            network: "btcTestnet",
        },
    ]) {
        super(client);
        this.provider = provider;
        this.preferredNetworks = preferredNetworks;
    }
    async assertAddress() {
        this.addressCache =
            this.addressCache ??
                (async () => {
                    if (!(await this.isConnected())) {
                        return;
                    }
                    return (await checkResponse(this.provider.request("getAddresses", {
                        purposes: [advancedBarrel_js_1.AddressPurpose.Payment],
                    }))).addresses[0];
                })();
        const address = await this.addressCache;
        if (address) {
            return address;
        }
        throw Error("Not connected");
    }
    /**
     * Gets the Bitcoin account address.
     * @returns A promise that resolves to the Bitcoin account address.
     */
    async getBtcAccount() {
        return (await this.assertAddress()).address;
    }
    /**
     * Gets the Bitcoin public key.
     * @returns A promise that resolves to the Bitcoin public key.
     */
    async getBtcPublicKey() {
        return core_1.ccc.hexFrom((await this.assertAddress()).publicKey);
    }
    /**
     * Connects to the provider by requesting accounts.
     * @returns A promise that resolves when the connection is established.
     */
    async connect() {
        if (await this.isConnected()) {
            return;
        }
        await checkResponse(this.provider.request("wallet_requestPermissions", undefined));
    }
    async disconnect() {
        this.addressCache = undefined;
    }
    onReplaced(listener) {
        const stop = [];
        const replacer = () => {
            listener();
            stop[0]?.();
        };
        stop.push(this.provider.addListener("accountChange", replacer), this.provider.addListener("networkChange", replacer));
        return stop[0];
    }
    /**
     * Checks if the signer is connected.
     * @returns A promise that resolves to true if connected, false otherwise.
     */
    async isConnected() {
        try {
            await checkResponse(this.provider.request("getBalance", undefined));
            return true;
        }
        catch (_error) {
            return false;
        }
    }
    /**
     * Signs a raw message with the Bitcoin account.
     * @param message - The message to sign.
     * @returns A promise that resolves to the signed message.
     */
    async signMessageRaw(message) {
        const challenge = typeof message === "string" ? message : core_1.ccc.hexFrom(message).slice(2);
        return (await checkResponse(this.provider.request("signMessage", {
            message: challenge,
            address: (await this.assertAddress()).address,
            protocol: advancedBarrel_js_1.MessageSigningProtocols.ECDSA,
        }))).signature;
    }
    /**
     * Build default inputsToSign for all unsigned inputs
     */
    buildDefaultinputsToSign(psbtHex, address) {
        const inputsToSign = [];
        try {
            // Collect all unsigned inputs
            const psbt = bitcoinjs_lib_1.Psbt.fromHex(psbtHex.slice(2));
            psbt.data.inputs.forEach((input, index) => {
                const isSigned = input.finalScriptSig ||
                    input.finalScriptWitness ||
                    input.tapKeySig ||
                    (input.partialSig && input.partialSig.length > 0) ||
                    (input.tapScriptSig && input.tapScriptSig.length > 0);
                if (!isSigned) {
                    inputsToSign.push({ index, address });
                }
            });
            // If no unsigned inputs found, the PSBT is already fully signed
            // Let the wallet handle this case (likely a no-op or error)
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            throw new Error(`Failed to parse PSBT hex. Please provide inputsToSign explicitly in options. Original error: ${errorMessage}`);
        }
        return inputsToSign;
    }
    async prepareSignPsbtParams(psbtHex, options) {
        let inputsToSign = options?.inputsToSign;
        if (!inputsToSign || !inputsToSign.length) {
            const address = await this.getBtcAccount();
            inputsToSign = this.buildDefaultinputsToSign(psbtHex, address);
        }
        const psbtBase64 = core_1.ccc.bytesTo(psbtHex, "base64");
        const signInputs = inputsToSign.reduce((acc, input) => {
            if (!input.address) {
                throw new Error("Xverse only supports signing with address. Please provide 'address' in inputsToSign.");
            }
            if (acc[input.address]) {
                acc[input.address].push(input.index);
            }
            else {
                acc[input.address] = [input.index];
            }
            return acc;
        }, {});
        return { psbtBase64, signInputs };
    }
    /**
     * Signs a PSBT using Xverse wallet.
     *
     * @param psbtHex - The hex string of PSBT to sign.
     * @param options - Options for signing the PSBT
     * @returns A promise that resolves to the signed PSBT as a Hex string
     *
     * @remarks
     * Xverse accepts:
     * - psbt: A string representing the PSBT to sign, encoded in base64
     * - signInputs: A Record<string, number[]> where:
     *   - keys are the addresses to use for signing
     *   - values are the indexes of the inputs to sign with each address
     *
     * Xverse returns:
     * - psbt: The base64 encoded signed PSBT
     *
     * @see https://docs.xverse.app/sats-connect/bitcoin-methods/signpsbt
     */
    async signPsbt(psbtHex, options) {
        const { psbtBase64, signInputs } = await this.prepareSignPsbtParams(core_1.ccc.hexFrom(psbtHex), options);
        const signedPsbtBase64 = (await checkResponse(this.provider.request("signPsbt", {
            psbt: psbtBase64,
            signInputs,
            broadcast: false,
        }))).psbt;
        return core_1.ccc.hexFrom(core_1.ccc.bytesFrom(signedPsbtBase64, "base64"));
    }
    /**
     * Broadcasts a PSBT to the Bitcoin network.
     *
     * @remarks
     * Xverse does not support broadcasting a signed PSBT directly.
     * It only supports "Sign and Broadcast" as a single atomic operation via `signAndBroadcastPsbt`.
     */
    async broadcastPsbt(_psbtHex, _options) {
        throw new Error("Xverse does not support broadcasting signed PSBTs directly. Use signAndBroadcastPsbt instead.");
    }
    async signAndBroadcastPsbt(psbtHex, options) {
        // ccc.hexFrom adds 0x prefix, but BTC expects non-0x
        const { psbtBase64, signInputs } = await this.prepareSignPsbtParams(core_1.ccc.hexFrom(psbtHex), options);
        const result = await checkResponse(this.provider.request("signPsbt", {
            psbt: psbtBase64,
            signInputs,
            broadcast: true,
        }));
        if (!result.txid) {
            throw new Error("Failed to broadcast PSBT");
        }
        return core_1.ccc.hexFrom(result.txid);
    }
}
exports.Signer = Signer;
