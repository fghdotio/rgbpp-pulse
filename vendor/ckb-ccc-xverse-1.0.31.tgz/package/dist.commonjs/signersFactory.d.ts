import { ccc } from "@ckb-ccc/core";
/**
 * Retrieves the Xverse signer if available.
 * @public
 *
 * @param client - The client instance.
 * @returns All Xverse Signer instances
 */
export declare function getXverseSigners(client: ccc.Client, preferredNetworks?: ccc.NetworkPreference[]): {
    wallet: ccc.Wallet;
    signerInfo: ccc.SignerInfo;
}[];
//# sourceMappingURL=signersFactory.d.ts.map