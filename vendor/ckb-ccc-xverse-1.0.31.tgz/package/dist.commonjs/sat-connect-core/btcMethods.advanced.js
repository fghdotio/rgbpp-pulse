"use strict";
// From https://github.com/secretkeylabs/sats-connect-core/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getBalanceRequestMessageSchema = exports.getBalanceResultSchema = exports.getBalanceParamsSchema = exports.getBalanceMethodName = exports.getAccountsRequestMessageSchema = exports.getAccountsResultSchema = exports.getAccountsParamsSchema = exports.getAccountsMethodName = exports.signMessageRequestMessageSchema = exports.signMessageResultSchema = exports.signMessageParamsSchema = exports.MessageSigningProtocols = exports.signMessageMethodName = exports.getAddressesRequestMessageSchema = exports.getAddressesResultSchema = exports.getAddressesParamsSchema = exports.getAddressesMethodName = exports.getInfoRequestMessageSchema = exports.getInfoResultSchema = exports.getInfoParamsSchema = exports.getInfoMethodName = exports.addressSchema = exports.AddressType = exports.AddressPurpose = void 0;
/**
 * Represents the types and interfaces related to BTC methods.
 */
const v = __importStar(require("valibot"));
const types_advanced_js_1 = require("./types.advanced.js");
const walletMethods_advanced_js_1 = require("./walletMethods.advanced.js");
var AddressPurpose;
(function (AddressPurpose) {
    AddressPurpose["Ordinals"] = "ordinals";
    AddressPurpose["Payment"] = "payment";
    AddressPurpose["Stacks"] = "stacks";
})(AddressPurpose || (exports.AddressPurpose = AddressPurpose = {}));
var AddressType;
(function (AddressType) {
    AddressType["p2pkh"] = "p2pkh";
    AddressType["p2sh"] = "p2sh";
    AddressType["p2wpkh"] = "p2wpkh";
    AddressType["p2wsh"] = "p2wsh";
    AddressType["p2tr"] = "p2tr";
    AddressType["stacks"] = "stacks";
})(AddressType || (exports.AddressType = AddressType = {}));
exports.addressSchema = v.object({
    address: v.string(),
    publicKey: v.string(),
    purpose: v.enum(AddressPurpose),
    addressType: v.enum(AddressType),
});
exports.getInfoMethodName = "getInfo";
exports.getInfoParamsSchema = v.nullish(v.null());
exports.getInfoResultSchema = v.object({
    /**
     * Version of the wallet.
     */
    version: v.string(),
    /**
     * [WBIP](https://wbips.netlify.app/wbips/WBIP002) methods supported by the wallet.
     */
    methods: v.optional(v.array(v.string())),
    /**
     * List of WBIP standards supported by the wallet. Not currently used.
     */
    supports: v.array(v.string()),
});
exports.getInfoRequestMessageSchema = v.object({
    ...types_advanced_js_1.rpcRequestMessageSchema.entries,
    ...v.object({
        method: v.literal(exports.getInfoMethodName),
        params: exports.getInfoParamsSchema,
        id: v.string(),
    }).entries,
});
exports.getAddressesMethodName = "getAddresses";
exports.getAddressesParamsSchema = v.object({
    /**
     * The purposes for which to generate addresses. See
     * {@linkcode AddressPurpose} for available purposes.
     */
    purposes: v.array(v.enum(AddressPurpose)),
    /**
     * A message to be displayed to the user in the request prompt.
     */
    message: v.optional(v.string()),
});
exports.getAddressesResultSchema = v.object({
    /**
     * The addresses generated for the given purposes.
     */
    addresses: v.array(exports.addressSchema),
});
exports.getAddressesRequestMessageSchema = v.object({
    ...types_advanced_js_1.rpcRequestMessageSchema.entries,
    ...v.object({
        method: v.literal(exports.getAddressesMethodName),
        params: exports.getAddressesParamsSchema,
        id: v.string(),
    }).entries,
});
exports.signMessageMethodName = "signMessage";
var MessageSigningProtocols;
(function (MessageSigningProtocols) {
    MessageSigningProtocols["ECDSA"] = "ECDSA";
    MessageSigningProtocols["BIP322"] = "BIP322";
})(MessageSigningProtocols || (exports.MessageSigningProtocols = MessageSigningProtocols = {}));
exports.signMessageParamsSchema = v.object({
    /**
     * The address used for signing.
     **/
    address: v.string(),
    /**
     * The message to sign.
     **/
    message: v.string(),
    /**
     * The protocol to use for signing the message.
     */
    protocol: v.optional(v.enum(MessageSigningProtocols)),
});
exports.signMessageResultSchema = v.object({
    /**
     * The signature of the message.
     */
    signature: v.string(),
    /**
     * hash of the message.
     */
    messageHash: v.string(),
    /**
     * The address used for signing.
     */
    address: v.string(),
    /**
     * The protocol to use for signing the message.
     */
    protocol: v.enum(MessageSigningProtocols),
});
exports.signMessageRequestMessageSchema = v.object({
    ...types_advanced_js_1.rpcRequestMessageSchema.entries,
    ...v.object({
        method: v.literal(exports.signMessageMethodName),
        params: exports.signMessageParamsSchema,
        id: v.string(),
    }).entries,
});
exports.getAccountsMethodName = "getAccounts";
exports.getAccountsParamsSchema = v.object({
    /**
     * The purposes for which to generate addresses. See
     * {@linkcode AddressPurpose} for available purposes.
     */
    purposes: v.array(v.enum(AddressPurpose)),
    /**
     * A message to be displayed to the user in the request prompt.
     */
    message: v.optional(v.string()),
});
exports.getAccountsResultSchema = v.array(v.object({
    ...exports.addressSchema.entries,
    ...v.object({
        walletType: walletMethods_advanced_js_1.walletTypeSchema,
    }).entries,
}));
exports.getAccountsRequestMessageSchema = v.object({
    ...types_advanced_js_1.rpcRequestMessageSchema.entries,
    ...v.object({
        method: v.literal(exports.getAccountsMethodName),
        params: exports.getAccountsParamsSchema,
        id: v.string(),
    }).entries,
});
exports.getBalanceMethodName = "getBalance";
exports.getBalanceParamsSchema = v.nullish(v.null());
exports.getBalanceResultSchema = v.object({
    /**
     * The confirmed balance of the wallet in sats. Using a string due to chrome
     * messages not supporting bigint
     * (https://issues.chromium.org/issues/40116184).
     */
    confirmed: v.string(),
    /**
     * The unconfirmed balance of the wallet in sats. Using a string due to chrome
     * messages not supporting bigint
     * (https://issues.chromium.org/issues/40116184).
     */
    unconfirmed: v.string(),
    /**
     * The total balance (both confirmed and unconfrimed UTXOs) of the wallet in
     * sats. Using a string due to chrome messages not supporting bigint
     * (https://issues.chromium.org/issues/40116184).
     */
    total: v.string(),
});
exports.getBalanceRequestMessageSchema = v.object({
    ...types_advanced_js_1.rpcRequestMessageSchema.entries,
    ...v.object({
        method: v.literal(exports.getBalanceMethodName),
        id: v.string(),
    }).entries,
});
