"use strict";
/* eslint-disable @typescript-eslint/no-explicit-any */
// From https://github.com/secretkeylabs/sats-connect-core/
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.rpcResponseMessageSchema = exports.rpcErrorResponseMessageSchema = exports.rpcSuccessResponseMessageSchema = exports.RpcErrorCode = exports.rpcRequestMessageSchema = exports.RpcIdSchema = exports.BitcoinNetworkType = void 0;
const v = __importStar(require("valibot"));
var BitcoinNetworkType;
(function (BitcoinNetworkType) {
    BitcoinNetworkType["Mainnet"] = "Mainnet";
    BitcoinNetworkType["Testnet"] = "Testnet";
    BitcoinNetworkType["Signet"] = "Signet";
})(BitcoinNetworkType || (exports.BitcoinNetworkType = BitcoinNetworkType = {}));
// RPC Request and Response types
exports.RpcIdSchema = v.optional(v.union([v.string(), v.number(), v.null()]));
exports.rpcRequestMessageSchema = v.object({
    jsonrpc: v.literal("2.0"),
    method: v.string(),
    params: v.optional(v.union([
        v.array(v.unknown()),
        v.looseObject({}),
        // Note: This is to support current incorrect usage of RPC 2.0. Params need
        // to be either an array or an object when provided. Changing this now would
        // be a breaking change, so accepting null values for now. Tracking in
        // https://linear.app/xverseapp/issue/ENG-4538.
        v.null(),
    ])),
    id: exports.RpcIdSchema,
});
/**
 * @enum {number} RpcErrorCode
 * @description JSON-RPC error codes
 * @see https://www.jsonrpc.org/specification#error_object
 */
var RpcErrorCode;
(function (RpcErrorCode) {
    /**
     * Parse error Invalid JSON
     **/
    RpcErrorCode[RpcErrorCode["PARSE_ERROR"] = -32700] = "PARSE_ERROR";
    /**
     * The JSON sent is not a valid Request object.
     **/
    RpcErrorCode[RpcErrorCode["INVALID_REQUEST"] = -32600] = "INVALID_REQUEST";
    /**
     * The method does not exist/is not available.
     **/
    RpcErrorCode[RpcErrorCode["METHOD_NOT_FOUND"] = -32601] = "METHOD_NOT_FOUND";
    /**
     * Invalid method parameter(s).
     */
    RpcErrorCode[RpcErrorCode["INVALID_PARAMS"] = -32602] = "INVALID_PARAMS";
    /**
     * Internal JSON-RPC error.
     * This is a generic error, used when the server encounters an error in performing the request.
     **/
    RpcErrorCode[RpcErrorCode["INTERNAL_ERROR"] = -32603] = "INTERNAL_ERROR";
    /**
     * user rejected/canceled the request
     */
    RpcErrorCode[RpcErrorCode["USER_REJECTION"] = -32000] = "USER_REJECTION";
    /**
     * method is not supported for the address provided
     */
    RpcErrorCode[RpcErrorCode["METHOD_NOT_SUPPORTED"] = -32001] = "METHOD_NOT_SUPPORTED";
    /**
     * The client does not have permission to access the requested resource.
     */
    RpcErrorCode[RpcErrorCode["ACCESS_DENIED"] = -32002] = "ACCESS_DENIED";
})(RpcErrorCode || (exports.RpcErrorCode = RpcErrorCode = {}));
exports.rpcSuccessResponseMessageSchema = v.object({
    jsonrpc: v.literal("2.0"),
    result: v.nonOptional(v.unknown()),
    id: exports.RpcIdSchema,
});
exports.rpcErrorResponseMessageSchema = v.object({
    jsonrpc: v.literal("2.0"),
    error: v.nonOptional(v.unknown()),
    id: exports.RpcIdSchema,
});
exports.rpcResponseMessageSchema = v.union([
    exports.rpcSuccessResponseMessageSchema,
    exports.rpcErrorResponseMessageSchema,
]);
