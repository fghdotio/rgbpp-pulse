import * as v from "valibot";
import { MethodParamsAndResult } from "./types.advanced.js";
export declare const walletTypes: readonly ["software", "ledger"];
export declare const walletTypeSchema: v.PicklistSchema<readonly ["software", "ledger"], undefined>;
export type WalletType = v.InferOutput<typeof walletTypeSchema>;
export declare const requestPermissionsMethodName = "wallet_requestPermissions";
export declare const requestPermissionsParamsSchema: v.UndefinedSchema<undefined>;
export declare const requestPermissionsResultSchema: v.LiteralSchema<true, undefined>;
export declare const requestPermissionsRequestMessageSchema: v.ObjectSchema<{
    readonly method: v.LiteralSchema<"wallet_requestPermissions", undefined>;
    readonly params: v.UndefinedSchema<undefined>;
    readonly id: v.StringSchema<undefined>;
    readonly jsonrpc: v.LiteralSchema<"2.0", undefined>;
}, undefined>;
export type RequestPermissions = MethodParamsAndResult<v.InferOutput<typeof requestPermissionsParamsSchema>, v.InferOutput<typeof requestPermissionsResultSchema>>;
export declare const renouncePermissionsMethodName = "wallet_renouncePermissions";
export declare const renouncePermissionsParamsSchema: v.UndefinedSchema<undefined>;
export declare const renouncePermissionsResultSchema: v.LiteralSchema<true, undefined>;
export declare const renouncePermissionsRequestMessageSchema: v.ObjectSchema<{
    readonly method: v.LiteralSchema<"wallet_renouncePermissions", undefined>;
    readonly params: v.UndefinedSchema<undefined>;
    readonly id: v.StringSchema<undefined>;
    readonly jsonrpc: v.LiteralSchema<"2.0", undefined>;
}, undefined>;
export type RenouncePermissions = MethodParamsAndResult<v.InferOutput<typeof renouncePermissionsParamsSchema>, v.InferOutput<typeof renouncePermissionsResultSchema>>;
export declare const getWalletTypeMethodName = "wallet_getWalletType";
export declare const getWalletTypeParamsSchema: v.NullishSchema<v.NullSchema<undefined>, undefined>;
export declare const getWalletTypeResultSchema: v.PicklistSchema<readonly ["software", "ledger"], undefined>;
export declare const getWalletTypeRequestMessageSchema: v.ObjectSchema<{
    readonly method: v.LiteralSchema<"wallet_getWalletType", undefined>;
    readonly id: v.StringSchema<undefined>;
    readonly jsonrpc: v.LiteralSchema<"2.0", undefined>;
    readonly params: v.OptionalSchema<v.UnionSchema<[v.ArraySchema<v.UnknownSchema, undefined>, v.LooseObjectSchema<{}, undefined>, v.NullSchema<undefined>], undefined>, undefined>;
}, undefined>;
export type GetWalletType = MethodParamsAndResult<v.InferOutput<typeof getWalletTypeParamsSchema>, v.InferOutput<typeof getWalletTypeResultSchema>>;
//# sourceMappingURL=walletMethods.advanced.d.ts.map