/**
 * Represents the types and interfaces related to BTC methods.
 */
import * as v from "valibot";
import { MethodParamsAndResult } from "./types.advanced.js";
export declare enum AddressPurpose {
    Ordinals = "ordinals",
    Payment = "payment",
    Stacks = "stacks"
}
export declare enum AddressType {
    p2pkh = "p2pkh",
    p2sh = "p2sh",
    p2wpkh = "p2wpkh",
    p2wsh = "p2wsh",
    p2tr = "p2tr",
    stacks = "stacks"
}
export declare const addressSchema: v.ObjectSchema<{
    readonly address: v.StringSchema<undefined>;
    readonly publicKey: v.StringSchema<undefined>;
    readonly purpose: v.EnumSchema<typeof AddressPurpose, undefined>;
    readonly addressType: v.EnumSchema<typeof AddressType, undefined>;
}, undefined>;
export type Address = v.InferOutput<typeof addressSchema>;
export declare const getInfoMethodName = "getInfo";
export declare const getInfoParamsSchema: v.NullishSchema<v.NullSchema<undefined>, undefined>;
export type GetInfoParams = v.InferOutput<typeof getInfoParamsSchema>;
export declare const getInfoResultSchema: v.ObjectSchema<{
    /**
     * Version of the wallet.
     */
    readonly version: v.StringSchema<undefined>;
    /**
     * [WBIP](https://wbips.netlify.app/wbips/WBIP002) methods supported by the wallet.
     */
    readonly methods: v.OptionalSchema<v.ArraySchema<v.StringSchema<undefined>, undefined>, undefined>;
    /**
     * List of WBIP standards supported by the wallet. Not currently used.
     */
    readonly supports: v.ArraySchema<v.StringSchema<undefined>, undefined>;
}, undefined>;
export type GetInfoResult = v.InferOutput<typeof getInfoResultSchema>;
export declare const getInfoRequestMessageSchema: v.ObjectSchema<{
    readonly method: v.LiteralSchema<"getInfo", undefined>;
    readonly params: v.NullishSchema<v.NullSchema<undefined>, undefined>;
    readonly id: v.StringSchema<undefined>;
    readonly jsonrpc: v.LiteralSchema<"2.0", undefined>;
}, undefined>;
export type GetInfoRequestMessage = v.InferOutput<typeof getInfoRequestMessageSchema>;
export type GetInfo = MethodParamsAndResult<v.InferOutput<typeof getInfoParamsSchema>, v.InferOutput<typeof getInfoResultSchema>>;
export declare const getAddressesMethodName = "getAddresses";
export declare const getAddressesParamsSchema: v.ObjectSchema<{
    /**
     * The purposes for which to generate addresses. See
     * {@linkcode AddressPurpose} for available purposes.
     */
    readonly purposes: v.ArraySchema<v.EnumSchema<typeof AddressPurpose, undefined>, undefined>;
    /**
     * A message to be displayed to the user in the request prompt.
     */
    readonly message: v.OptionalSchema<v.StringSchema<undefined>, undefined>;
}, undefined>;
export type GetAddressesParams = v.InferOutput<typeof getAddressesParamsSchema>;
export declare const getAddressesResultSchema: v.ObjectSchema<{
    /**
     * The addresses generated for the given purposes.
     */
    readonly addresses: v.ArraySchema<v.ObjectSchema<{
        readonly address: v.StringSchema<undefined>;
        readonly publicKey: v.StringSchema<undefined>;
        readonly purpose: v.EnumSchema<typeof AddressPurpose, undefined>;
        readonly addressType: v.EnumSchema<typeof AddressType, undefined>;
    }, undefined>, undefined>;
}, undefined>;
export type GetAddressesResult = v.InferOutput<typeof getAddressesResultSchema>;
export declare const getAddressesRequestMessageSchema: v.ObjectSchema<{
    readonly method: v.LiteralSchema<"getAddresses", undefined>;
    readonly params: v.ObjectSchema<{
        /**
         * The purposes for which to generate addresses. See
         * {@linkcode AddressPurpose} for available purposes.
         */
        readonly purposes: v.ArraySchema<v.EnumSchema<typeof AddressPurpose, undefined>, undefined>;
        /**
         * A message to be displayed to the user in the request prompt.
         */
        readonly message: v.OptionalSchema<v.StringSchema<undefined>, undefined>;
    }, undefined>;
    readonly id: v.StringSchema<undefined>;
    readonly jsonrpc: v.LiteralSchema<"2.0", undefined>;
}, undefined>;
export type GetAddressesRequestMessage = v.InferOutput<typeof getAddressesRequestMessageSchema>;
export type GetAddresses = MethodParamsAndResult<v.InferOutput<typeof getAddressesParamsSchema>, v.InferOutput<typeof getAddressesResultSchema>>;
export declare const signMessageMethodName = "signMessage";
export declare enum MessageSigningProtocols {
    ECDSA = "ECDSA",
    BIP322 = "BIP322"
}
export declare const signMessageParamsSchema: v.ObjectSchema<{
    /**
     * The address used for signing.
     **/
    readonly address: v.StringSchema<undefined>;
    /**
     * The message to sign.
     **/
    readonly message: v.StringSchema<undefined>;
    /**
     * The protocol to use for signing the message.
     */
    readonly protocol: v.OptionalSchema<v.EnumSchema<typeof MessageSigningProtocols, undefined>, undefined>;
}, undefined>;
export type SignMessageParams = v.InferOutput<typeof signMessageParamsSchema>;
export declare const signMessageResultSchema: v.ObjectSchema<{
    /**
     * The signature of the message.
     */
    readonly signature: v.StringSchema<undefined>;
    /**
     * hash of the message.
     */
    readonly messageHash: v.StringSchema<undefined>;
    /**
     * The address used for signing.
     */
    readonly address: v.StringSchema<undefined>;
    /**
     * The protocol to use for signing the message.
     */
    readonly protocol: v.EnumSchema<typeof MessageSigningProtocols, undefined>;
}, undefined>;
export type SignMessageResult = v.InferOutput<typeof signMessageResultSchema>;
export declare const signMessageRequestMessageSchema: v.ObjectSchema<{
    readonly method: v.LiteralSchema<"signMessage", undefined>;
    readonly params: v.ObjectSchema<{
        /**
         * The address used for signing.
         **/
        readonly address: v.StringSchema<undefined>;
        /**
         * The message to sign.
         **/
        readonly message: v.StringSchema<undefined>;
        /**
         * The protocol to use for signing the message.
         */
        readonly protocol: v.OptionalSchema<v.EnumSchema<typeof MessageSigningProtocols, undefined>, undefined>;
    }, undefined>;
    readonly id: v.StringSchema<undefined>;
    readonly jsonrpc: v.LiteralSchema<"2.0", undefined>;
}, undefined>;
export type SignMessageRequestMessage = v.InferOutput<typeof signMessageRequestMessageSchema>;
export type SignMessage = MethodParamsAndResult<v.InferOutput<typeof signMessageParamsSchema>, v.InferOutput<typeof signMessageResultSchema>>;
type Recipient = {
    /**
     * The recipient's address.
     **/
    address: string;
    /**
     * The amount to send to the recipient in satoshis.
     */
    amount: number;
};
export type SendTransferParams = {
    /**
     * Array of recipients to send to.
     * The amount to send to each recipient is in satoshis.
     */
    recipients: Array<Recipient>;
};
type SendTransferResult = {
    /**
     * The transaction id as a hex-encoded string.
     */
    txid: string;
};
export type SendTransfer = MethodParamsAndResult<SendTransferParams, SendTransferResult>;
export type SignPsbtParams = {
    /**
     * The base64 encoded PSBT to sign.
     */
    psbt: string;
    /**
     * The inputs to sign.
     * The key is the address and the value is an array of indexes of the inputs to sign.
     */
    signInputs: Record<string, number[]>;
    /**
     * the sigHash type to use for signing.
     * will default to the sighash type of the input if not provided.
     **/
    allowedSignHash?: number;
    /**
     * Whether to broadcast the transaction after signing.
     **/
    broadcast?: boolean;
};
export type SignPsbtResult = {
    /**
     * The base64 encoded PSBT after signing.
     */
    psbt: string;
    /**
     * The transaction id as a hex-encoded string.
     * This is only returned if the transaction was broadcast.
     **/
    txid?: string;
};
export type SignPsbt = MethodParamsAndResult<SignPsbtParams, SignPsbtResult>;
export declare const getAccountsMethodName = "getAccounts";
export declare const getAccountsParamsSchema: v.ObjectSchema<{
    /**
     * The purposes for which to generate addresses. See
     * {@linkcode AddressPurpose} for available purposes.
     */
    readonly purposes: v.ArraySchema<v.EnumSchema<typeof AddressPurpose, undefined>, undefined>;
    /**
     * A message to be displayed to the user in the request prompt.
     */
    readonly message: v.OptionalSchema<v.StringSchema<undefined>, undefined>;
}, undefined>;
export type GetAccountsParams = v.InferOutput<typeof getAccountsParamsSchema>;
export declare const getAccountsResultSchema: v.ArraySchema<v.ObjectSchema<{
    readonly walletType: v.PicklistSchema<readonly ["software", "ledger"], undefined>;
    readonly address: v.StringSchema<undefined>;
    readonly publicKey: v.StringSchema<undefined>;
    readonly purpose: v.EnumSchema<typeof AddressPurpose, undefined>;
    readonly addressType: v.EnumSchema<typeof AddressType, undefined>;
}, undefined>, undefined>;
export type GetAccountsResult = v.InferOutput<typeof getAccountsResultSchema>;
export declare const getAccountsRequestMessageSchema: v.ObjectSchema<{
    readonly method: v.LiteralSchema<"getAccounts", undefined>;
    readonly params: v.ObjectSchema<{
        /**
         * The purposes for which to generate addresses. See
         * {@linkcode AddressPurpose} for available purposes.
         */
        readonly purposes: v.ArraySchema<v.EnumSchema<typeof AddressPurpose, undefined>, undefined>;
        /**
         * A message to be displayed to the user in the request prompt.
         */
        readonly message: v.OptionalSchema<v.StringSchema<undefined>, undefined>;
    }, undefined>;
    readonly id: v.StringSchema<undefined>;
    readonly jsonrpc: v.LiteralSchema<"2.0", undefined>;
}, undefined>;
export type GetAccountsRequestMessage = v.InferOutput<typeof getAccountsRequestMessageSchema>;
export type GetAccounts = MethodParamsAndResult<v.InferOutput<typeof getAccountsParamsSchema>, v.InferOutput<typeof getAccountsResultSchema>>;
export declare const getBalanceMethodName = "getBalance";
export declare const getBalanceParamsSchema: v.NullishSchema<v.NullSchema<undefined>, undefined>;
export declare const getBalanceResultSchema: v.ObjectSchema<{
    /**
     * The confirmed balance of the wallet in sats. Using a string due to chrome
     * messages not supporting bigint
     * (https://issues.chromium.org/issues/40116184).
     */
    readonly confirmed: v.StringSchema<undefined>;
    /**
     * The unconfirmed balance of the wallet in sats. Using a string due to chrome
     * messages not supporting bigint
     * (https://issues.chromium.org/issues/40116184).
     */
    readonly unconfirmed: v.StringSchema<undefined>;
    /**
     * The total balance (both confirmed and unconfrimed UTXOs) of the wallet in
     * sats. Using a string due to chrome messages not supporting bigint
     * (https://issues.chromium.org/issues/40116184).
     */
    readonly total: v.StringSchema<undefined>;
}, undefined>;
export declare const getBalanceRequestMessageSchema: v.ObjectSchema<{
    readonly method: v.LiteralSchema<"getBalance", undefined>;
    readonly id: v.StringSchema<undefined>;
    readonly jsonrpc: v.LiteralSchema<"2.0", undefined>;
    readonly params: v.OptionalSchema<v.UnionSchema<[v.ArraySchema<v.UnknownSchema, undefined>, v.LooseObjectSchema<{}, undefined>, v.NullSchema<undefined>], undefined>, undefined>;
}, undefined>;
export type GetBalance = MethodParamsAndResult<v.InferOutput<typeof getBalanceParamsSchema>, v.InferOutput<typeof getBalanceResultSchema>>;
export {};
//# sourceMappingURL=btcMethods.advanced.d.ts.map