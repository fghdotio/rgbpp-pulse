import * as v from "valibot";
import { Params, Requests } from "./requests.advanced.js";
import { RpcResponse } from "./types.advanced.js";
export declare const accountChangeEventName = "accountChange";
export declare const accountChangeSchema: v.ObjectSchema<{
    readonly type: v.LiteralSchema<"accountChange", undefined>;
}, undefined>;
export type AccountChangeEvent = v.InferOutput<typeof accountChangeSchema>;
export declare const networkChangeEventName = "networkChange";
export declare const networkChangeSchema: v.ObjectSchema<{
    readonly type: v.LiteralSchema<"networkChange", undefined>;
}, undefined>;
export type NetworkChangeEvent = v.InferOutput<typeof networkChangeSchema>;
export declare const disconnectEventName = "disconnect";
export declare const disconnectSchema: v.ObjectSchema<{
    readonly type: v.LiteralSchema<"disconnect", undefined>;
}, undefined>;
export type DisconnectEvent = v.InferOutput<typeof disconnectSchema>;
export declare const walletEventSchema: v.VariantSchema<"type", [v.ObjectSchema<{
    readonly type: v.LiteralSchema<"accountChange", undefined>;
}, undefined>, v.ObjectSchema<{
    readonly type: v.LiteralSchema<"networkChange", undefined>;
}, undefined>, v.ObjectSchema<{
    readonly type: v.LiteralSchema<"disconnect", undefined>;
}, undefined>], undefined>;
export type WalletEvent = v.InferOutput<typeof walletEventSchema>;
export type AddListener = <const WalletEventName extends WalletEvent["type"]>(eventName: WalletEventName, cb: (event: Extract<WalletEvent, {
    type: WalletEventName;
}>) => void) => () => void;
/**
 * Interface representing a provider for interacting with accounts and signing messages.
 */
export interface BtcProvider {
    request: <Method extends keyof Requests>(method: Method, options: Params<Method>, providerId?: string) => Promise<RpcResponse<Method>>;
    addListener: AddListener;
}
export interface Provider {
    id: string;
    name: string;
    icon: string;
    webUrl?: string;
    chromeWebStoreUrl?: string;
    mozillaAddOnsUrl?: string;
    googlePlayStoreUrl?: string;
    iOSAppStoreUrl?: string;
    methods?: string[];
}
//# sourceMappingURL=provider.advanced.d.ts.map