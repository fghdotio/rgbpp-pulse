import * as v from "valibot";
import type { BtcProvider } from "./provider.advanced.js";
import type { Requests, Return } from "./requests.advanced.js";
export declare enum BitcoinNetworkType {
    Mainnet = "Mainnet",
    Testnet = "Testnet",
    Signet = "Signet"
}
export interface BitcoinNetwork {
    type: BitcoinNetworkType;
    address?: string;
}
export interface RequestPayload {
    network: BitcoinNetwork;
}
export interface RequestOptions<Payload extends RequestPayload, Response> {
    onFinish: (response: Response) => void;
    onCancel: () => void;
    payload: Payload;
    getProvider?: () => Promise<BtcProvider | undefined>;
}
export declare const RpcIdSchema: v.OptionalSchema<v.UnionSchema<[v.StringSchema<undefined>, v.NumberSchema<undefined>, v.NullSchema<undefined>], undefined>, undefined>;
export type RpcId = v.InferOutput<typeof RpcIdSchema>;
export declare const rpcRequestMessageSchema: v.ObjectSchema<{
    readonly jsonrpc: v.LiteralSchema<"2.0", undefined>;
    readonly method: v.StringSchema<undefined>;
    readonly params: v.OptionalSchema<v.UnionSchema<[v.ArraySchema<v.UnknownSchema, undefined>, v.LooseObjectSchema<{}, undefined>, v.NullSchema<undefined>], undefined>, undefined>;
    readonly id: v.OptionalSchema<v.UnionSchema<[v.StringSchema<undefined>, v.NumberSchema<undefined>, v.NullSchema<undefined>], undefined>, undefined>;
}, undefined>;
export type RpcRequestMessage = v.InferOutput<typeof rpcRequestMessageSchema>;
export interface RpcBase {
    jsonrpc: "2.0";
    id: RpcId;
}
export interface RpcRequest<T extends string, U> extends RpcBase {
    method: T;
    params: U;
}
export interface MethodParamsAndResult<TParams, TResult> {
    params: TParams;
    result: TResult;
}
/**
 * @enum {number} RpcErrorCode
 * @description JSON-RPC error codes
 * @see https://www.jsonrpc.org/specification#error_object
 */
export declare enum RpcErrorCode {
    /**
     * Parse error Invalid JSON
     **/
    PARSE_ERROR = -32700,
    /**
     * The JSON sent is not a valid Request object.
     **/
    INVALID_REQUEST = -32600,
    /**
     * The method does not exist/is not available.
     **/
    METHOD_NOT_FOUND = -32601,
    /**
     * Invalid method parameter(s).
     */
    INVALID_PARAMS = -32602,
    /**
     * Internal JSON-RPC error.
     * This is a generic error, used when the server encounters an error in performing the request.
     **/
    INTERNAL_ERROR = -32603,
    /**
     * user rejected/canceled the request
     */
    USER_REJECTION = -32000,
    /**
     * method is not supported for the address provided
     */
    METHOD_NOT_SUPPORTED = -32001,
    /**
     * The client does not have permission to access the requested resource.
     */
    ACCESS_DENIED = -32002
}
export declare const rpcSuccessResponseMessageSchema: v.ObjectSchema<{
    readonly jsonrpc: v.LiteralSchema<"2.0", undefined>;
    readonly result: v.NonOptionalSchema<v.UnknownSchema, undefined>;
    readonly id: v.OptionalSchema<v.UnionSchema<[v.StringSchema<undefined>, v.NumberSchema<undefined>, v.NullSchema<undefined>], undefined>, undefined>;
}, undefined>;
export type RpcSuccessResponseMessage = v.InferOutput<typeof rpcSuccessResponseMessageSchema>;
export declare const rpcErrorResponseMessageSchema: v.ObjectSchema<{
    readonly jsonrpc: v.LiteralSchema<"2.0", undefined>;
    readonly error: v.NonOptionalSchema<v.UnknownSchema, undefined>;
    readonly id: v.OptionalSchema<v.UnionSchema<[v.StringSchema<undefined>, v.NumberSchema<undefined>, v.NullSchema<undefined>], undefined>, undefined>;
}, undefined>;
export type RpcErrorResponseMessage = v.InferOutput<typeof rpcErrorResponseMessageSchema>;
export declare const rpcResponseMessageSchema: v.UnionSchema<[v.ObjectSchema<{
    readonly jsonrpc: v.LiteralSchema<"2.0", undefined>;
    readonly result: v.NonOptionalSchema<v.UnknownSchema, undefined>;
    readonly id: v.OptionalSchema<v.UnionSchema<[v.StringSchema<undefined>, v.NumberSchema<undefined>, v.NullSchema<undefined>], undefined>, undefined>;
}, undefined>, v.ObjectSchema<{
    readonly jsonrpc: v.LiteralSchema<"2.0", undefined>;
    readonly error: v.NonOptionalSchema<v.UnknownSchema, undefined>;
    readonly id: v.OptionalSchema<v.UnionSchema<[v.StringSchema<undefined>, v.NumberSchema<undefined>, v.NullSchema<undefined>], undefined>, undefined>;
}, undefined>], undefined>;
export type RpcResponseMessage = v.InferOutput<typeof rpcResponseMessageSchema>;
export interface RpcError {
    code: number | RpcErrorCode;
    message: string;
    data?: any;
}
export interface RpcErrorResponse<TError extends RpcError = RpcError> extends RpcBase {
    error: TError;
}
export interface RpcSuccessResponse<Method extends keyof Requests> extends RpcBase {
    result: Return<Method>;
}
export type RpcResponse<Method extends keyof Requests> = RpcSuccessResponse<Method> | RpcErrorResponse;
export type RpcResult<Method extends keyof Requests> = {
    result: RpcSuccessResponse<Method>["result"];
    status: "success";
} | {
    error: RpcErrorResponse["error"];
    status: "error";
};
//# sourceMappingURL=types.advanced.d.ts.map