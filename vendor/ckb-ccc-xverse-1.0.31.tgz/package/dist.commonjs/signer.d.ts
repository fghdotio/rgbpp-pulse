import { ccc } from "@ckb-ccc/core";
import { Address, BtcProvider } from "./advancedBarrel.js";
/**
 * Class representing a Bitcoin signer that extends SignerBtc
 * @public
 */
export declare class Signer extends ccc.SignerBtc {
    readonly provider: BtcProvider;
    private readonly preferredNetworks;
    private addressCache;
    /**
     * Creates an instance of Signer.
     * @param client - The client instance.
     * @param provider - The provider instance.
     */
    constructor(client: ccc.Client, provider: BtcProvider, preferredNetworks?: ccc.NetworkPreference[]);
    assertAddress(): Promise<Address>;
    /**
     * Gets the Bitcoin account address.
     * @returns A promise that resolves to the Bitcoin account address.
     */
    getBtcAccount(): Promise<string>;
    /**
     * Gets the Bitcoin public key.
     * @returns A promise that resolves to the Bitcoin public key.
     */
    getBtcPublicKey(): Promise<ccc.Hex>;
    /**
     * Connects to the provider by requesting accounts.
     * @returns A promise that resolves when the connection is established.
     */
    connect(): Promise<void>;
    disconnect(): Promise<void>;
    onReplaced(listener: () => void): () => void;
    /**
     * Checks if the signer is connected.
     * @returns A promise that resolves to true if connected, false otherwise.
     */
    isConnected(): Promise<boolean>;
    /**
     * Signs a raw message with the Bitcoin account.
     * @param message - The message to sign.
     * @returns A promise that resolves to the signed message.
     */
    signMessageRaw(message: string | ccc.BytesLike): Promise<string>;
    /**
     * Build default inputsToSign for all unsigned inputs
     */
    private buildDefaultinputsToSign;
    private prepareSignPsbtParams;
    /**
     * Signs a PSBT using Xverse wallet.
     *
     * @param psbtHex - The hex string of PSBT to sign.
     * @param options - Options for signing the PSBT
     * @returns A promise that resolves to the signed PSBT as a Hex string
     *
     * @remarks
     * Xverse accepts:
     * - psbt: A string representing the PSBT to sign, encoded in base64
     * - signInputs: A Record<string, number[]> where:
     *   - keys are the addresses to use for signing
     *   - values are the indexes of the inputs to sign with each address
     *
     * Xverse returns:
     * - psbt: The base64 encoded signed PSBT
     *
     * @see https://docs.xverse.app/sats-connect/bitcoin-methods/signpsbt
     */
    signPsbt(psbtHex: ccc.HexLike, options?: ccc.SignPsbtOptionsLike): Promise<ccc.Hex>;
    /**
     * Broadcasts a PSBT to the Bitcoin network.
     *
     * @remarks
     * Xverse does not support broadcasting a signed PSBT directly.
     * It only supports "Sign and Broadcast" as a single atomic operation via `signAndBroadcastPsbt`.
     */
    broadcastPsbt(_psbtHex: ccc.HexLike, _options?: ccc.SignPsbtOptionsLike): Promise<ccc.Hex>;
    signAndBroadcastPsbt(psbtHex: ccc.HexLike, options?: ccc.SignPsbtOptionsLike): Promise<ccc.Hex>;
}
//# sourceMappingURL=signer.d.ts.map