"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getXverseSigners = getXverseSigners;
const signer_js_1 = require("./signer.js");
function getProviderById(providerId) {
    return providerId
        ?.split(".")
        // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/no-unsafe-return
        .reduce((acc, part) => acc?.[part], window);
}
/**
 * Retrieves the Xverse signer if available.
 * @public
 *
 * @param client - The client instance.
 * @returns All Xverse Signer instances
 */
function getXverseSigners(client, preferredNetworks) {
    const windowRef = window;
    const signers = (() => {
        if (windowRef.btc_providers) {
            return windowRef.btc_providers.map((provider) => ({
                wallet: {
                    name: provider.name,
                    icon: provider.icon,
                },
                signerInfo: {
                    name: "BTC",
                    signer: new signer_js_1.Signer(client, getProviderById(provider.id), preferredNetworks),
                },
            }));
        }
        return [];
    })();
    return signers;
}
