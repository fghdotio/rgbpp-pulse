import { ccc } from "@ckb-ccc/core";
import { SporeScriptInfo, SporeScriptInfoLike } from "../predefined/index.js";
export declare function findSingletonCellByArgs(client: ccc.Client, args: ccc.HexLike, scripts: (SporeScriptInfoLike | undefined)[]): Promise<{
    cell: ccc.Cell;
    scriptInfo: SporeScriptInfo;
} | undefined>;
//# sourceMappingURL=index.d.ts.map