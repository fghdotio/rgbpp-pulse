"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.findSingletonCellByArgs = findSingletonCellByArgs;
const index_js_1 = require("../predefined/index.js");
async function findSingletonCellByArgs(client, args, scripts) {
    for (const scriptInfo of scripts) {
        if (!scriptInfo) {
            continue;
        }
        const cell = await client.findSingletonCellByType({
            ...scriptInfo,
            args,
        }, true);
        if (cell) {
            return {
                cell,
                scriptInfo: index_js_1.SporeScriptInfo.from(scriptInfo),
            };
        }
    }
}
