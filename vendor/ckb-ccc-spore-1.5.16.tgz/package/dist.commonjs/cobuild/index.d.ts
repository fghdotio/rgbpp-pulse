import { ccc } from "@ckb-ccc/core";
import { Action, ActionVec, WitnessLayout } from "../codec/index.js";
export declare function assembleCreateSporeAction(sporeOutput: ccc.CellOutputLike, sporeData: ccc.BytesLike, scriptInfoHash?: ccc.HexLike): ccc.EncodableType<typeof Action>;
export declare function assembleTransferSporeAction(sporeInput: ccc.CellOutputLike, sporeOutput: ccc.CellOutputLike, scriptInfoHash?: ccc.HexLike): ccc.EncodableType<typeof Action>;
export declare function assembleMeltSporeAction(sporeInput: ccc.CellOutputLike, scriptInfoHash?: ccc.HexLike): ccc.EncodableType<typeof Action>;
export declare function assembleCreateClusterAction(clusterOutput: ccc.CellOutputLike, clusterData: ccc.BytesLike, scriptInfoHash?: ccc.HexLike): ccc.EncodableType<typeof Action>;
export declare function assembleTransferClusterAction(clusterInput: ccc.CellOutputLike, clusterOutput: ccc.CellOutputLike, scriptInfoHash?: ccc.HexLike): ccc.EncodableType<typeof Action>;
export declare function prepareSporeTransaction(signer: ccc.Signer, txLike: ccc.TransactionLike, actions: ccc.EncodableType<typeof ActionVec>): Promise<ccc.Transaction>;
export declare function unpackCommonCobuildProof(data: ccc.HexLike): ccc.EncodableType<typeof WitnessLayout> | undefined;
export declare function extractCobuildActionsFromTx(tx: ccc.Transaction): ccc.EncodableType<typeof ActionVec>;
export declare function injectCobuild(tx: ccc.Transaction, actions: ccc.EncodableType<typeof ActionVec>): void;
//# sourceMappingURL=index.d.ts.map