"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.assembleCreateSporeAction = assembleCreateSporeAction;
exports.assembleTransferSporeAction = assembleTransferSporeAction;
exports.assembleMeltSporeAction = assembleMeltSporeAction;
exports.assembleCreateClusterAction = assembleCreateClusterAction;
exports.assembleTransferClusterAction = assembleTransferClusterAction;
exports.prepareSporeTransaction = prepareSporeTransaction;
exports.unpackCommonCobuildProof = unpackCommonCobuildProof;
exports.extractCobuildActionsFromTx = extractCobuildActionsFromTx;
exports.injectCobuild = injectCobuild;
const core_1 = require("@ckb-ccc/core");
const index_js_1 = require("../codec/index.js");
const index_js_2 = require("../predefined/index.js");
function assembleCreateSporeAction(sporeOutput, sporeData, scriptInfoHash = index_js_2.DEFAULT_COBUILD_INFO_HASH) {
    if (!sporeOutput.type) {
        throw new Error("Spore cell must have a type script");
    }
    const sporeType = core_1.ccc.Script.from(sporeOutput.type);
    const sporeTypeHash = sporeType.hash();
    const actionData = index_js_1.SporeAction.encode({
        type: "CreateSpore",
        value: {
            sporeId: sporeType.args,
            to: {
                type: "Script",
                value: sporeOutput.lock,
            },
            dataHash: core_1.ccc.hashCkb(sporeData),
        },
    });
    return {
        scriptInfoHash: core_1.ccc.hexFrom(scriptInfoHash),
        scriptHash: sporeTypeHash,
        data: core_1.ccc.hexFrom(actionData),
    };
}
function assembleTransferSporeAction(sporeInput, sporeOutput, scriptInfoHash = index_js_2.DEFAULT_COBUILD_INFO_HASH) {
    if (!sporeInput.type || !sporeOutput.type) {
        throw new Error("Spore cell must have a type script");
    }
    const sporeType = core_1.ccc.Script.from(sporeOutput.type);
    const sporeTypeHash = sporeType.hash();
    const actionData = index_js_1.SporeAction.encode({
        type: "TransferSpore",
        value: {
            sporeId: sporeType.args,
            from: {
                type: "Script",
                value: sporeInput.lock,
            },
            to: {
                type: "Script",
                value: sporeOutput.lock,
            },
        },
    });
    return {
        scriptInfoHash: core_1.ccc.hexFrom(scriptInfoHash),
        scriptHash: sporeTypeHash,
        data: core_1.ccc.hexFrom(actionData),
    };
}
function assembleMeltSporeAction(sporeInput, scriptInfoHash = index_js_2.DEFAULT_COBUILD_INFO_HASH) {
    if (!sporeInput.type) {
        throw new Error("Spore cell must have a type script");
    }
    const sporeType = core_1.ccc.Script.from(sporeInput.type);
    const sporeTypeHash = sporeType.hash();
    const actionData = index_js_1.SporeAction.encode({
        type: "MeltSpore",
        value: {
            sporeId: sporeType.args,
            from: {
                type: "Script",
                value: sporeInput.lock,
            },
        },
    });
    return {
        scriptInfoHash: core_1.ccc.hexFrom(scriptInfoHash),
        scriptHash: sporeTypeHash,
        data: core_1.ccc.hexFrom(actionData),
    };
}
function assembleCreateClusterAction(clusterOutput, clusterData, scriptInfoHash = index_js_2.DEFAULT_COBUILD_INFO_HASH) {
    if (!clusterOutput.type) {
        throw new Error("Cluster cell must have a type script");
    }
    const clusterType = core_1.ccc.Script.from(clusterOutput.type);
    const clusterTypeHash = clusterType.hash();
    const actionData = index_js_1.SporeAction.encode({
        type: "CreateCluster",
        value: {
            clusterId: clusterType.args,
            to: {
                type: "Script",
                value: clusterOutput.lock,
            },
            dataHash: core_1.ccc.hashCkb(clusterData),
        },
    });
    return {
        scriptInfoHash: core_1.ccc.hexFrom(scriptInfoHash),
        scriptHash: clusterTypeHash,
        data: core_1.ccc.hexFrom(actionData),
    };
}
function assembleTransferClusterAction(clusterInput, clusterOutput, scriptInfoHash = index_js_2.DEFAULT_COBUILD_INFO_HASH) {
    if (!clusterInput.type || !clusterOutput.type) {
        throw new Error("Cluster cell must have a type script");
    }
    const clusterType = core_1.ccc.Script.from(clusterOutput.type);
    const clusterTypeHash = clusterType.hash();
    const actionData = index_js_1.SporeAction.encode({
        type: "TransferCluster",
        value: {
            clusterId: clusterType.args,
            from: {
                type: "Script",
                value: clusterInput.lock,
            },
            to: {
                type: "Script",
                value: clusterOutput.lock,
            },
        },
    });
    return {
        scriptInfoHash: core_1.ccc.hexFrom(scriptInfoHash),
        scriptHash: clusterTypeHash,
        data: core_1.ccc.hexFrom(actionData),
    };
}
async function prepareSporeTransaction(signer, txLike, actions) {
    let tx = core_1.ccc.Transaction.from(txLike);
    if (actions.length === 0) {
        return signer.prepareTransaction(tx);
    }
    const existedActions = extractCobuildActionsFromTx(tx);
    tx = await signer.prepareTransaction(tx);
    injectCobuild(tx, [existedActions, actions].flat());
    return tx;
}
function unpackCommonCobuildProof(data) {
    try {
        return index_js_1.WitnessLayout.decode(core_1.ccc.bytesFrom(data));
    }
    catch {
        return;
    }
}
function extractCobuildActionsFromTx(tx) {
    if (tx.witnesses.length === 0) {
        return [];
    }
    const witnessLayout = unpackCommonCobuildProof(tx.witnesses[tx.witnesses.length - 1]);
    if (!witnessLayout) {
        return [];
    }
    if (witnessLayout.type !== "SighashAll") {
        throw new Error("Invalid cobuild proof type: SighashAll");
    }
    // Remove existed cobuild witness
    tx.witnesses.pop();
    return witnessLayout.value.message.actions;
}
function injectCobuild(tx, actions) {
    tx.setWitnessAt(Math.max(tx.witnesses.length, tx.inputs.length), index_js_1.WitnessLayout.encode({
        type: "SighashAll",
        value: {
            seal: "0x",
            message: {
                actions,
            },
        },
    }));
}
