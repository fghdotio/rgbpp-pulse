export * from "./advancedBarrel.js";
export * as sporeA from "./advancedBarrel.js";
//# sourceMappingURL=advanced.d.ts.map