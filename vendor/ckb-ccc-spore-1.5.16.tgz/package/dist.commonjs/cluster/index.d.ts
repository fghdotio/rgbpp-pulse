import { ccc } from "@ckb-ccc/core";
import { ClusterDataView } from "../codec/index.js";
import { SporeScriptInfo, SporeScriptInfoLike } from "../predefined/index.js";
export declare function findCluster(client: ccc.Client, id: ccc.HexLike, scripts?: SporeScriptInfoLike[]): Promise<{
    cell: ccc.Cell;
    cluster: ccc.Cell;
    clusterData: ClusterDataView;
    scriptInfo: SporeScriptInfo;
} | undefined>;
export declare function assertCluster(client: ccc.Client, args: ccc.HexLike, scripts?: SporeScriptInfoLike[]): Promise<{
    cell: ccc.Cell;
    scriptInfo: SporeScriptInfo;
}>;
/**
 * Create a new Cluster cell
 *
 * @param params.signer who takes the responsibility to balance and sign the transaction
 * @param params.data specific format of data required by Cluster protocol
 * @param params.to the owner of the Cluster cell, which will be replaced with signer if not provided
 * @param params.tx the transaction skeleton, if not provided, a new one will be created
 * @param params.scriptInfo the script info of new cluster, default spore version if undefined
 * @param params.scriptInfoHash the script info hash used in cobuild
 * @returns
 *  - **tx**: a new transaction that contains created Cluster cell
 *  - **id**: the id of the created Cluster cell
 */
export declare function createSporeCluster(params: {
    signer: ccc.Signer;
    data: ClusterDataView;
    to?: ccc.ScriptLike;
    tx?: ccc.TransactionLike;
    scriptInfo?: SporeScriptInfoLike;
    scriptInfoHash?: ccc.HexLike;
}): Promise<{
    tx: ccc.Transaction;
    id: ccc.Hex;
}>;
/**
 * Transfer a Cluster cell
 *
 * @param params.signer who takes the responsibility to balance and sign the transaction
 * @param params.id the id of the Cluster cell to be transferred
 * @param params.to the new owner of the Cluster cell
 * @param params.tx the transaction skeleton, if not provided, a new one will be created
 * @param params.scriptInfoHash the script info hash used in cobuild
 * @returns
 *  - **tx**: a new transaction that contains transferred Cluster cell
 */
export declare function transferSporeCluster(params: {
    signer: ccc.Signer;
    id: ccc.HexLike;
    to: ccc.ScriptLike;
    tx?: ccc.TransactionLike;
    scripts?: SporeScriptInfoLike[];
    scriptInfoHash?: ccc.HexLike;
}): Promise<{
    tx: ccc.Transaction;
}>;
/**
 * Search on-chain clusters under the signer's control
 *
 * @param params.signer the owner of clusters
 * @param params.order the order in creation time of clusters
 * @param params.scriptInfos the deployed script infos of clusters
 */
export declare function findSporeClustersBySigner(params: {
    signer: ccc.Signer;
    order?: "asc" | "desc";
    limit?: number;
    scriptInfos?: SporeScriptInfoLike[];
}): AsyncGenerator<{
    cell: ccc.Cell;
    cluster: ccc.Cell;
    clusterData: ClusterDataView;
    scriptInfo: SporeScriptInfo;
}>;
/**
 * Search on-chain clusters under the specified lock or not
 *
 * @param params.client the client to search clusters
 * @param params.lock the lock of clusters
 */
export declare function findSporeClusters(params: {
    client: ccc.Client;
    lock?: ccc.ScriptLike;
    order?: "asc" | "desc";
    limit?: number;
    scriptInfos?: SporeScriptInfoLike[];
}): AsyncGenerator<{
    cell: ccc.Cell;
    cluster: ccc.Cell;
    clusterData: ClusterDataView;
    scriptInfo: SporeScriptInfo;
}>;
//# sourceMappingURL=index.d.ts.map