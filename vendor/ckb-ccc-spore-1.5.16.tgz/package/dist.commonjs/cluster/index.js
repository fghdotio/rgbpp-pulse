"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.findCluster = findCluster;
exports.assertCluster = assertCluster;
exports.createSporeCluster = createSporeCluster;
exports.transferSporeCluster = transferSporeCluster;
exports.findSporeClustersBySigner = findSporeClustersBySigner;
exports.findSporeClusters = findSporeClusters;
const core_1 = require("@ckb-ccc/core");
const advanced_js_1 = require("../advanced.js");
const index_js_1 = require("../codec/index.js");
const index_js_2 = require("../helper/index.js");
const index_js_3 = require("../predefined/index.js");
async function findCluster(client, id, scripts) {
    const found = await (0, index_js_2.findSingletonCellByArgs)(client, id, scripts ?? Object.values((0, index_js_3.getClusterScriptInfos)(client)));
    if (!found) {
        return;
    }
    return {
        cell: found.cell,
        cluster: found.cell,
        clusterData: (0, index_js_1.unpackToRawClusterData)(found.cell.outputData),
        scriptInfo: found.scriptInfo,
    };
}
async function assertCluster(client, args, scripts) {
    const res = await findCluster(client, args, scripts);
    if (!res) {
        throw new Error(`Cluster ${core_1.ccc.hexFrom(args)} not found`);
    }
    return res;
}
/**
 * Create a new Cluster cell
 *
 * @param params.signer who takes the responsibility to balance and sign the transaction
 * @param params.data specific format of data required by Cluster protocol
 * @param params.to the owner of the Cluster cell, which will be replaced with signer if not provided
 * @param params.tx the transaction skeleton, if not provided, a new one will be created
 * @param params.scriptInfo the script info of new cluster, default spore version if undefined
 * @param params.scriptInfoHash the script info hash used in cobuild
 * @returns
 *  - **tx**: a new transaction that contains created Cluster cell
 *  - **id**: the id of the created Cluster cell
 */
async function createSporeCluster(params) {
    const { signer, data, to, scriptInfoHash } = params;
    const scriptInfo = params.scriptInfo ?? (0, index_js_3.getClusterScriptInfo)(signer.client);
    // prepare transaction
    const tx = core_1.ccc.Transaction.from(params.tx ?? {});
    await tx.completeInputsAtLeastOne(signer);
    // build cluster cell
    const id = core_1.ccc.hashTypeId(tx.inputs[0], tx.outputs.length);
    const packedClusterData = (0, index_js_1.packRawClusterData)(data);
    tx.addOutput({
        lock: to ?? (await signer.getRecommendedAddressObj()).script,
        type: {
            ...scriptInfo,
            args: id,
        },
    }, packedClusterData);
    // complete cellDeps
    await tx.addCellDepInfos(signer.client, scriptInfo.cellDeps);
    // generate cobuild action
    const actions = scriptInfo.cobuild
        ? [
            (0, advanced_js_1.assembleCreateClusterAction)(tx.outputs[tx.outputs.length - 1], packedClusterData, scriptInfoHash),
        ]
        : [];
    return {
        tx: await (0, advanced_js_1.prepareSporeTransaction)(signer, tx, actions),
        id,
    };
}
/**
 * Transfer a Cluster cell
 *
 * @param params.signer who takes the responsibility to balance and sign the transaction
 * @param params.id the id of the Cluster cell to be transferred
 * @param params.to the new owner of the Cluster cell
 * @param params.tx the transaction skeleton, if not provided, a new one will be created
 * @param params.scriptInfoHash the script info hash used in cobuild
 * @returns
 *  - **tx**: a new transaction that contains transferred Cluster cell
 */
async function transferSporeCluster(params) {
    const { signer, id, to, scripts, scriptInfoHash } = params;
    // prepare transaction
    const tx = core_1.ccc.Transaction.from(params.tx ?? {});
    // build cluster cell
    const { cell: cluster, scriptInfo: clusterScriptInfo } = await assertCluster(signer.client, id, scripts);
    tx.addInput(cluster);
    tx.addOutput({
        lock: to,
        type: cluster.cellOutput.type,
    }, cluster.outputData);
    // complete cellDeps
    await tx.addCellDepInfos(signer.client, clusterScriptInfo.cellDeps);
    // generate cobuild action
    const actions = clusterScriptInfo.cobuild
        ? [
            (0, advanced_js_1.assembleTransferClusterAction)(cluster.cellOutput, tx.outputs[tx.outputs.length - 1], scriptInfoHash),
        ]
        : [];
    return {
        tx: await (0, advanced_js_1.prepareSporeTransaction)(signer, tx, actions),
    };
}
/**
 * Search on-chain clusters under the signer's control
 *
 * @param params.signer the owner of clusters
 * @param params.order the order in creation time of clusters
 * @param params.scriptInfos the deployed script infos of clusters
 */
async function* findSporeClustersBySigner(params) {
    const { signer, order, limit, scriptInfos } = params;
    for (const scriptInfo of scriptInfos ??
        Object.values((0, index_js_3.getClusterScriptInfos)(signer.client))) {
        if (!scriptInfo) {
            continue;
        }
        for await (const cluster of signer.findCells({
            script: {
                ...scriptInfo,
                args: "",
            },
        }, true, order, limit)) {
            yield {
                cell: cluster,
                cluster,
                clusterData: (0, index_js_1.unpackToRawClusterData)(cluster.outputData),
                scriptInfo: index_js_3.SporeScriptInfo.from(scriptInfo),
            };
        }
    }
}
/**
 * Search on-chain clusters under the specified lock or not
 *
 * @param params.client the client to search clusters
 * @param params.lock the lock of clusters
 */
async function* findSporeClusters(params) {
    const { client, lock, order, limit, scriptInfos } = params;
    for (const scriptInfo of scriptInfos ??
        Object.values((0, index_js_3.getClusterScriptInfos)(client))) {
        if (!scriptInfo) {
            continue;
        }
        for await (const cluster of client.findCells({
            script: {
                ...scriptInfo,
                args: "",
            },
            scriptType: "type",
            scriptSearchMode: "prefix",
            withData: true,
            filter: lock
                ? {
                    script: lock,
                }
                : undefined,
        }, order, limit)) {
            yield {
                cell: cluster,
                cluster,
                clusterData: (0, index_js_1.unpackToRawClusterData)(cluster.outputData),
                scriptInfo: index_js_3.SporeScriptInfo.from(scriptInfo),
            };
        }
    }
}
