import { DNA, Dob0, Dob1 } from "../helper/index.js";
export declare function encodeDna(dna: DNA): ArrayBuffer;
export declare function encodeClusterDescriptionForDob0(dob0: Dob0): string;
export declare function encodeClusterDescriptionForDob1(dob1: Dob1): string;
//# sourceMappingURL=encode.d.ts.map