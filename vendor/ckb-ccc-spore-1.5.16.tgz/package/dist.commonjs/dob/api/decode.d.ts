import { ccc } from "@ckb-ccc/core";
import { RenderOutput } from "../helper/object.js";
export declare function extractDobFromDecoderResult(result: string): RenderOutput;
export declare function decodeDobBySporeId(sporeId: ccc.HexLike, dobServerUrl: string): Promise<RenderOutput>;
export declare function decodeDobBySporeCell(sporeOutput: ccc.CellOutputLike, dobServerUrl: string): Promise<RenderOutput>;
export declare function decodeDobBySporeOutpoint(client: ccc.Client, sporeOutpoint: ccc.OutPointLike, dobServerUrl: string): Promise<RenderOutput>;
export declare function decodeDobByRawData(sporeCellData: ccc.HexLike, clusterCellData: ccc.HexLike, dobServerUrl: string): Promise<RenderOutput>;
//# sourceMappingURL=decode.d.ts.map