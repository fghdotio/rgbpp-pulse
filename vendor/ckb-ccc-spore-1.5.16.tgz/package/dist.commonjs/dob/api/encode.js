"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.encodeDna = encodeDna;
exports.encodeClusterDescriptionForDob0 = encodeClusterDescriptionForDob0;
exports.encodeClusterDescriptionForDob1 = encodeClusterDescriptionForDob1;
const core_1 = require("@ckb-ccc/core");
const index_js_1 = require("../helper/index.js");
function encodeDna(dna) {
    const data = core_1.ccc.bytesFrom(JSON.stringify(dna), "utf8");
    const arrayBuffer = new ArrayBuffer(data.byteLength);
    const view = new Uint8Array(arrayBuffer);
    view.set(data);
    return arrayBuffer;
}
function encodeClusterDescriptionForDob0(dob0) {
    (0, index_js_1.checkDecoder)(dob0.dob.decoder);
    dob0.dob.pattern.forEach((v) => {
        (0, index_js_1.checkPatternDob0)(v);
        v.toJSON = function () {
            if (v.traitArgs) {
                return [
                    v.traitName,
                    v.dobType,
                    v.dnaOffset,
                    v.dnaLength,
                    v.patternType,
                    v.traitArgs,
                ];
            }
            else {
                return [
                    v.traitName,
                    v.dobType,
                    v.dnaOffset,
                    v.dnaLength,
                    v.patternType,
                ];
            }
        };
    });
    return JSON.stringify(dob0);
}
function encodeClusterDescriptionForDob1(dob1) {
    dob1.dob.decoders.forEach((value) => {
        (0, index_js_1.checkDecoder)(value.decoder);
        value.pattern.forEach((v) => {
            if ("dnaOffset" in v) {
                (0, index_js_1.checkPatternDob0)(v);
                v.toJSON = function () {
                    if (v.traitArgs) {
                        return [
                            v.traitName,
                            v.dobType,
                            v.dnaOffset,
                            v.dnaLength,
                            v.patternType,
                            v.traitArgs,
                        ];
                    }
                    else {
                        return [
                            v.traitName,
                            v.dobType,
                            v.dnaOffset,
                            v.dnaLength,
                            v.patternType,
                        ];
                    }
                };
            }
            else {
                (0, index_js_1.checkPatternDob1)(v);
                v.toJSON = () => {
                    return [
                        v.imageName,
                        v.svgFields,
                        v.traitName,
                        v.patternType,
                        v.traitArgs,
                    ];
                };
            }
        });
    });
    return JSON.stringify(dob1);
}
