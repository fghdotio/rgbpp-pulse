"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.extractDobFromDecoderResult = extractDobFromDecoderResult;
exports.decodeDobBySporeId = decodeDobBySporeId;
exports.decodeDobBySporeCell = decodeDobBySporeCell;
exports.decodeDobBySporeOutpoint = decodeDobBySporeOutpoint;
exports.decodeDobByRawData = decodeDobByRawData;
const core_1 = require("@ckb-ccc/core");
const axios_1 = require("axios");
const error_js_1 = require("../helper/error.js");
function extractDobFromDecoderResult(result) {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    const decoderResult = JSON.parse(result);
    if ("error" in decoderResult) {
        const serverError = (0, error_js_1.getErrorByCode)(decoderResult.error.code);
        throw new Error(`Decode DOB failed: ${serverError}`);
    }
    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-argument
    const renderResult = JSON.parse(decoderResult.result);
    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-argument
    const renderOutput = JSON.parse(renderResult.render_output);
    // eslint-disable-next-line @typescript-eslint/no-unsafe-return
    return renderOutput;
}
async function decodeDobBySporeId(sporeId, dobServerUrl) {
    const axios = new axios_1.Axios({
        baseURL: dobServerUrl,
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
    });
    const result = await axios.post("/", JSON.stringify({
        id: 0,
        jsonrpc: "2.0",
        method: "dob_decode",
        params: [core_1.ccc.hexFrom(sporeId).replace(/^0x/, "")],
    }));
    return extractDobFromDecoderResult(result.data);
}
async function decodeDobBySporeCell(sporeOutput, dobServerUrl) {
    const sporeId = sporeOutput.type?.args;
    if (sporeId === undefined) {
        throw new Error("Invalid spore cell: missing spore id");
    }
    return decodeDobBySporeId(core_1.ccc.hexFrom(sporeId), dobServerUrl);
}
async function decodeDobBySporeOutpoint(client, sporeOutpoint, dobServerUrl) {
    const liveCell = await client.getCell(sporeOutpoint);
    if (!liveCell) {
        throw new Error("Invalid spore outpoint: missing spore cell");
    }
    return decodeDobBySporeCell(liveCell.cellOutput, dobServerUrl);
}
async function decodeDobByRawData(sporeCellData, clusterCellData, dobServerUrl) {
    const axios = new axios_1.Axios({
        baseURL: dobServerUrl,
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
    });
    const result = await axios.post("/", JSON.stringify({
        id: 0,
        jsonrpc: "2.0",
        method: "dob_raw_decode",
        params: [core_1.ccc.hexFrom(sporeCellData), core_1.ccc.hexFrom(clusterCellData)],
    }));
    return extractDobFromDecoderResult(result.data);
}
