import { ccc } from "@ckb-ccc/core";
import { Decoder } from "../helper/index.js";
export type DobType = "dob0" | "dob1";
export type DobScriptInfo = Record<DobType, Decoder>;
export declare const DOB_TESTNET_DECODERS: DobScriptInfo;
export declare const DOB_MAINNET_DECODERS: DobScriptInfo;
export declare function getDecoder(client: ccc.Client, dobType: DobType, dobScriptInfo?: DobScriptInfo): Decoder;
//# sourceMappingURL=predefined.d.ts.map