"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DOB_MAINNET_DECODERS = exports.DOB_TESTNET_DECODERS = void 0;
exports.getDecoder = getDecoder;
exports.DOB_TESTNET_DECODERS = Object.freeze({
    ["dob0"]: {
        type: "code_hash",
        hash: "0x13cac78ad8482202f18f9df4ea707611c35f994375fa03ae79121312dda9925c",
    },
    // another avaliable options:
    // {
    //   type: "type_id",
    //   hash: "0x784e32cef202b9d4759ea96e80d806f94051e8069fd34d761f452553700138d7",
    // }
    // or
    // {
    //   type: "type_script",
    //   script: {
    //     code_hash:
    //       "0x00000000000000000000000000000000000000000000000000545950455f4944",
    //     hash_type: "type",
    //     args: "0x784e32cef202b9d4759ea96e80d806f94051e8069fd34d761f452553700138d7",
    //   }
    // }
    ["dob1"]: {
        type: "code_hash",
        hash: "0xda3525549b72970b4c95f5b5749357f20d1293d335710b674f09c32f7d54b6dc",
    },
});
exports.DOB_MAINNET_DECODERS = Object.freeze({
    ["dob0"]: {
        type: "code_hash",
        hash: "0x13cac78ad8482202f18f9df4ea707611c35f994375fa03ae79121312dda9925c",
    },
    // another avaliable options:
    // {
    //   type: "type_id",
    //   hash: "0x8892bea4405a1f077921799bc0f4516e0ebaef7aea0dfc6614a8898fb47d5372",
    // },
    // or
    // {
    //   type: "type_script",
    //   script: {
    //     code_hash:
    //       "0x00000000000000000000000000000000000000000000000000545950455f4944",
    //     hash_type: "type",
    //     args: "0x8892bea4405a1f077921799bc0f4516e0ebaef7aea0dfc6614a8898fb47d5372",
    //   }
    // }
    ["dob1"]: {
        type: "code_hash",
        hash: "0xda3525549b72970b4c95f5b5749357f20d1293d335710b674f09c32f7d54b6dc",
    },
});
function getDecoder(client, dobType, dobScriptInfo) {
    if (dobScriptInfo) {
        return dobScriptInfo[dobType];
    }
    if (client.addressPrefix === "ckb") {
        return exports.DOB_MAINNET_DECODERS[dobType];
    }
    return exports.DOB_TESTNET_DECODERS[dobType];
}
