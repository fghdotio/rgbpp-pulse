export * from "./predefined.js";
//# sourceMappingURL=index.d.ts.map