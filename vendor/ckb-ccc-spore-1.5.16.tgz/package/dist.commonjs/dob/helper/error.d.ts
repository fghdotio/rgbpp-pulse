export declare function getErrorByCode(code: number): string;
//# sourceMappingURL=error.d.ts.map