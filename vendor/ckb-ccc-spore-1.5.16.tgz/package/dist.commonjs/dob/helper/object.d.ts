export type DNA = string | {
    dna: string;
} | string[];
export interface Decoder {
    type: "code_hash" | "type_id" | "type_script";
    hash?: string;
    script?: {
        code_hash: string;
        hash_type: string;
        args: string;
    };
}
export interface PatternElementDob0 {
    traitName: string;
    dobType: string;
    dnaOffset: number;
    dnaLength: number;
    patternType: "options" | "range" | "rawNumber" | "rawString" | "utf8";
    traitArgs?: string[] | number[];
    toJSON?: () => unknown;
}
export interface PatternDob0 {
    ver: 0;
    decoder: Decoder;
    pattern: PatternElementDob0[];
}
export interface Dob0 {
    description: string;
    dob: PatternDob0;
}
export type Dob1PatternArgs = string | number[] | ["*"];
export interface PatternElementDob1 {
    imageName: string;
    svgFields: "attributes" | "elements";
    traitName: string;
    patternType: "options" | "raw";
    traitArgs: Dob1PatternArgs[][] | string;
    toJSON?: () => unknown;
}
export interface PatternDob1 {
    ver: 1;
    decoders: {
        decoder: Decoder;
        pattern: PatternElementDob0[] | PatternElementDob1[];
    }[];
}
export interface Dob1 {
    description: string;
    dob: PatternDob1;
}
export interface DecodeElement {
    name: string;
    traits: {
        type: string;
        value: number | string;
    }[];
}
export type RenderOutput = DecodeElement[];
//# sourceMappingURL=object.d.ts.map