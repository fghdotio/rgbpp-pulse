import { Decoder, PatternElementDob0, PatternElementDob1 } from "./object.js";
export declare function checkDecoder(decoder: Decoder): void;
export declare function checkPatternDob0(value: PatternElementDob0): void;
export declare function checkPatternDob1(value: PatternElementDob1): void;
//# sourceMappingURL=check.d.ts.map