import { ccc } from "@ckb-ccc/core";
export declare const DEFAULT_COBUILD_INFO_HASH: `0x${string}`;
export declare enum SporeVersion {
    V1 = "V1",
    V2 = "V2",
    DID = "DID"
}
export declare const SPORE_VERSION_DEFAULT = SporeVersion.V2;
export type SporeScriptInfoLike = ccc.ScriptInfoLike & {
    cobuild?: boolean;
};
export declare class SporeScriptInfo extends ccc.ScriptInfo {
    cobuild?: boolean | undefined;
    constructor(codeHash: ccc.Hex, hashType: ccc.HashType, cellDeps: ccc.CellDepInfo[], cobuild?: boolean | undefined);
    static from(scriptInfoLike: SporeScriptInfoLike): SporeScriptInfo;
}
//# sourceMappingURL=types.d.ts.map