import { SporeScriptInfoLike, SporeVersion } from "./types.js";
export declare const SCRIPTS_SPORE_MAINNET: Record<SporeVersion, SporeScriptInfoLike | undefined>;
export declare const SCRIPTS_CLUSTER_MAINNET: Record<SporeVersion, SporeScriptInfoLike | undefined>;
//# sourceMappingURL=mainnet.advanced.d.ts.map