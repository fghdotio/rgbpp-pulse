"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SporeScriptInfo = exports.SPORE_VERSION_DEFAULT = exports.SporeVersion = exports.DEFAULT_COBUILD_INFO_HASH = void 0;
const core_1 = require("@ckb-ccc/core");
exports.DEFAULT_COBUILD_INFO_HASH = core_1.ccc.hashCkb(core_1.ccc.bytesFrom("CCC_DEFAULT_COBUILD_INFO", "utf8"));
var SporeVersion;
(function (SporeVersion) {
    SporeVersion["V1"] = "V1";
    SporeVersion["V2"] = "V2";
    SporeVersion["DID"] = "DID";
})(SporeVersion || (exports.SporeVersion = SporeVersion = {}));
exports.SPORE_VERSION_DEFAULT = SporeVersion.V2;
class SporeScriptInfo extends core_1.ccc.ScriptInfo {
    constructor(codeHash, hashType, cellDeps, cobuild) {
        super(codeHash, hashType, cellDeps);
        this.cobuild = cobuild;
    }
    static from(scriptInfoLike) {
        return new SporeScriptInfo(core_1.ccc.hexFrom(scriptInfoLike.codeHash), core_1.ccc.hashTypeFrom(scriptInfoLike.hashType), scriptInfoLike.cellDeps.map((c) => core_1.ccc.CellDepInfo.from(c)), scriptInfoLike.cobuild);
    }
}
exports.SporeScriptInfo = SporeScriptInfo;
