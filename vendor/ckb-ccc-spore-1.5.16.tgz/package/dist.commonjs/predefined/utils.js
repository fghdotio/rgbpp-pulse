"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSporeScriptInfos = getSporeScriptInfos;
exports.getClusterScriptInfos = getClusterScriptInfos;
exports.getSporeScriptInfo = getSporeScriptInfo;
exports.getClusterScriptInfo = getClusterScriptInfo;
const advanced_js_1 = require("./advanced.js");
const types_js_1 = require("./types.js");
function getSporeScriptInfos(client) {
    return client.addressPrefix === "ckb"
        ? advanced_js_1.SCRIPTS_SPORE_MAINNET
        : advanced_js_1.SCRIPTS_SPORE_TESTNET;
}
function getClusterScriptInfos(client) {
    return client.addressPrefix === "ckb"
        ? advanced_js_1.SCRIPTS_CLUSTER_MAINNET
        : advanced_js_1.SCRIPTS_CLUSTER_TESTNET;
}
function getSporeScriptInfo(client, version) {
    const scriptInfo = getSporeScriptInfos(client)[version ?? types_js_1.SPORE_VERSION_DEFAULT];
    if (!scriptInfo) {
        throw new Error(`Spore script info not found of for version ${version} on ${client.addressPrefix}`);
    }
    return types_js_1.SporeScriptInfo.from(scriptInfo);
}
function getClusterScriptInfo(client, version) {
    const scriptInfo = getClusterScriptInfos(client)[version ?? types_js_1.SPORE_VERSION_DEFAULT];
    if (!scriptInfo) {
        throw new Error(`Cluster script info not found of for version ${version} on ${client.addressPrefix}`);
    }
    return types_js_1.SporeScriptInfo.from(scriptInfo);
}
