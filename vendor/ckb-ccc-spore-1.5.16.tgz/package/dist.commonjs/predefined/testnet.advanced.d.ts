import { SporeScriptInfoLike, SporeVersion } from "./types.js";
export declare const SCRIPTS_SPORE_TESTNET: Record<SporeVersion, SporeScriptInfoLike | undefined>;
export declare const SCRIPTS_CLUSTER_TESTNET: Record<SporeVersion, SporeScriptInfoLike | undefined>;
//# sourceMappingURL=testnet.advanced.d.ts.map