import { ccc } from "@ckb-ccc/core";
import { SporeScriptInfo, SporeVersion } from "./types.js";
export declare function getSporeScriptInfos(client: ccc.Client): Record<SporeVersion, import("./types.js").SporeScriptInfoLike | undefined>;
export declare function getClusterScriptInfos(client: ccc.Client): Record<SporeVersion, import("./types.js").SporeScriptInfoLike | undefined>;
export declare function getSporeScriptInfo(client: ccc.Client, version?: SporeVersion): SporeScriptInfo;
export declare function getClusterScriptInfo(client: ccc.Client, version?: SporeVersion): SporeScriptInfo;
//# sourceMappingURL=utils.d.ts.map