"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SporeData = void 0;
exports.packRawSporeData = packRawSporeData;
exports.unpackToRawSporeData = unpackToRawSporeData;
const core_1 = require("@ckb-ccc/core");
exports.SporeData = core_1.mol.table({
    contentType: core_1.mol.String,
    content: core_1.mol.Bytes,
    clusterId: core_1.mol.BytesOpt,
});
function packRawSporeData(packable) {
    return core_1.ccc.bytesFrom(exports.SporeData.encode({
        contentType: packable.contentType,
        content: packable.content,
        clusterId: packable.clusterId,
    }));
}
function unpackToRawSporeData(unpackable) {
    return exports.SporeData.decode(unpackable);
}
