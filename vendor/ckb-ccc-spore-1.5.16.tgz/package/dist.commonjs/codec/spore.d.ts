import { ccc } from "@ckb-ccc/core";
export interface SporeDataView {
    contentType: string;
    content: ccc.BytesLike;
    clusterId?: ccc.HexLike;
}
export declare const SporeData: ccc.Codec<SporeDataView>;
export declare function packRawSporeData(packable: SporeDataView): Uint8Array;
export declare function unpackToRawSporeData(unpackable: ccc.BytesLike): SporeDataView;
//# sourceMappingURL=spore.d.ts.map