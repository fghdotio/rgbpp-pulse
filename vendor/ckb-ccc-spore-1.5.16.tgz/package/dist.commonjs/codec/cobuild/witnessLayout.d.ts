import { mol } from "@ckb-ccc/core";
export declare const SighashAll: mol.Codec<mol.EncodableRecord<{
    seal: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
    message: mol.Codec<mol.EncodableRecord<{
        actions: mol.Codec<mol.EncodableRecord<{
            scriptInfoHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
            scriptHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
            data: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
        }>[], mol.DecodedRecord<{
            scriptInfoHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
            scriptHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
            data: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
        }>[]>;
    }>, mol.DecodedRecord<{
        actions: mol.Codec<mol.EncodableRecord<{
            scriptInfoHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
            scriptHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
            data: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
        }>[], mol.DecodedRecord<{
            scriptInfoHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
            scriptHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
            data: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
        }>[]>;
    }>>;
}>, mol.DecodedRecord<{
    seal: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
    message: mol.Codec<mol.EncodableRecord<{
        actions: mol.Codec<mol.EncodableRecord<{
            scriptInfoHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
            scriptHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
            data: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
        }>[], mol.DecodedRecord<{
            scriptInfoHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
            scriptHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
            data: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
        }>[]>;
    }>, mol.DecodedRecord<{
        actions: mol.Codec<mol.EncodableRecord<{
            scriptInfoHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
            scriptHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
            data: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
        }>[], mol.DecodedRecord<{
            scriptInfoHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
            scriptHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
            data: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
        }>[]>;
    }>>;
}>>;
export declare const SighashAllOnly: mol.Codec<mol.EncodableRecord<{
    seal: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
}>, mol.DecodedRecord<{
    seal: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
}>>;
/**
 * Otx related are not implemented yet, so just placeholders.
 */
export declare const Otx: mol.Codec<mol.EncodableRecord<{}>, mol.DecodedRecord<{}>>;
export declare const OtxStart: mol.Codec<mol.EncodableRecord<{}>, mol.DecodedRecord<{}>>;
export declare const WitnessLayoutFieldTags: {
    readonly SighashAll: 4278190081;
    readonly SighashAllOnly: 4278190082;
    readonly Otx: 4278190083;
    readonly OtxStart: 4278190084;
};
export declare const WitnessLayout: mol.Codec<{
    type: "SighashAll";
    value: {} & {
        message: {} & {
            actions: mol.EncodableRecord<{
                scriptInfoHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
                scriptHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
                data: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
            }>[];
        };
        seal: import("@ckb-ccc/core").BytesLike;
    };
} | {
    type: "SighashAllOnly";
    value: {} & {
        seal: import("@ckb-ccc/core").BytesLike;
    };
} | {
    type: "Otx";
    value: {} & {};
} | {
    type: "OtxStart";
    value: {} & {};
}, {
    type: "SighashAll";
    value: mol.DecodedRecord<{
        seal: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
        message: mol.Codec<mol.EncodableRecord<{
            actions: mol.Codec<mol.EncodableRecord<{
                scriptInfoHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
                scriptHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
                data: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
            }>[], mol.DecodedRecord<{
                scriptInfoHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
                scriptHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
                data: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
            }>[]>;
        }>, mol.DecodedRecord<{
            actions: mol.Codec<mol.EncodableRecord<{
                scriptInfoHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
                scriptHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
                data: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
            }>[], mol.DecodedRecord<{
                scriptInfoHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
                scriptHash: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
                data: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
            }>[]>;
        }>>;
    }>;
} | {
    type: "SighashAllOnly";
    value: mol.DecodedRecord<{
        seal: mol.Codec<import("@ckb-ccc/core").BytesLike, `0x${string}`>;
    }>;
} | {
    type: "Otx";
    value: mol.DecodedRecord<{}>;
} | {
    type: "OtxStart";
    value: mol.DecodedRecord<{}>;
}>;
//# sourceMappingURL=witnessLayout.d.ts.map