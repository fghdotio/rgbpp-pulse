import { ccc, mol } from "@ckb-ccc/core";
export declare const Action: ccc.Codec<mol.EncodableRecord<{
    scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
}>, mol.DecodedRecord<{
    scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
}>>;
export declare const ActionVec: ccc.Codec<mol.EncodableRecord<{
    scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
}>[], mol.DecodedRecord<{
    scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
}>[]>;
export declare const Message: ccc.Codec<mol.EncodableRecord<{
    actions: ccc.Codec<mol.EncodableRecord<{
        scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    }>[], mol.DecodedRecord<{
        scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    }>[]>;
}>, mol.DecodedRecord<{
    actions: ccc.Codec<mol.EncodableRecord<{
        scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    }>[], mol.DecodedRecord<{
        scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    }>[]>;
}>>;
export declare const ResolvedInputs: ccc.Codec<mol.EncodableRecord<{
    outputs: ccc.Codec<ccc.CellOutputLike[], ccc.CellOutput[]>;
    outputsData: ccc.Codec<ccc.BytesLike[], `0x${string}`[]>;
}>, mol.DecodedRecord<{
    outputs: ccc.Codec<ccc.CellOutputLike[], ccc.CellOutput[]>;
    outputsData: ccc.Codec<ccc.BytesLike[], `0x${string}`[]>;
}>>;
export declare const ScriptInfo: ccc.Codec<mol.EncodableRecord<{
    name: ccc.Codec<string, string>;
    url: ccc.Codec<string, string>;
    scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    schema: ccc.Codec<string, string>;
    messageType: ccc.Codec<string, string>;
}>, mol.DecodedRecord<{
    name: ccc.Codec<string, string>;
    url: ccc.Codec<string, string>;
    scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    schema: ccc.Codec<string, string>;
    messageType: ccc.Codec<string, string>;
}>>;
export declare const ScriptInfoVec: ccc.Codec<mol.EncodableRecord<{
    name: ccc.Codec<string, string>;
    url: ccc.Codec<string, string>;
    scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    schema: ccc.Codec<string, string>;
    messageType: ccc.Codec<string, string>;
}>[], mol.DecodedRecord<{
    name: ccc.Codec<string, string>;
    url: ccc.Codec<string, string>;
    scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    schema: ccc.Codec<string, string>;
    messageType: ccc.Codec<string, string>;
}>[]>;
export declare const BuildingPacketV1: ccc.Codec<mol.EncodableRecord<{
    message: ccc.Codec<mol.EncodableRecord<{
        actions: ccc.Codec<mol.EncodableRecord<{
            scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        }>[], mol.DecodedRecord<{
            scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        }>[]>;
    }>, mol.DecodedRecord<{
        actions: ccc.Codec<mol.EncodableRecord<{
            scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        }>[], mol.DecodedRecord<{
            scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        }>[]>;
    }>>;
    payload: typeof ccc.Transaction;
    resolvedInputs: ccc.Codec<mol.EncodableRecord<{
        outputs: ccc.Codec<ccc.CellOutputLike[], ccc.CellOutput[]>;
        outputsData: ccc.Codec<ccc.BytesLike[], `0x${string}`[]>;
    }>, mol.DecodedRecord<{
        outputs: ccc.Codec<ccc.CellOutputLike[], ccc.CellOutput[]>;
        outputsData: ccc.Codec<ccc.BytesLike[], `0x${string}`[]>;
    }>>;
    changeOutput: ccc.Codec<ccc.NumLike | null | undefined, number | undefined>;
    scriptInfos: ccc.Codec<mol.EncodableRecord<{
        name: ccc.Codec<string, string>;
        url: ccc.Codec<string, string>;
        scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        schema: ccc.Codec<string, string>;
        messageType: ccc.Codec<string, string>;
    }>[], mol.DecodedRecord<{
        name: ccc.Codec<string, string>;
        url: ccc.Codec<string, string>;
        scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        schema: ccc.Codec<string, string>;
        messageType: ccc.Codec<string, string>;
    }>[]>;
    lockActions: ccc.Codec<mol.EncodableRecord<{
        scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    }>[], mol.DecodedRecord<{
        scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    }>[]>;
}>, mol.DecodedRecord<{
    message: ccc.Codec<mol.EncodableRecord<{
        actions: ccc.Codec<mol.EncodableRecord<{
            scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        }>[], mol.DecodedRecord<{
            scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        }>[]>;
    }>, mol.DecodedRecord<{
        actions: ccc.Codec<mol.EncodableRecord<{
            scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        }>[], mol.DecodedRecord<{
            scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        }>[]>;
    }>>;
    payload: typeof ccc.Transaction;
    resolvedInputs: ccc.Codec<mol.EncodableRecord<{
        outputs: ccc.Codec<ccc.CellOutputLike[], ccc.CellOutput[]>;
        outputsData: ccc.Codec<ccc.BytesLike[], `0x${string}`[]>;
    }>, mol.DecodedRecord<{
        outputs: ccc.Codec<ccc.CellOutputLike[], ccc.CellOutput[]>;
        outputsData: ccc.Codec<ccc.BytesLike[], `0x${string}`[]>;
    }>>;
    changeOutput: ccc.Codec<ccc.NumLike | null | undefined, number | undefined>;
    scriptInfos: ccc.Codec<mol.EncodableRecord<{
        name: ccc.Codec<string, string>;
        url: ccc.Codec<string, string>;
        scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        schema: ccc.Codec<string, string>;
        messageType: ccc.Codec<string, string>;
    }>[], mol.DecodedRecord<{
        name: ccc.Codec<string, string>;
        url: ccc.Codec<string, string>;
        scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        schema: ccc.Codec<string, string>;
        messageType: ccc.Codec<string, string>;
    }>[]>;
    lockActions: ccc.Codec<mol.EncodableRecord<{
        scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    }>[], mol.DecodedRecord<{
        scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    }>[]>;
}>>;
export declare const BuildingPacket: ccc.Codec<{
    type: "BuildingPacketV1";
    value: {
        changeOutput?: ccc.NumLike | null | undefined;
    } & {
        message: {} & {
            actions: mol.EncodableRecord<{
                scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
                scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
                data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            }>[];
        };
        payload: ccc.TransactionLike;
        resolvedInputs: {} & {
            outputs: ccc.CellOutputLike[];
            outputsData: ccc.BytesLike[];
        };
        scriptInfos: mol.EncodableRecord<{
            name: ccc.Codec<string, string>;
            url: ccc.Codec<string, string>;
            scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            schema: ccc.Codec<string, string>;
            messageType: ccc.Codec<string, string>;
        }>[];
        lockActions: mol.EncodableRecord<{
            scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        }>[];
    };
}, {
    type: "BuildingPacketV1";
    value: mol.DecodedRecord<{
        message: ccc.Codec<mol.EncodableRecord<{
            actions: ccc.Codec<mol.EncodableRecord<{
                scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
                scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
                data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            }>[], mol.DecodedRecord<{
                scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
                scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
                data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            }>[]>;
        }>, mol.DecodedRecord<{
            actions: ccc.Codec<mol.EncodableRecord<{
                scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
                scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
                data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            }>[], mol.DecodedRecord<{
                scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
                scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
                data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            }>[]>;
        }>>;
        payload: typeof ccc.Transaction;
        resolvedInputs: ccc.Codec<mol.EncodableRecord<{
            outputs: ccc.Codec<ccc.CellOutputLike[], ccc.CellOutput[]>;
            outputsData: ccc.Codec<ccc.BytesLike[], `0x${string}`[]>;
        }>, mol.DecodedRecord<{
            outputs: ccc.Codec<ccc.CellOutputLike[], ccc.CellOutput[]>;
            outputsData: ccc.Codec<ccc.BytesLike[], `0x${string}`[]>;
        }>>;
        changeOutput: ccc.Codec<ccc.NumLike | null | undefined, number | undefined>;
        scriptInfos: ccc.Codec<mol.EncodableRecord<{
            name: ccc.Codec<string, string>;
            url: ccc.Codec<string, string>;
            scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            schema: ccc.Codec<string, string>;
            messageType: ccc.Codec<string, string>;
        }>[], mol.DecodedRecord<{
            name: ccc.Codec<string, string>;
            url: ccc.Codec<string, string>;
            scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            schema: ccc.Codec<string, string>;
            messageType: ccc.Codec<string, string>;
        }>[]>;
        lockActions: ccc.Codec<mol.EncodableRecord<{
            scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        }>[], mol.DecodedRecord<{
            scriptInfoHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            scriptHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
            data: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        }>[]>;
    }>;
}>;
//# sourceMappingURL=buildingPacket.d.ts.map