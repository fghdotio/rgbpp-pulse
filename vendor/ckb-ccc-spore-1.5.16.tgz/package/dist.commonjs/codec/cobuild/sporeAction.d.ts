import { ccc, mol } from "@ckb-ccc/core";
export declare const Address: ccc.Codec<{
    type: "Script";
    value: ccc.ScriptLike;
}, {
    type: "Script";
    value: ccc.Script;
}>;
/**
 * Spore
 */
export declare const CreateSpore: ccc.Codec<mol.EncodableRecord<{
    sporeId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    to: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
    dataHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
}>, mol.DecodedRecord<{
    sporeId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    to: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
    dataHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
}>>;
export declare const TransferSpore: ccc.Codec<mol.EncodableRecord<{
    sporeId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    from: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
    to: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
}>, mol.DecodedRecord<{
    sporeId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    from: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
    to: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
}>>;
export declare const MeltSpore: ccc.Codec<mol.EncodableRecord<{
    sporeId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    from: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
}>, mol.DecodedRecord<{
    sporeId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    from: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
}>>;
/**
 * Cluster
 */
export declare const CreateCluster: ccc.Codec<mol.EncodableRecord<{
    clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    to: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
    dataHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
}>, mol.DecodedRecord<{
    clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    to: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
    dataHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
}>>;
export declare const TransferCluster: ccc.Codec<mol.EncodableRecord<{
    clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    from: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
    to: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
}>, mol.DecodedRecord<{
    clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    from: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
    to: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
}>>;
/**
 * ClusterProxy
 */
export declare const CreateClusterProxy: ccc.Codec<mol.EncodableRecord<{
    clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    clusterProxyId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    to: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
}>, mol.DecodedRecord<{
    clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    clusterProxyId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    to: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
}>>;
export declare const TransferClusterProxy: ccc.Codec<mol.EncodableRecord<{
    clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    clusterProxyId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    from: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
    to: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
}>, mol.DecodedRecord<{
    clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    clusterProxyId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    from: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
    to: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
}>>;
export declare const MeltClusterProxy: ccc.Codec<mol.EncodableRecord<{
    clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    clusterProxyId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    from: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
}>, mol.DecodedRecord<{
    clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    clusterProxyId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    from: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
}>>;
/**
 * ClusterAgent
 */
export declare const CreateClusterAgent: ccc.Codec<mol.EncodableRecord<{
    clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    clusterProxyId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    to: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
}>, mol.DecodedRecord<{
    clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    clusterProxyId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    to: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
}>>;
export declare const TransferClusterAgent: ccc.Codec<mol.EncodableRecord<{
    clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    from: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
    to: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
}>, mol.DecodedRecord<{
    clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    from: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
    to: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
}>>;
export declare const MeltClusterAgent: ccc.Codec<mol.EncodableRecord<{
    clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    from: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
}>, mol.DecodedRecord<{
    clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    from: ccc.Codec<{
        type: "Script";
        value: ccc.ScriptLike;
    }, {
        type: "Script";
        value: ccc.Script;
    }>;
}>>;
/**
 * Spore ScriptInfo Actions
 */
export declare const SporeAction: ccc.Codec<{
    type: "CreateSpore";
    value: {} & {
        sporeId: ccc.BytesLike;
        to: {
            type: "Script";
            value: ccc.ScriptLike;
        };
        dataHash: ccc.BytesLike;
    };
} | {
    type: "TransferSpore";
    value: {} & {
        sporeId: ccc.BytesLike;
        to: {
            type: "Script";
            value: ccc.ScriptLike;
        };
        from: {
            type: "Script";
            value: ccc.ScriptLike;
        };
    };
} | {
    type: "MeltSpore";
    value: {} & {
        sporeId: ccc.BytesLike;
        from: {
            type: "Script";
            value: ccc.ScriptLike;
        };
    };
} | {
    type: "CreateCluster";
    value: {} & {
        to: {
            type: "Script";
            value: ccc.ScriptLike;
        };
        dataHash: ccc.BytesLike;
        clusterId: ccc.BytesLike;
    };
} | {
    type: "TransferCluster";
    value: {} & {
        to: {
            type: "Script";
            value: ccc.ScriptLike;
        };
        from: {
            type: "Script";
            value: ccc.ScriptLike;
        };
        clusterId: ccc.BytesLike;
    };
} | {
    type: "CreateClusterProxy";
    value: {} & {
        to: {
            type: "Script";
            value: ccc.ScriptLike;
        };
        clusterId: ccc.BytesLike;
        clusterProxyId: ccc.BytesLike;
    };
} | {
    type: "TransferClusterProxy";
    value: {} & {
        to: {
            type: "Script";
            value: ccc.ScriptLike;
        };
        from: {
            type: "Script";
            value: ccc.ScriptLike;
        };
        clusterId: ccc.BytesLike;
        clusterProxyId: ccc.BytesLike;
    };
} | {
    type: "MeltClusterProxy";
    value: {} & {
        from: {
            type: "Script";
            value: ccc.ScriptLike;
        };
        clusterId: ccc.BytesLike;
        clusterProxyId: ccc.BytesLike;
    };
} | {
    type: "CreateClusterAgent";
    value: {} & {
        to: {
            type: "Script";
            value: ccc.ScriptLike;
        };
        clusterId: ccc.BytesLike;
        clusterProxyId: ccc.BytesLike;
    };
} | {
    type: "TransferClusterAgent";
    value: {} & {
        to: {
            type: "Script";
            value: ccc.ScriptLike;
        };
        from: {
            type: "Script";
            value: ccc.ScriptLike;
        };
        clusterId: ccc.BytesLike;
    };
} | {
    type: "MeltClusterAgent";
    value: {} & {
        from: {
            type: "Script";
            value: ccc.ScriptLike;
        };
        clusterId: ccc.BytesLike;
    };
}, {
    type: "CreateSpore";
    value: mol.DecodedRecord<{
        sporeId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        to: ccc.Codec<{
            type: "Script";
            value: ccc.ScriptLike;
        }, {
            type: "Script";
            value: ccc.Script;
        }>;
        dataHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    }>;
} | {
    type: "TransferSpore";
    value: mol.DecodedRecord<{
        sporeId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        from: ccc.Codec<{
            type: "Script";
            value: ccc.ScriptLike;
        }, {
            type: "Script";
            value: ccc.Script;
        }>;
        to: ccc.Codec<{
            type: "Script";
            value: ccc.ScriptLike;
        }, {
            type: "Script";
            value: ccc.Script;
        }>;
    }>;
} | {
    type: "MeltSpore";
    value: mol.DecodedRecord<{
        sporeId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        from: ccc.Codec<{
            type: "Script";
            value: ccc.ScriptLike;
        }, {
            type: "Script";
            value: ccc.Script;
        }>;
    }>;
} | {
    type: "CreateCluster";
    value: mol.DecodedRecord<{
        clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        to: ccc.Codec<{
            type: "Script";
            value: ccc.ScriptLike;
        }, {
            type: "Script";
            value: ccc.Script;
        }>;
        dataHash: ccc.Codec<ccc.BytesLike, `0x${string}`>;
    }>;
} | {
    type: "TransferCluster";
    value: mol.DecodedRecord<{
        clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        from: ccc.Codec<{
            type: "Script";
            value: ccc.ScriptLike;
        }, {
            type: "Script";
            value: ccc.Script;
        }>;
        to: ccc.Codec<{
            type: "Script";
            value: ccc.ScriptLike;
        }, {
            type: "Script";
            value: ccc.Script;
        }>;
    }>;
} | {
    type: "CreateClusterProxy";
    value: mol.DecodedRecord<{
        clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        clusterProxyId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        to: ccc.Codec<{
            type: "Script";
            value: ccc.ScriptLike;
        }, {
            type: "Script";
            value: ccc.Script;
        }>;
    }>;
} | {
    type: "TransferClusterProxy";
    value: mol.DecodedRecord<{
        clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        clusterProxyId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        from: ccc.Codec<{
            type: "Script";
            value: ccc.ScriptLike;
        }, {
            type: "Script";
            value: ccc.Script;
        }>;
        to: ccc.Codec<{
            type: "Script";
            value: ccc.ScriptLike;
        }, {
            type: "Script";
            value: ccc.Script;
        }>;
    }>;
} | {
    type: "MeltClusterProxy";
    value: mol.DecodedRecord<{
        clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        clusterProxyId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        from: ccc.Codec<{
            type: "Script";
            value: ccc.ScriptLike;
        }, {
            type: "Script";
            value: ccc.Script;
        }>;
    }>;
} | {
    type: "CreateClusterAgent";
    value: mol.DecodedRecord<{
        clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        clusterProxyId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        to: ccc.Codec<{
            type: "Script";
            value: ccc.ScriptLike;
        }, {
            type: "Script";
            value: ccc.Script;
        }>;
    }>;
} | {
    type: "TransferClusterAgent";
    value: mol.DecodedRecord<{
        clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        from: ccc.Codec<{
            type: "Script";
            value: ccc.ScriptLike;
        }, {
            type: "Script";
            value: ccc.Script;
        }>;
        to: ccc.Codec<{
            type: "Script";
            value: ccc.ScriptLike;
        }, {
            type: "Script";
            value: ccc.Script;
        }>;
    }>;
} | {
    type: "MeltClusterAgent";
    value: mol.DecodedRecord<{
        clusterId: ccc.Codec<ccc.BytesLike, `0x${string}`>;
        from: ccc.Codec<{
            type: "Script";
            value: ccc.ScriptLike;
        }, {
            type: "Script";
            value: ccc.Script;
        }>;
    }>;
}>;
//# sourceMappingURL=sporeAction.d.ts.map