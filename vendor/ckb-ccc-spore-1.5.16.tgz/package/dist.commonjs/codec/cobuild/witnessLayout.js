"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WitnessLayout = exports.WitnessLayoutFieldTags = exports.OtxStart = exports.Otx = exports.SighashAllOnly = exports.SighashAll = void 0;
const core_1 = require("@ckb-ccc/core");
const buildingPacket_js_1 = require("./buildingPacket.js");
exports.SighashAll = core_1.mol.table({
    seal: core_1.mol.Bytes,
    message: buildingPacket_js_1.Message,
});
exports.SighashAllOnly = core_1.mol.table({
    seal: core_1.mol.Bytes,
});
/**
 * Otx related are not implemented yet, so just placeholders.
 */
exports.Otx = core_1.mol.table({});
exports.OtxStart = core_1.mol.table({});
exports.WitnessLayoutFieldTags = {
    SighashAll: 4278190081,
    SighashAllOnly: 4278190082,
    Otx: 4278190083,
    OtxStart: 4278190084,
};
exports.WitnessLayout = core_1.mol.union({
    SighashAll: exports.SighashAll,
    SighashAllOnly: exports.SighashAllOnly,
    Otx: exports.Otx,
    OtxStart: exports.OtxStart,
}, exports.WitnessLayoutFieldTags);
