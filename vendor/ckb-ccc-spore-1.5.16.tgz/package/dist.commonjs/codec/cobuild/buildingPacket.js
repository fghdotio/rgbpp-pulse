"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BuildingPacket = exports.BuildingPacketV1 = exports.ScriptInfoVec = exports.ScriptInfo = exports.ResolvedInputs = exports.Message = exports.ActionVec = exports.Action = void 0;
const core_1 = require("@ckb-ccc/core");
exports.Action = core_1.mol.table({
    scriptInfoHash: core_1.mol.Byte32,
    scriptHash: core_1.mol.Byte32,
    data: core_1.mol.Bytes,
});
exports.ActionVec = core_1.mol.vector(exports.Action);
exports.Message = core_1.mol.table({
    actions: exports.ActionVec,
});
exports.ResolvedInputs = core_1.mol.table({
    outputs: core_1.ccc.CellOutputVec,
    outputsData: core_1.mol.BytesVec,
});
exports.ScriptInfo = core_1.mol.table({
    name: core_1.mol.String,
    url: core_1.mol.String,
    scriptHash: core_1.mol.Byte32,
    schema: core_1.mol.String,
    messageType: core_1.mol.String,
});
exports.ScriptInfoVec = core_1.mol.vector(exports.ScriptInfo);
exports.BuildingPacketV1 = core_1.mol.table({
    message: exports.Message,
    payload: core_1.ccc.Transaction,
    resolvedInputs: exports.ResolvedInputs,
    changeOutput: core_1.mol.Uint32Opt,
    scriptInfos: exports.ScriptInfoVec,
    lockActions: exports.ActionVec,
});
exports.BuildingPacket = core_1.mol.union({
    BuildingPacketV1: exports.BuildingPacketV1,
});
