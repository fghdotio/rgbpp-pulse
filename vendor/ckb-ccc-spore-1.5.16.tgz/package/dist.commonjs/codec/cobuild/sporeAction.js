"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SporeAction = exports.MeltClusterAgent = exports.TransferClusterAgent = exports.CreateClusterAgent = exports.MeltClusterProxy = exports.TransferClusterProxy = exports.CreateClusterProxy = exports.TransferCluster = exports.CreateCluster = exports.MeltSpore = exports.TransferSpore = exports.CreateSpore = exports.Address = void 0;
const core_1 = require("@ckb-ccc/core");
exports.Address = core_1.mol.union({
    Script: core_1.ccc.Script,
});
/**
 * Spore
 */
exports.CreateSpore = core_1.mol.table({
    sporeId: core_1.mol.Byte32,
    to: exports.Address,
    dataHash: core_1.mol.Byte32,
});
exports.TransferSpore = core_1.mol.table({
    sporeId: core_1.mol.Byte32,
    from: exports.Address,
    to: exports.Address,
});
exports.MeltSpore = core_1.mol.table({
    sporeId: core_1.mol.Byte32,
    from: exports.Address,
});
/**
 * Cluster
 */
exports.CreateCluster = core_1.mol.table({
    clusterId: core_1.mol.Byte32,
    to: exports.Address,
    dataHash: core_1.mol.Byte32,
});
exports.TransferCluster = core_1.mol.table({
    clusterId: core_1.mol.Byte32,
    from: exports.Address,
    to: exports.Address,
});
/**
 * ClusterProxy
 */
exports.CreateClusterProxy = core_1.mol.table({
    clusterId: core_1.mol.Byte32,
    clusterProxyId: core_1.mol.Byte32,
    to: exports.Address,
});
exports.TransferClusterProxy = core_1.mol.table({
    clusterId: core_1.mol.Byte32,
    clusterProxyId: core_1.mol.Byte32,
    from: exports.Address,
    to: exports.Address,
});
exports.MeltClusterProxy = core_1.mol.table({
    clusterId: core_1.mol.Byte32,
    clusterProxyId: core_1.mol.Byte32,
    from: exports.Address,
});
/**
 * ClusterAgent
 */
exports.CreateClusterAgent = core_1.mol.table({
    clusterId: core_1.mol.Byte32,
    clusterProxyId: core_1.mol.Byte32,
    to: exports.Address,
});
exports.TransferClusterAgent = core_1.mol.table({
    clusterId: core_1.mol.Byte32,
    from: exports.Address,
    to: exports.Address,
});
exports.MeltClusterAgent = core_1.mol.table({
    clusterId: core_1.mol.Byte32,
    from: exports.Address,
});
/**
 * Spore ScriptInfo Actions
 */
exports.SporeAction = core_1.mol.union({
    // Spore
    CreateSpore: exports.CreateSpore,
    TransferSpore: exports.TransferSpore,
    MeltSpore: exports.MeltSpore,
    // Cluster
    CreateCluster: exports.CreateCluster,
    TransferCluster: exports.TransferCluster,
    // ClusterProxy
    CreateClusterProxy: exports.CreateClusterProxy,
    TransferClusterProxy: exports.TransferClusterProxy,
    MeltClusterProxy: exports.MeltClusterProxy,
    // ClusterAgent
    CreateClusterAgent: exports.CreateClusterAgent,
    TransferClusterAgent: exports.TransferClusterAgent,
    MeltClusterAgent: exports.MeltClusterAgent,
});
