import { ccc } from "@ckb-ccc/core";
export interface ClusterDataV1View {
    name: string;
    description: string;
}
export declare const ClusterDataV1: ccc.Codec<ClusterDataV1View>;
export interface ClusterDataV2View {
    name: string;
    description: string;
    mutantId?: ccc.HexLike;
}
export declare const ClusterDataV2: ccc.Codec<ClusterDataV2View>;
export type ClusterDataView = ClusterDataV2View;
export type ClusterDataVersion = "v1" | "v2";
export declare const ClusterData: ccc.Codec<ClusterDataV2View, ClusterDataV2View>;
/**
 * Pack RawClusterData to Uint8Array.
 * Pass an optional "version" field to select a specific packing version.
 */
export declare function packRawClusterData(packable: ClusterDataView): Uint8Array;
export declare function packRawClusterData(packable: ClusterDataV1View, version: "v1"): Uint8Array;
export declare function packRawClusterData(packable: ClusterDataV2View, version: "v2"): Uint8Array;
export declare function packRawClusterDataV1(packable: ClusterDataV1View): Uint8Array;
export declare function packRawClusterDataV2(packable: ClusterDataV2View): Uint8Array;
/**
 * Unpack Hex/Bytes to RawClusterData.
 * Pass an optional "version" field to select a specific unpacking version.
 */
export declare function unpackToRawClusterData(unpackable: ccc.BytesLike): ClusterDataView;
export declare function unpackToRawClusterData(unpackable: ccc.BytesLike, version: "v1"): ClusterDataV1View;
export declare function unpackToRawClusterData(unpackable: ccc.BytesLike, version: "v2"): ClusterDataV2View;
export declare function unpackToRawClusterDataV1(unpackable: ccc.BytesLike): ClusterDataV1View;
export declare function unpackToRawClusterDataV2(unpackable: ccc.BytesLike): ClusterDataV2View;
//# sourceMappingURL=cluster.d.ts.map