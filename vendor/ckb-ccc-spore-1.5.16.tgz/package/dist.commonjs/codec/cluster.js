"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClusterData = exports.ClusterDataV2 = exports.ClusterDataV1 = void 0;
exports.packRawClusterData = packRawClusterData;
exports.packRawClusterDataV1 = packRawClusterDataV1;
exports.packRawClusterDataV2 = packRawClusterDataV2;
exports.unpackToRawClusterData = unpackToRawClusterData;
exports.unpackToRawClusterDataV1 = unpackToRawClusterDataV1;
exports.unpackToRawClusterDataV2 = unpackToRawClusterDataV2;
const core_1 = require("@ckb-ccc/core");
exports.ClusterDataV1 = core_1.mol.table({
    name: core_1.mol.String,
    description: core_1.mol.String,
});
exports.ClusterDataV2 = core_1.mol.table({
    name: core_1.mol.String,
    description: core_1.mol.String,
    mutantId: core_1.mol.BytesOpt,
});
exports.ClusterData = exports.ClusterDataV2;
function packRawClusterData(packable, version) {
    if (!version) {
        return packRawClusterDataV2(packable);
    }
    switch (version) {
        case "v1":
            return packRawClusterDataV1(packable);
        case "v2":
            return packRawClusterDataV2(packable);
    }
}
function packRawClusterDataV1(packable) {
    return core_1.ccc.bytesFrom(exports.ClusterDataV1.encode({
        name: packable.name,
        description: packable.description,
    }));
}
function packRawClusterDataV2(packable) {
    return core_1.ccc.bytesFrom(exports.ClusterDataV2.encode({
        name: packable.name,
        description: packable.description,
        mutantId: packable.mutantId,
    }));
}
function unpackToRawClusterData(unpackable, version) {
    if (version) {
        switch (version) {
            case "v1":
                return unpackToRawClusterDataV1(unpackable);
            case "v2":
                return unpackToRawClusterDataV2(unpackable);
        }
    }
    try {
        return unpackToRawClusterDataV2(unpackable);
    }
    catch {
        try {
            return unpackToRawClusterDataV1(unpackable);
        }
        catch {
            throw new Error(`Cannot unpack ClusterData, no matching molecule: ${core_1.ccc.hexFrom(unpackable)}`);
        }
    }
}
function unpackToRawClusterDataV1(unpackable) {
    return exports.ClusterDataV1.decode(unpackable);
}
function unpackToRawClusterDataV2(unpackable) {
    return exports.ClusterDataV2.decode(unpackable);
}
