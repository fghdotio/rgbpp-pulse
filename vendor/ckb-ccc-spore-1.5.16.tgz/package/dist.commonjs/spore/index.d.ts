import { ccc } from "@ckb-ccc/core";
import { SporeDataView } from "../codec/index.js";
import { SporeScriptInfo, SporeScriptInfoLike } from "../predefined/index.js";
export declare function findSpore(client: ccc.Client, id: ccc.HexLike, scripts?: SporeScriptInfoLike[]): Promise<{
    cell: ccc.Cell;
    spore: ccc.Cell;
    sporeData: SporeDataView;
    scriptInfo: SporeScriptInfo;
} | undefined>;
export declare function assertSpore(client: ccc.Client, args: ccc.HexLike, scripts?: SporeScriptInfoLike[]): Promise<{
    cell: ccc.Cell;
    scriptInfo: SporeScriptInfo;
}>;
/**
 * Create one Spore cell with the specified Spore data.
 *
 * @param params.signer who takes the responsibility to balance and sign the transaction
 * @param params.data specific format of data required by Spore protocol
 * @param params.to owner of new spore cell, signer if no provided
 * @param params.clusterMode how to process cluster cell **(if clusterId is not provided in SporeData, this parameter will be ignored)**
 *   - undefined: error if the spore has a cluster but the clusterMode is not set
 *   - lockProxy: put a cell that uses the same lock from Cluster cell in both Inputs and Outputs
 *   - clusterCell: directly put Cluster cell in Inputs and Outputs
 *   - skip: don't handle the cluster logic
 * @param params.tx the transaction skeleton, if not provided, a new one will be created
 * @param params.scriptInfo the script info of Spore cell, if not provided, the default script info will be used
 * @param params.scriptInfoHash the script info hash used in cobuild
 * @returns
 *  - **tx**: a new transaction that contains created Spore cells
 *  - **id**: the sporeId of created Spore cell
 */
export declare function createSpore(params: {
    signer: ccc.Signer;
    data: SporeDataView;
    to?: ccc.ScriptLike;
    clusterMode?: "lockProxy" | "clusterCell" | "skip";
    tx?: ccc.TransactionLike;
    scriptInfo?: SporeScriptInfoLike;
    scriptInfoHash?: ccc.HexLike;
}): Promise<{
    tx: ccc.Transaction;
    id: ccc.Hex;
}>;
/**
 * Transfer one Spore cell
 *
 * @param params.signer who takes the responsibility to balance and sign the transaction
 * @param params.id sporeId
 * @param params.to Spore's new owner
 * @param params.tx the transaction skeleton, if not provided, a new one will be created
 * @param params.scriptInfoHash the script info hash used in cobuild
 * @returns
 *  - **tx**: a new transaction that contains transferred Spore cells
 */
export declare function transferSpore(params: {
    signer: ccc.Signer;
    id: ccc.HexLike;
    to: ccc.ScriptLike;
    tx?: ccc.TransactionLike;
    scripts?: SporeScriptInfoLike[];
    scriptInfoHash?: ccc.HexLike;
}): Promise<{
    tx: ccc.Transaction;
}>;
/**
 * Melt one Spore cell
 *
 * @param params.signer who takes the responsibility to balance and sign the transaction
 * @param params.id sporeId to be melted
 * @param params.tx the transaction skeleton, if not provided, a new one will be created
 * @param params.scriptInfoHash the script info hash used in cobuild
 * @returns
 *  - **tx**: a new transaction that contains melted Spore cell
 */
export declare function meltSpore(params: {
    signer: ccc.Signer;
    id: ccc.HexLike;
    tx?: ccc.TransactionLike;
    scripts?: SporeScriptInfoLike[];
    scriptInfoHash?: ccc.HexLike;
}): Promise<{
    tx: ccc.Transaction;
}>;
/**
 * Search on-chain spores under the signer's control, if cluster provided, filter spores belonging to this cluster
 *
 * @param params.signer the owner of spores
 * @param params.order the order in creation time of spores
 * @param params.clusterId the cluster that spores belong to. "" to find public spores
 * @param params.scriptInfos the deployed script infos of spores
 * @returns specified spore cells
 */
export declare function findSporesBySigner(params: {
    signer: ccc.Signer;
    order?: "asc" | "desc";
    limit?: number;
    clusterId?: ccc.HexLike;
    scriptInfos?: SporeScriptInfoLike[];
}): AsyncGenerator<{
    cell: ccc.Cell;
    spore: ccc.Cell;
    sporeData: SporeDataView;
    scriptInfo: SporeScriptInfo;
}>;
/**
 * Search on-chain spores under the specified lock or not, if cluster provided, filter spores belonging to this cluster
 *
 * @param params.client the client to search spores
 * @param params.lock the lock of spores
 * @param params.clusterId the cluster that spores belong to. "" to find public spores
 * @param params.scriptInfos the deployed script infos of spores
 * @param params.limit the limit of spores to search
 * @param params.order the order in creation time of spores
 * @returns specified spore cells
 */
export declare function findSpores(params: {
    client: ccc.Client;
    lock?: ccc.ScriptLike;
    clusterId?: ccc.HexLike;
    scriptInfos?: SporeScriptInfoLike[];
    limit?: number;
    order?: "asc" | "desc";
}): AsyncGenerator<{
    cell: ccc.Cell;
    spore: ccc.Cell;
    sporeData: SporeDataView;
    scriptInfo: SporeScriptInfo;
}>;
//# sourceMappingURL=index.d.ts.map