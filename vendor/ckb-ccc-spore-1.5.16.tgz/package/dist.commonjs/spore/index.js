"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.findSpore = findSpore;
exports.assertSpore = assertSpore;
exports.createSpore = createSpore;
exports.transferSpore = transferSpore;
exports.meltSpore = meltSpore;
exports.findSporesBySigner = findSporesBySigner;
exports.findSpores = findSpores;
const core_1 = require("@ckb-ccc/core");
const advanced_js_1 = require("../advanced.js");
const index_js_1 = require("../codec/index.js");
const index_js_2 = require("../helper/index.js");
const index_js_3 = require("../predefined/index.js");
const advanced_js_2 = require("./advanced.js");
async function findSpore(client, id, scripts) {
    const found = await (0, index_js_2.findSingletonCellByArgs)(client, id, scripts ?? Object.values((0, index_js_3.getSporeScriptInfos)(client)));
    if (!found) {
        return undefined;
    }
    return {
        cell: found.cell,
        spore: found.cell,
        sporeData: (0, index_js_1.unpackToRawSporeData)(found.cell.outputData),
        scriptInfo: found.scriptInfo,
    };
}
async function assertSpore(client, args, scripts) {
    const res = await findSpore(client, args, scripts);
    if (!res) {
        throw new Error(`Spore ${core_1.ccc.hexFrom(args)} not found`);
    }
    return res;
}
/**
 * Create one Spore cell with the specified Spore data.
 *
 * @param params.signer who takes the responsibility to balance and sign the transaction
 * @param params.data specific format of data required by Spore protocol
 * @param params.to owner of new spore cell, signer if no provided
 * @param params.clusterMode how to process cluster cell **(if clusterId is not provided in SporeData, this parameter will be ignored)**
 *   - undefined: error if the spore has a cluster but the clusterMode is not set
 *   - lockProxy: put a cell that uses the same lock from Cluster cell in both Inputs and Outputs
 *   - clusterCell: directly put Cluster cell in Inputs and Outputs
 *   - skip: don't handle the cluster logic
 * @param params.tx the transaction skeleton, if not provided, a new one will be created
 * @param params.scriptInfo the script info of Spore cell, if not provided, the default script info will be used
 * @param params.scriptInfoHash the script info hash used in cobuild
 * @returns
 *  - **tx**: a new transaction that contains created Spore cells
 *  - **id**: the sporeId of created Spore cell
 */
async function createSpore(params) {
    const { signer, data, to, clusterMode, scriptInfoHash } = params;
    const scriptInfo = params.scriptInfo ?? (0, index_js_3.getSporeScriptInfo)(signer.client);
    // prepare transaction
    const actions = [];
    const ids = [];
    const tx = core_1.ccc.Transaction.from(params.tx ?? {});
    await tx.completeInputsAtLeastOne(signer);
    const { script: lock } = await signer.getRecommendedAddressObj();
    // build spore cell
    const id = core_1.ccc.hashTypeId(tx.inputs[0], tx.outputs.length);
    ids.push(id);
    const packedData = (0, index_js_1.packRawSporeData)(data);
    tx.addOutput({
        lock: to ?? lock,
        type: {
            ...scriptInfo,
            args: id,
        },
    }, packedData);
    // create spore action
    if (scriptInfo.cobuild) {
        const output = tx.outputs[tx.outputs.length - 1];
        const createAction = (0, advanced_js_1.assembleCreateSporeAction)(output, packedData, scriptInfoHash);
        actions.push(createAction);
    }
    // complete cellDeps
    await tx.addCellDepInfos(signer.client, scriptInfo.cellDeps);
    const action = await (0, advanced_js_2.prepareCluster)(signer, tx, data, clusterMode);
    if (action) {
        actions.push(action);
    }
    return {
        tx: await (0, advanced_js_1.prepareSporeTransaction)(signer, tx, actions),
        id,
    };
}
/**
 * Transfer one Spore cell
 *
 * @param params.signer who takes the responsibility to balance and sign the transaction
 * @param params.id sporeId
 * @param params.to Spore's new owner
 * @param params.tx the transaction skeleton, if not provided, a new one will be created
 * @param params.scriptInfoHash the script info hash used in cobuild
 * @returns
 *  - **tx**: a new transaction that contains transferred Spore cells
 */
async function transferSpore(params) {
    const { signer, id, to, scripts, scriptInfoHash } = params;
    // prepare transaction
    const tx = core_1.ccc.Transaction.from(params.tx ?? {});
    const { cell: sporeCell, scriptInfo: sporeScriptInfo } = await assertSpore(signer.client, id, scripts);
    await tx.addCellDepInfos(signer.client, sporeScriptInfo.cellDeps);
    tx.addInput(sporeCell);
    tx.addOutput({
        lock: to,
        type: sporeCell.cellOutput.type,
    }, sporeCell.outputData);
    const actions = sporeScriptInfo.cobuild
        ? [
            (0, advanced_js_1.assembleTransferSporeAction)(sporeCell.cellOutput, tx.outputs[tx.outputs.length - 1], scriptInfoHash),
        ]
        : [];
    return {
        tx: await (0, advanced_js_1.prepareSporeTransaction)(signer, tx, actions),
    };
}
/**
 * Melt one Spore cell
 *
 * @param params.signer who takes the responsibility to balance and sign the transaction
 * @param params.id sporeId to be melted
 * @param params.tx the transaction skeleton, if not provided, a new one will be created
 * @param params.scriptInfoHash the script info hash used in cobuild
 * @returns
 *  - **tx**: a new transaction that contains melted Spore cell
 */
async function meltSpore(params) {
    const { signer, id, scripts, scriptInfoHash } = params;
    // prepare transaction
    const tx = core_1.ccc.Transaction.from(params.tx ?? {});
    // build spore cell
    const { cell: sporeCell, scriptInfo: sporeScriptInfo } = await assertSpore(signer.client, id, scripts);
    await tx.addCellDepInfos(signer.client, sporeScriptInfo.cellDeps);
    tx.addInput(sporeCell);
    const actions = sporeScriptInfo.cobuild
        ? [(0, advanced_js_1.assembleMeltSporeAction)(sporeCell.cellOutput, scriptInfoHash)]
        : [];
    return {
        tx: await (0, advanced_js_1.prepareSporeTransaction)(signer, tx, actions),
    };
}
/**
 * Search on-chain spores under the signer's control, if cluster provided, filter spores belonging to this cluster
 *
 * @param params.signer the owner of spores
 * @param params.order the order in creation time of spores
 * @param params.clusterId the cluster that spores belong to. "" to find public spores
 * @param params.scriptInfos the deployed script infos of spores
 * @returns specified spore cells
 */
async function* findSporesBySigner(params) {
    const { signer, clusterId, scriptInfos, limit, order } = params;
    for (const scriptInfo of scriptInfos ??
        Object.values((0, index_js_3.getSporeScriptInfos)(signer.client))) {
        if (!scriptInfo) {
            continue;
        }
        for await (const spore of signer.findCells({
            script: {
                ...scriptInfo,
                args: [],
            },
        }, true, order, limit)) {
            const sporeData = (0, index_js_1.unpackToRawSporeData)(spore.outputData);
            if (!clusterId ||
                (clusterId === "" && !sporeData.clusterId) ||
                sporeData.clusterId === core_1.ccc.hexFrom(clusterId)) {
                yield {
                    cell: spore,
                    spore,
                    sporeData,
                    scriptInfo: index_js_3.SporeScriptInfo.from(scriptInfo),
                };
            }
        }
    }
}
/**
 * Search on-chain spores under the specified lock or not, if cluster provided, filter spores belonging to this cluster
 *
 * @param params.client the client to search spores
 * @param params.lock the lock of spores
 * @param params.clusterId the cluster that spores belong to. "" to find public spores
 * @param params.scriptInfos the deployed script infos of spores
 * @param params.limit the limit of spores to search
 * @param params.order the order in creation time of spores
 * @returns specified spore cells
 */
async function* findSpores(params) {
    const { client, lock, clusterId, scriptInfos, limit, order } = params;
    for (const scriptInfo of scriptInfos ??
        Object.values((0, index_js_3.getSporeScriptInfos)(client))) {
        if (!scriptInfo) {
            continue;
        }
        for await (const spore of client.findCells({
            script: {
                ...scriptInfo,
                args: [],
            },
            scriptType: "type",
            scriptSearchMode: "prefix",
            withData: true,
            filter: lock
                ? {
                    script: lock,
                }
                : undefined,
        }, order, limit)) {
            const sporeData = (0, index_js_1.unpackToRawSporeData)(spore.outputData);
            if (!clusterId ||
                (clusterId === "" && !sporeData.clusterId) ||
                sporeData.clusterId === core_1.ccc.hexFrom(clusterId)) {
                yield {
                    cell: spore,
                    spore,
                    sporeData,
                    scriptInfo: index_js_3.SporeScriptInfo.from(scriptInfo),
                };
            }
        }
    }
}
