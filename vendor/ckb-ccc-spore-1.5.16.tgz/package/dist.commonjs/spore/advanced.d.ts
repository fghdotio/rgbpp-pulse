import { ccc } from "@ckb-ccc/core";
import { Action, SporeDataView } from "../codec/index.js";
export declare function prepareCluster(signer: ccc.Signer, tx: ccc.Transaction, data: SporeDataView, clusterMode?: "lockProxy" | "clusterCell" | "skip", scriptInfoHash?: ccc.HexLike): Promise<ccc.EncodableType<typeof Action> | undefined>;
//# sourceMappingURL=advanced.d.ts.map