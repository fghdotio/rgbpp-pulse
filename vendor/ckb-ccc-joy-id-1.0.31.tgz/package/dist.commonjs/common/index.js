"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPopup = createPopup;
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
const common_1 = require("@joyid/common");
/**
 * Creates a popup window for JoyID Dapp requests.
 * @param url - The URL to open in the popup.
 * @param config - The popup configuration options.
 * @returns A promise that resolves to the response data of the requested type.
 * @throws {PopupNotSupportedError} If popups are not supported in the current browser.
 * @throws {PopupCancelledError} If the popup is closed by the user.
 * @throws {PopupTimeoutError} If the popup operation times out.
 */
async function createPopup(url, config) {
    if (config.popup == null) {
        config.popup = (0, common_1.openPopup)("");
        if (config.popup == null) {
            return (0, common_1.createBlockDialog)(async () => createPopup(url, config));
        }
    }
    config.popup.location.href = url;
    return new Promise((resolve, reject) => {
        if ((0, common_1.isStandaloneBrowser)()) {
            reject(new common_1.PopupNotSupportedError(config.popup));
        }
        let popupEventListener;
        let timeoutId;
        // Check each second if the popup is closed triggering a PopupCancelledError
        const popupTimer = setInterval(() => {
            if (config.popup?.closed) {
                clearInterval(popupTimer);
                clearTimeout(timeoutId);
                window.removeEventListener("message", popupEventListener, false);
                reject(new common_1.PopupCancelledError(config.popup));
            }
        }, 1000);
        timeoutId = setTimeout(() => {
            clearInterval(popupTimer);
            reject(new common_1.PopupTimeoutError(config.popup));
            window.removeEventListener("message", popupEventListener, false);
        }, (config.timeoutInSeconds ?? 3000) * 1000);
        popupEventListener = (e) => {
            const { joyidAppURL } = config;
            const appURL = new URL(joyidAppURL);
            if (e.origin !== appURL.origin) {
                return;
            }
            if (!e.data || e.data?.type !== config.type) {
                return;
            }
            clearTimeout(timeoutId);
            clearInterval(popupTimer);
            window.removeEventListener("message", popupEventListener, false);
            config.popup.close();
            if (e.data.error) {
                reject(new Error(e.data.error));
            }
            resolve(e.data.data);
        };
        window.addEventListener("message", popupEventListener);
    });
}
