import { ccc } from "@ckb-ccc/core";
import { ConnectionsRepo } from "../connectionsStorage/index.js";
/**
 * Class representing a Bitcoin signer that extends SignerBtc
 * @public
 */
export declare class BitcoinSigner extends ccc.SignerBtc {
    readonly name: string;
    readonly icon: string;
    private readonly preferredNetworks;
    readonly addressType: "auto" | "p2wpkh" | "p2tr";
    private readonly _appUri?;
    private readonly connectionsRepo;
    private connection?;
    private network;
    /**
     * Ensures that the signer is connected and returns the connection.
     * @throws Will throw an error if not connected.
     * @returns The current connection.
     */
    private assertConnection;
    /**
     * Creates an instance of BitcoinSigner.
     * @param client - The client instance.
     * @param name - The name of the signer.
     * @param icon - The icon URL of the signer.
     * @param addressType - The address type.
     * @param _appUri - The application URI.
     * @param connectionsRepo - The connections repository.
     */
    constructor(client: ccc.Client, name: string, icon: string, preferredNetworks?: ccc.NetworkPreference[], addressType?: "auto" | "p2wpkh" | "p2tr", _appUri?: string | undefined, connectionsRepo?: ConnectionsRepo);
    /**
     * Gets the configuration for JoyID.
     * @returns The configuration object.
     */
    private getConfig;
    disconnect(): Promise<void>;
    /**
     * Gets the Bitcoin account address.
     * @returns A promise that resolves to the Bitcoin account address.
     */
    getBtcAccount(): Promise<string>;
    /**
     * Gets the Bitcoin public key.
     * @returns A promise that resolves to the Bitcoin public key.
     */
    getBtcPublicKey(): Promise<ccc.Hex>;
    /**
     * Connects to the provider by requesting authentication.
     * @returns A promise that resolves when the connection is established.
     */
    connect(): Promise<void>;
    /**
     * Checks if the signer is connected.
     * @returns A promise that resolves to true if connected, false otherwise.
     */
    isConnected(): Promise<boolean>;
    /**
     * Signs a raw message with the Bitcoin account.
     * @param message - The message to sign.
     * @returns A promise that resolves to the signed message.
     */
    signMessageRaw(message: string | ccc.BytesLike): Promise<string>;
    /**
     * Signs a PSBT using JoyID wallet.
     *
     * @param psbtHex - The hex string of PSBT to sign.
     * @returns A promise that resolves to the signed PSBT as a Hex string.
     */
    signPsbt(psbtHex: ccc.HexLike, options?: ccc.SignPsbtOptionsLike): Promise<ccc.Hex>;
    /**
     * Broadcasts a PSBT to the Bitcoin network.
     *
     * @remarks
     * JoyID does not support broadcasting a signed PSBT directly.
     * It only supports "Sign and Broadcast" as a single atomic operation via `signAndBroadcastPsbt`.
     */
    broadcastPsbt(_psbtHex: ccc.HexLike, _options?: ccc.SignPsbtOptionsLike): Promise<ccc.Hex>;
    signAndBroadcastPsbt(psbtHex: ccc.HexLike, options?: ccc.SignPsbtOptionsLike): Promise<ccc.Hex>;
}
//# sourceMappingURL=index.d.ts.map