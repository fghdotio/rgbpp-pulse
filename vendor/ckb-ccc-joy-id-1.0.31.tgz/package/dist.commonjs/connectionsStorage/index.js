"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConnectionsRepoLocalStorage = void 0;
exports.isSelectorMatch = isSelectorMatch;
/**
 * Checks if a AccountSelector matches the filter
 * @param a - The first account selector.
 * @param filter - The account selector filter.
 * @returns True if the selector matches the filter
 */
function isSelectorMatch(a, filter) {
    return a.uri === filter.uri && a.addressType.startsWith(filter.addressType);
}
/**
 * Class representing a local storage-based repository for managing connections.
 */
class ConnectionsRepoLocalStorage {
    /**
     * Creates an instance of ConnectionsRepoLocalStorage.
     * @param [storageKey="ccc-joy-id-signer"] - The local storage key.
     */
    constructor(storageKey = "ccc-joy-id-signer") {
        this.storageKey = storageKey;
        this.operationLock = Promise.resolve();
    }
    /**
     * Reads all connections from local storage.
     * @returns A promise that resolves to an array of selectors and connections.
     */
    async readConnections() {
        return JSON.parse(window.localStorage.getItem(this.storageKey) ?? "[]");
    }
    /**
     * Gets a connection for the given selector.
     * @param selector - The account selector.
     * @returns A promise that resolves to the connection, if found.
     */
    async get(selector) {
        return (await this.readConnections()).find(([s]) => isSelectorMatch(selector, s))?.[1];
    }
    /**
     * Sets a connection for the given selector.
     * @param selector - The account selector.
     * @param connection - The connection to set.
     * @returns
     */
    async set(selector, connection) {
        const operation = this.operationLock
            .catch(() => undefined)
            .then(async () => {
            const connections = await this.readConnections();
            if (connection) {
                const existed = connections.find(([s]) => isSelectorMatch(s, selector));
                if (existed) {
                    existed[1] = connection;
                }
                else {
                    connections.push([selector, connection]);
                }
                window.localStorage.setItem(this.storageKey, JSON.stringify(connections));
            }
            else {
                window.localStorage.setItem(this.storageKey, JSON.stringify(connections.filter(([s]) => !isSelectorMatch(s, selector))));
            }
        });
        this.operationLock = operation;
        await operation;
    }
}
exports.ConnectionsRepoLocalStorage = ConnectionsRepoLocalStorage;
