import { ccc } from "@ckb-ccc/core";
/**
 * Type representing an account selector with a URI and address type.
 */
export type AccountSelector = {
    /**
     * The URI of the account.
     */
    uri: string;
    /**
     * The address type of the account.
     */
    addressType: string;
};
/**
 * Checks if a AccountSelector matches the filter
 * @param a - The first account selector.
 * @param filter - The account selector filter.
 * @returns True if the selector matches the filter
 */
export declare function isSelectorMatch(a: AccountSelector, filter: AccountSelector): boolean;
/**
 * Type representing a connection with an address, public key, and key type.
 */
export type Connection = {
    /**
     * The address of the connection.
     */
    readonly address: string;
    /**
     * The public key of the connection.
     */
    readonly publicKey: ccc.Hex;
    /**
     * The key type of the connection.
     */
    readonly keyType: string;
};
/**
 * Interface representing a repository for managing connections.
 */
export interface ConnectionsRepo {
    /**
     * Gets a connection for the given selector.
     * @param selector - The account selector.
     * @returns A promise that resolves to the connection, if found.
     */
    get(selector: AccountSelector): Promise<Connection | undefined>;
    /**
     * Sets a connection for the given selector.
     * @param selector - The account selector.
     * @param connection - The connection to set.
     * @returns A promise that resolves when the connection is set.
     */
    set(selector: AccountSelector, connection: Connection | undefined): Promise<void>;
}
/**
 * Class representing a local storage-based repository for managing connections.
 */
export declare class ConnectionsRepoLocalStorage implements ConnectionsRepo {
    private readonly storageKey;
    private operationLock;
    /**
     * Creates an instance of ConnectionsRepoLocalStorage.
     * @param [storageKey="ccc-joy-id-signer"] - The local storage key.
     */
    constructor(storageKey?: string);
    /**
     * Reads all connections from local storage.
     * @returns A promise that resolves to an array of selectors and connections.
     */
    readConnections(): Promise<[AccountSelector, Connection][]>;
    /**
     * Gets a connection for the given selector.
     * @param selector - The account selector.
     * @returns A promise that resolves to the connection, if found.
     */
    get(selector: AccountSelector): Promise<Connection | undefined>;
    /**
     * Sets a connection for the given selector.
     * @param selector - The account selector.
     * @param connection - The connection to set.
     * @returns
     */
    set(selector: AccountSelector, connection: Connection | undefined): Promise<void>;
}
//# sourceMappingURL=index.d.ts.map