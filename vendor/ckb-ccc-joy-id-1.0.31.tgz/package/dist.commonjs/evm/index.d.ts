import { ccc } from "@ckb-ccc/core";
import { ConnectionsRepo } from "../connectionsStorage/index.js";
/**
 * Class representing an EVM signer that extends SignerEvm
 * @public
 */
export declare class EvmSigner extends ccc.SignerEvm {
    private readonly name;
    private readonly icon;
    private readonly _appUri?;
    private readonly connectionsRepo;
    private connection?;
    /**
     * Ensures that the signer is connected and returns the connection.
     * @throws Will throw an error if not connected.
     * @returns The current connection.
     */
    private assertConnection;
    /**
     * Creates an instance of EvmSigner.
     * @param client - The client instance.
     * @param name - The name of the signer.
     * @param icon - The icon URL of the signer.
     * @param _appUri - The application URI.
     * @param connectionsRepo - The connections repository.
     */
    constructor(client: ccc.Client, name: string, icon: string, _appUri?: string | undefined, connectionsRepo?: ConnectionsRepo);
    /**
     * Gets the configuration for JoyID.
     * @returns The configuration object.
     */
    private getConfig;
    /**
     * Gets the EVM account address.
     * @returns A promise that resolves to the EVM account address.
     */
    getEvmAccount(): Promise<ccc.Hex>;
    /**
     * Connects to the provider by requesting authentication.
     * @returns A promise that resolves when the connection is established.
     */
    connect(): Promise<void>;
    disconnect(): Promise<void>;
    /**
     * Checks if the signer is connected.
     * @returns A promise that resolves to true if connected, false otherwise.
     */
    isConnected(): Promise<boolean>;
    /**
     * Signs a raw message with the EVM account.
     * @param message - The message to sign.
     * @returns A promise that resolves to the signed message.
     */
    signMessageRaw(message: string | ccc.BytesLike): Promise<ccc.Hex>;
    /**
     * Saves the current connection.
     * @returns
     */
    private saveConnection;
    /**
     * Restores the previous connection.
     * @returns
     */
    private restoreConnection;
}
//# sourceMappingURL=index.d.ts.map