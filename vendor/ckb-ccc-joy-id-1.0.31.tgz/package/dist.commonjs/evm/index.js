"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EvmSigner = void 0;
const core_1 = require("@ckb-ccc/core");
const common_1 = require("@joyid/common");
const index_js_1 = require("../common/index.js");
const index_js_2 = require("../connectionsStorage/index.js");
/**
 * Class representing an EVM signer that extends SignerEvm
 * @public
 */
class EvmSigner extends core_1.ccc.SignerEvm {
    /**
     * Ensures that the signer is connected and returns the connection.
     * @throws Will throw an error if not connected.
     * @returns The current connection.
     */
    async assertConnection() {
        if (!(await this.isConnected()) || !this.connection) {
            throw new Error("Not connected");
        }
        return this.connection;
    }
    /**
     * Creates an instance of EvmSigner.
     * @param client - The client instance.
     * @param name - The name of the signer.
     * @param icon - The icon URL of the signer.
     * @param _appUri - The application URI.
     * @param connectionsRepo - The connections repository.
     */
    constructor(client, name, icon, _appUri, connectionsRepo = new index_js_2.ConnectionsRepoLocalStorage()) {
        super(client);
        this.name = name;
        this.icon = icon;
        this._appUri = _appUri;
        this.connectionsRepo = connectionsRepo;
    }
    /**
     * Gets the configuration for JoyID.
     * @returns The configuration object.
     */
    getConfig() {
        return {
            redirectURL: location.href,
            joyidAppURL: this._appUri ??
                (this.client.addressPrefix === "ckb"
                    ? "https://app.joy.id"
                    : "https://testnet.joyid.dev"),
            requestNetwork: `ethereum`,
            name: this.name,
            logo: this.icon,
        };
    }
    /**
     * Gets the EVM account address.
     * @returns A promise that resolves to the EVM account address.
     */
    async getEvmAccount() {
        return (await this.assertConnection()).address;
    }
    /**
     * Connects to the provider by requesting authentication.
     * @returns A promise that resolves when the connection is established.
     */
    async connect() {
        const config = this.getConfig();
        const res = await (0, index_js_1.createPopup)((0, common_1.buildJoyIDURL)(config, "popup", "/auth"), {
            ...config,
            type: common_1.DappRequestType.Auth,
        });
        this.connection = {
            address: res.ethAddress,
            publicKey: core_1.ccc.hexFrom(res.pubkey),
            keyType: res.keyType,
        };
        await this.saveConnection();
    }
    async disconnect() {
        await super.disconnect();
        this.connection = undefined;
        await this.saveConnection();
    }
    /**
     * Checks if the signer is connected.
     * @returns A promise that resolves to true if connected, false otherwise.
     */
    async isConnected() {
        if (this.connection) {
            return true;
        }
        await this.restoreConnection();
        return this.connection !== undefined;
    }
    /**
     * Signs a raw message with the EVM account.
     * @param message - The message to sign.
     * @returns A promise that resolves to the signed message.
     */
    async signMessageRaw(message) {
        const { address } = await this.assertConnection();
        const challenge = typeof message === "string" ? message : core_1.ccc.hexFrom(message).slice(2);
        const config = this.getConfig();
        const { signature } = await (0, index_js_1.createPopup)((0, common_1.buildJoyIDURL)({
            ...config,
            challenge,
            isData: typeof message !== "string",
            address,
        }, "popup", "/sign-message"), { ...config, type: common_1.DappRequestType.SignMessage });
        return core_1.ccc.hexFrom(signature);
    }
    /**
     * Saves the current connection.
     * @returns
     */
    async saveConnection() {
        return this.connectionsRepo.set({
            uri: this.getConfig().joyidAppURL,
            addressType: "ethereum",
        }, this.connection);
    }
    /**
     * Restores the previous connection.
     * @returns
     */
    async restoreConnection() {
        this.connection = await this.connectionsRepo.get({
            uri: this.getConfig().joyidAppURL,
            addressType: "ethereum",
        });
    }
}
exports.EvmSigner = EvmSigner;
