"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CkbSigner = void 0;
const core_1 = require("@ckb-ccc/core");
const ckb_1 = require("@joyid/ckb");
const common_1 = require("@joyid/common");
const index_js_1 = require("../common/index.js");
const index_js_2 = require("../connectionsStorage/index.js");
/**
 * Class representing a CKB signer that extends Signer
 * @public
 */
class CkbSigner extends core_1.ccc.Signer {
    /**
     * Gets the signer type.
     * @returns The type of the signer.
     */
    get type() {
        return core_1.ccc.SignerType.CKB;
    }
    /**
     * Gets the sign type.
     * @returns The sign type.
     */
    get signType() {
        return core_1.ccc.SignerSignType.JoyId;
    }
    /**
     * Ensures that the signer is connected and returns the connection.
     * @throws Will throw an error if not connected.
     * @returns A promise that resolves to the current connection.
     */
    async assertConnection() {
        if (!(await this.isConnected()) || !this.connection) {
            throw new Error("Not connected");
        }
        return this.connection;
    }
    /**
     * Creates an instance of CkbSigner.
     * @param client - The client instance.
     * @param name - The name of the signer.
     * @param icon - The icon URL of the signer.
     * @param _appUri - The application URI.
     * @param _aggregatorUri - The aggregator URI.
     * @param connectionsRepo - The connections repository.
     */
    constructor(client, name, icon, _appUri, _aggregatorUri, connectionsRepo = new index_js_2.ConnectionsRepoLocalStorage()) {
        super(client);
        this.name = name;
        this.icon = icon;
        this._appUri = _appUri;
        this._aggregatorUri = _aggregatorUri;
        this.connectionsRepo = connectionsRepo;
    }
    /**
     * Gets the configuration for JoyID.
     * @returns The configuration object.
     */
    getConfig() {
        return {
            redirectURL: location.href,
            joyidAppURL: this._appUri ??
                (this.client.addressPrefix === "ckb"
                    ? "https://app.joy.id"
                    : "https://testnet.joyid.dev"),
            name: this.name,
            logo: this.icon,
        };
    }
    /**
     * Gets the aggregator URI.
     * @returns The aggregator URI.
     */
    getAggregatorUri() {
        return (this._aggregatorUri ??
            (this.client.addressPrefix === "ckb"
                ? "https://cota.nervina.dev/mainnet-aggregator"
                : "https://cota.nervina.dev/aggregator"));
    }
    /**
     * Connects to the provider by requesting authentication.
     * @returns A promise that resolves when the connection is established.
     */
    async connect() {
        const config = this.getConfig();
        const res = await (0, index_js_1.createPopup)((0, common_1.buildJoyIDURL)(config, "popup", "/auth"), {
            ...config,
            type: common_1.DappRequestType.Auth,
        });
        this.connection = {
            address: res.address,
            publicKey: core_1.ccc.hexFrom(res.pubkey),
            keyType: res.keyType,
        };
        await this.saveConnection();
    }
    async disconnect() {
        await super.disconnect();
        this.connection = undefined;
        await this.saveConnection();
    }
    /**
     * Checks if the signer is connected.
     * @returns A promise that resolves to true if connected, false otherwise.
     */
    async isConnected() {
        if (this.connection) {
            return true;
        }
        await this.restoreConnection();
        return this.connection !== undefined;
    }
    /**
     * Gets the internal address.
     * @returns A promise that resolves to the internal address.
     */
    async getInternalAddress() {
        return (await this.assertConnection()).address;
    }
    /**
     * Gets the identity of the signer.
     * @returns A promise that resolves to the identity.
     */
    async getIdentity() {
        const connection = await this.assertConnection();
        return JSON.stringify({
            keyType: connection.keyType,
            publicKey: connection.publicKey.slice(2),
        });
    }
    /**
     * Gets the address object.
     * @returns A promise that resolves to the address object.
     */
    async getAddressObj() {
        return await core_1.ccc.Address.fromString(await this.getInternalAddress(), this.client);
    }
    /**
     * Gets the address objects.
     * @returns A promise that resolves to an array of address objects.
     */
    async getAddressObjs() {
        return [await this.getAddressObj()];
    }
    /**
     * Prepares a transaction.
     * @param txLike - The transaction-like object.
     * @returns A promise that resolves to the prepared transaction.
     */
    async prepareTransaction(txLike) {
        const tx = core_1.ccc.Transaction.from(txLike);
        await tx.addCellDepsOfKnownScripts(this.client, core_1.ccc.KnownScript.JoyId);
        const position = await tx.findInputIndexByLock((await this.getAddressObj()).script, this.client);
        if (position === undefined) {
            return tx;
        }
        const witness = tx.getWitnessArgsAt(position) ?? core_1.ccc.WitnessArgs.from({});
        witness.lock = core_1.ccc.hexFrom("00".repeat(1000));
        await this.prepareTransactionForSubKey(tx, witness);
        tx.setWitnessArgsAt(position, witness);
        return tx;
    }
    /**
     * Prepares a transaction for a sub key.
     * @param tx - The transaction object.
     * @param witness - The witness arguments.
     * @throws Will throw an error if no COTA cells are found for the sub key wallet.
     */
    async prepareTransactionForSubKey(tx, witness) {
        if (this.connection?.keyType !== "sub_key" ||
            (witness.outputType ?? "0x") !== "0x") {
            return;
        }
        const pubkeyHash = core_1.ccc.hashCkb(this.connection.publicKey).substring(0, 42);
        const lock = (await this.getAddressObj()).script;
        const aggregator = new ckb_1.Aggregator(this.getAggregatorUri());
        const { unlock_entry: unlockEntry } = await aggregator.generateSubkeyUnlockSmt({
            alg_index: 1,
            pubkey_hash: pubkeyHash,
            lock_script: core_1.ccc.hexFrom(lock.toBytes()),
        });
        witness.outputType = core_1.ccc.hexFrom(unlockEntry);
        const cotaDeps = [];
        for await (const cell of this.client.findCellsByLock(lock, await core_1.ccc.Script.fromKnownScript(this.client, core_1.ccc.KnownScript.COTA, "0x"))) {
            cotaDeps.push(core_1.ccc.CellDep.from({
                depType: "code",
                outPoint: cell.outPoint,
            }));
        }
        if (cotaDeps.length === 0) {
            throw new Error("No COTA cells for sub key wallet");
        }
        tx.addCellDepsAtStart(cotaDeps);
    }
    /**
     * Signs a transaction.
     * @param txLike - The transaction-like object.
     * @returns A promise that resolves to the signed transaction.
     */
    async signOnlyTransaction(txLike) {
        const tx = core_1.ccc.Transaction.from(txLike);
        const { script } = await this.getAddressObj();
        const witnessIndexes = await core_1.ccc.reduceAsync(tx.inputs, async (acc, input, i) => {
            const { cellOutput } = await input.getCell(this.client);
            if (cellOutput.lock.eq(script)) {
                acc.push(i);
            }
        }, []);
        // Trim unnecessary fields to reduce tx size
        await tx.prepareSighashAllWitness(script, 0, this.client);
        tx.inputs.forEach((i) => {
            i.cellOutput = undefined;
            i.outputData = undefined;
        });
        const config = this.getConfig();
        const res = await (0, index_js_1.createPopup)((0, common_1.buildJoyIDURL)({
            ...config,
            // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
            tx: JSON.parse(tx.stringify()),
            signerAddress: (await this.assertConnection()).address,
            witnessIndexes,
        }, "popup", "/sign-ckb-raw-tx"), {
            ...config,
            type: common_1.DappRequestType.SignCkbRawTx,
        });
        return core_1.ccc.Transaction.from(res.tx);
    }
    /**
     * Signs a raw message with the account.
     * @param message - The message to sign.
     * @returns A promise that resolves to the signed message.
     */
    async signMessageRaw(message) {
        const { address } = await this.assertConnection();
        const challenge = typeof message === "string" ? message : core_1.ccc.hexFrom(message).slice(2);
        const config = this.getConfig();
        const res = await (0, index_js_1.createPopup)((0, common_1.buildJoyIDURL)({
            ...config,
            challenge,
            isData: typeof message !== "string",
            address,
        }, "popup", "/sign-message"), { ...config, type: common_1.DappRequestType.SignMessage });
        return JSON.stringify({
            signature: res.signature,
            alg: res.alg,
            message: res.message,
        });
    }
    /**
     * Saves the current connection.
     * @returns
     */
    async saveConnection() {
        return this.connectionsRepo.set({
            uri: this.getConfig().joyidAppURL,
            addressType: "ckb",
        }, this.connection);
    }
    /**
     * Restores the previous connection.
     * @returns
     */
    async restoreConnection() {
        this.connection = await this.connectionsRepo.get({
            uri: this.getConfig().joyidAppURL,
            addressType: "ckb",
        });
    }
}
exports.CkbSigner = CkbSigner;
