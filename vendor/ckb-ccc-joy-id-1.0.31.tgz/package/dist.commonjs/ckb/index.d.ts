import { ccc } from "@ckb-ccc/core";
import { ConnectionsRepo } from "../connectionsStorage/index.js";
/**
 * Class representing a CKB signer that extends Signer
 * @public
 */
export declare class CkbSigner extends ccc.Signer {
    private readonly name;
    private readonly icon;
    private readonly _appUri?;
    private readonly _aggregatorUri?;
    private readonly connectionsRepo;
    /**
     * Gets the signer type.
     * @returns The type of the signer.
     */
    get type(): ccc.SignerType;
    /**
     * Gets the sign type.
     * @returns The sign type.
     */
    get signType(): ccc.SignerSignType;
    private connection?;
    /**
     * Ensures that the signer is connected and returns the connection.
     * @throws Will throw an error if not connected.
     * @returns A promise that resolves to the current connection.
     */
    private assertConnection;
    /**
     * Creates an instance of CkbSigner.
     * @param client - The client instance.
     * @param name - The name of the signer.
     * @param icon - The icon URL of the signer.
     * @param _appUri - The application URI.
     * @param _aggregatorUri - The aggregator URI.
     * @param connectionsRepo - The connections repository.
     */
    constructor(client: ccc.Client, name: string, icon: string, _appUri?: string | undefined, _aggregatorUri?: string | undefined, connectionsRepo?: ConnectionsRepo);
    /**
     * Gets the configuration for JoyID.
     * @returns The configuration object.
     */
    private getConfig;
    /**
     * Gets the aggregator URI.
     * @returns The aggregator URI.
     */
    private getAggregatorUri;
    /**
     * Connects to the provider by requesting authentication.
     * @returns A promise that resolves when the connection is established.
     */
    connect(): Promise<void>;
    disconnect(): Promise<void>;
    /**
     * Checks if the signer is connected.
     * @returns A promise that resolves to true if connected, false otherwise.
     */
    isConnected(): Promise<boolean>;
    /**
     * Gets the internal address.
     * @returns A promise that resolves to the internal address.
     */
    getInternalAddress(): Promise<string>;
    /**
     * Gets the identity of the signer.
     * @returns A promise that resolves to the identity.
     */
    getIdentity(): Promise<string>;
    /**
     * Gets the address object.
     * @returns A promise that resolves to the address object.
     */
    getAddressObj(): Promise<ccc.Address>;
    /**
     * Gets the address objects.
     * @returns A promise that resolves to an array of address objects.
     */
    getAddressObjs(): Promise<ccc.Address[]>;
    /**
     * Prepares a transaction.
     * @param txLike - The transaction-like object.
     * @returns A promise that resolves to the prepared transaction.
     */
    prepareTransaction(txLike: ccc.TransactionLike): Promise<ccc.Transaction>;
    /**
     * Prepares a transaction for a sub key.
     * @param tx - The transaction object.
     * @param witness - The witness arguments.
     * @throws Will throw an error if no COTA cells are found for the sub key wallet.
     */
    private prepareTransactionForSubKey;
    /**
     * Signs a transaction.
     * @param txLike - The transaction-like object.
     * @returns A promise that resolves to the signed transaction.
     */
    signOnlyTransaction(txLike: ccc.TransactionLike): Promise<ccc.Transaction>;
    /**
     * Signs a raw message with the account.
     * @param message - The message to sign.
     * @returns A promise that resolves to the signed message.
     */
    signMessageRaw(message: string | ccc.BytesLike): Promise<string>;
    /**
     * Saves the current connection.
     * @returns
     */
    private saveConnection;
    /**
     * Restores the previous connection.
     * @returns
     */
    private restoreConnection;
}
//# sourceMappingURL=index.d.ts.map