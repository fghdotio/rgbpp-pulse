"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getJoyIdSigners = getJoyIdSigners;
const core_1 = require("@ckb-ccc/core");
const common_1 = require("@joyid/common");
const index_js_1 = require("../btc/index.js");
const index_js_2 = require("../ckb/index.js");
const index_js_3 = require("../evm/index.js");
const index_js_4 = require("../nostr/index.js");
/**
 * Gets the JoyID signers based on the client, name, and icon.
 * If the browser is standalone or a webview, returns SignerAlwaysError instances.
 * Otherwise, returns instances of CkbSigner, BitcoinSigner, and EvmSigner.
 * @public
 *
 * @param client - The client instance.
 * @param name - The name of the signer.
 * @param icon - The icon URL of the signer.
 * @returns An array of signer information objects.
 */
function getJoyIdSigners(client, name, icon, preferredNetworks) {
    if ((0, common_1.isStandaloneBrowser)() || core_1.ccc.isWebview(window.navigator.userAgent)) {
        return [core_1.ccc.SignerType.CKB, core_1.ccc.SignerType.EVM, core_1.ccc.SignerType.BTC].map((type) => ({
            name: type,
            signer: new core_1.ccc.SignerAlwaysError(client, type, "JoyID can only be used with standard browsers"),
        }));
    }
    return [
        {
            name: "CKB",
            signer: new index_js_2.CkbSigner(client, name, icon),
        },
        {
            name: "BTC",
            signer: new index_js_1.BitcoinSigner(client, name, icon, preferredNetworks),
        },
        {
            name: "Nostr",
            signer: new index_js_4.NostrSigner(client, name, icon),
        },
        {
            name: "EVM",
            signer: new index_js_3.EvmSigner(client, name, icon),
        },
        {
            name: "BTC (P2WPKH)",
            signer: new index_js_1.BitcoinSigner(client, name, icon, preferredNetworks, "p2wpkh"),
        },
        {
            name: "BTC (P2TR)",
            signer: new index_js_1.BitcoinSigner(client, name, icon, preferredNetworks, "p2tr"),
        },
    ];
}
