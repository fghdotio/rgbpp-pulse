import { ccc } from "@ckb-ccc/core";
/**
 * Gets the JoyID signers based on the client, name, and icon.
 * If the browser is standalone or a webview, returns SignerAlwaysError instances.
 * Otherwise, returns instances of CkbSigner, BitcoinSigner, and EvmSigner.
 * @public
 *
 * @param client - The client instance.
 * @param name - The name of the signer.
 * @param icon - The icon URL of the signer.
 * @returns An array of signer information objects.
 */
export declare function getJoyIdSigners(client: ccc.Client, name: string, icon: string, preferredNetworks?: ccc.NetworkPreference[]): ccc.SignerInfo[];
//# sourceMappingURL=index.d.ts.map