import { ccc } from "@ckb-ccc/core";
import { ConnectionsRepo } from "../connectionsStorage/index.js";
/**
 * Class representing a Nostr signer that extends SignerNostr
 * @public
 */
export declare class NostrSigner extends ccc.SignerNostr {
    private readonly name;
    private readonly icon;
    private readonly _appUri?;
    private readonly connectionsRepo;
    private connection?;
    /**
     * Ensures that the signer is connected and returns the connection.
     * @throws Will throw an error if not connected.
     * @returns The current connection.
     */
    private assertConnection;
    /**
     * Creates an instance of NostrSigner.
     * @param client - The client instance.
     * @param name - The name of the signer.
     * @param icon - The icon URL of the signer.
     * @param _appUri - The application URI.
     * @param connectionsRepo - The connections repository.
     */
    constructor(client: ccc.Client, name: string, icon: string, _appUri?: string | undefined, connectionsRepo?: ConnectionsRepo);
    /**
     * Gets the configuration for JoyID.
     * @returns The configuration object.
     */
    private getConfig;
    /**
     * Connects to the provider by requesting authentication.
     * @returns A promise that resolves when the connection is established.
     */
    connect(): Promise<void>;
    disconnect(): Promise<void>;
    /**
     * Checks if the signer is connected.
     * @returns A promise that resolves to true if connected, false otherwise.
     */
    isConnected(): Promise<boolean>;
    getNostrPublicKey(): Promise<ccc.Hex>;
    signNostrEvent(event: ccc.NostrEvent): Promise<Required<ccc.NostrEvent>>;
    /**
     * Saves the current connection.
     * @returns
     */
    private saveConnection;
    /**
     * Restores the previous connection.
     * @returns
     */
    private restoreConnection;
}
//# sourceMappingURL=index.d.ts.map