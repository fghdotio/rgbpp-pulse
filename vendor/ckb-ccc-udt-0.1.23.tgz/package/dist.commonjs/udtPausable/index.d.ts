import { ccc } from "@ckb-ccc/core";
import { ssri } from "@ckb-ccc/ssri";
import { Udt } from "../udt/index.js";
/**
 * Represents a UDT (User Defined Token) with pausable functionality.
 * @extends {Udt} This must be a SSRI UDT that does not fallback to xUDT.
 * @public
 */
export declare class UdtPausable extends Udt {
    constructor(code: ccc.OutPointLike, script: ccc.ScriptLike, config: {
        executor: ssri.Executor;
    });
    /**
     * Pauses the UDT for the specified lock hashes. Pausing/Unpause without lock hashes should take effect on the global level. Note that this method is only available if the pausable UDT uses external pause list.
     * @param {ccc.HexLike[]} lockHashes - The array of lock hashes to be paused.
     * @param {ccc.TransactionLike} tx - The transaction to be used.
     * @returns The transaction result.
     * @tag Mutation - This method represents a mutation of the onchain state and will return a transaction to be sent.
     */
    pause(signer: ccc.Signer, locks: ccc.ScriptLike[], tx?: ccc.TransactionLike | null, extraLockHashes?: ccc.HexLike[] | null): Promise<ssri.ExecutorResponse<ccc.Transaction>>;
    /**
     * Unpauses the UDT for the specified lock hashes. Note that this method is only available if the pausable UDT uses external pause list.
     * @param tx - The transaction to be used.
     * @param lockHashes - The array of lock hashes to be unpaused.
     * @returns The transaction result.
     * @tag Mutation - This method represents a mutation of the onchain state and will return a transaction to be sent.
     */
    unpause(signer: ccc.Signer, locks: ccc.ScriptLike[], tx?: ccc.TransactionLike | null, extraLockHashes?: ccc.HexLike[] | null): Promise<ssri.ExecutorResponse<ccc.Transaction>>;
    /**
     * Checks if the UDT is paused for the specified lock hashes within a transaction. If not using external pause list, it can also be run on Code environment level.
     * @param lockHashes - The lock hashes to check.
     * @returns True if any of the lock hashes are paused, false otherwise.
     */
    isPaused(locks: ccc.ScriptLike[], extraLockHashes?: ccc.HexLike[] | null): Promise<ssri.ExecutorResponse<boolean[]>>;
    /**
     * Enumerates all paused lock hashes in UDTPausableData.
     * @returns The array of lock hashes.
     */
    enumeratePaused(offset?: ccc.Num, limit?: ccc.Num): Promise<ssri.ExecutorResponse<ccc.Hex[]>>;
}
//# sourceMappingURL=index.d.ts.map