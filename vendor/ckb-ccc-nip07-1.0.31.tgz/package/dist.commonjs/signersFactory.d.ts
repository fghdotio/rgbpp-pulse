import { ccc } from "@ckb-ccc/core";
import { Signer } from "./signer.js";
/**
 * @public
 */
export declare function getNip07Signer(client: ccc.Client): Signer | undefined;
//# sourceMappingURL=signersFactory.d.ts.map