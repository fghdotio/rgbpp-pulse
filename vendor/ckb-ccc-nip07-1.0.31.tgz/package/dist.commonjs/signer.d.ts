import { ccc } from "@ckb-ccc/core";
import { Provider } from "./nip07.advanced.js";
/**
 * @public
 */
export declare class Signer extends ccc.SignerNostr {
    readonly provider: Provider;
    private publicKeyCache?;
    constructor(client: ccc.Client, provider: Provider);
    getNostrPublicKey(): Promise<ccc.Hex>;
    signNostrEvent(event: ccc.NostrEvent): Promise<Required<ccc.NostrEvent>>;
    connect(): Promise<void>;
    isConnected(): Promise<boolean>;
}
//# sourceMappingURL=signer.d.ts.map