"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getNip07Signer = getNip07Signer;
const signer_js_1 = require("./signer.js");
/**
 * @public
 */
function getNip07Signer(client) {
    const windowRef = window;
    if (typeof windowRef.nostr === "undefined") {
        return;
    }
    return new signer_js_1.Signer(client, windowRef.nostr);
}
