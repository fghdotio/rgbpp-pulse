"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Signer = void 0;
const core_1 = require("@ckb-ccc/core");
/**
 * @public
 */
class Signer extends core_1.ccc.SignerNostr {
    constructor(client, provider) {
        super(client);
        this.provider = provider;
        this.publicKeyCache = undefined;
    }
    async getNostrPublicKey() {
        if (!this.publicKeyCache) {
            this.publicKeyCache = this.provider.getPublicKey().catch((e) => {
                this.publicKeyCache = undefined;
                throw e;
            });
        }
        return core_1.ccc.hexFrom(await this.publicKeyCache);
    }
    async signNostrEvent(event) {
        return this.provider.signEvent({
            ...event,
            pubkey: await this.publicKeyCache,
        });
    }
    async connect() {
        await this.getNostrPublicKey();
    }
    async isConnected() {
        return true;
    }
}
exports.Signer = Signer;
