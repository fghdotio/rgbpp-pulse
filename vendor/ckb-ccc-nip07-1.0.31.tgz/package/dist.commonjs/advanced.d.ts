export * as Nip07A from "./nip07.advanced.js";
//# sourceMappingURL=advanced.d.ts.map