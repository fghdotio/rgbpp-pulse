import { ccc } from "@ckb-ccc/core";

//#region src/advancedBarrel.d.ts
declare namespace advancedBarrel_d_exports {
  export { buildTypeIdOperations };
}
/**
 * Build Type ID operations.
 *
 * @param props The properties to build the operations.
 * @param props.getScriptInfo Function to get the script info.
 * @param props.calculateTypeId Function to calculate the Type ID.
 * @param props.addCellDeps Function to add cell dependencies.
 */
declare function buildTypeIdOperations<Encodable = ccc.BytesLike, Decoded = ccc.Bytes>(props: {
  getScriptInfo: (client: ccc.Client) => Promise<ccc.ScriptInfoLike>;
  codec?: ccc.CodecLike<Encodable, Decoded> | null;
  calculateTypeId?: ((client: ccc.Client, tx: ccc.Transaction) => Promise<ccc.HexLike>) | null;
  addCellDeps?: ((client: ccc.Client, tx: ccc.Transaction, scriptInfo: ccc.ScriptInfo) => Promise<ccc.TransactionLike>) | null;
}): {
  /**
   * Create a Type ID cell.
   *
   * @param props The arguments for creating the cell.
   * @param props.signer The signer to sign the transaction.
   * @param props.receiver The receiver script (optional).
   * @param props.data The output data.
   * @param props.tx The transaction skeleton (optional).
   */
  create(this: void, props: {
    signer: ccc.Signer;
    data: Encodable;
    receiver?: ccc.ScriptLike | null;
    tx?: ccc.TransactionLike | null;
  }): Promise<{
    tx: ccc.Transaction;
    id: ccc.Hex;
    index: number;
  }>;
  /**
   * Transfer a Type ID cell.
   *
   * @param props The arguments for transferring the cell.
   * @param props.client The client to communicate with CKB.
   * @param props.id The Type ID to transfer.
   * @param props.receiver The new receiver script.
   * @param props.tx The transaction skeleton (optional).
   * @param props.data The new output data or a transformer to update the data (optional).
   */
  transfer(this: void, props: {
    client: ccc.Client;
    id: ccc.HexLike;
    receiver: ccc.ScriptLike;
    tx?: ccc.TransactionLike | null;
    data?: Encodable | ((cell: ccc.Cell, data?: Decoded) => Encodable | Promise<Encodable>) | null;
  }): Promise<{
    tx: ccc.Transaction;
    inIndex: number;
    outIndex: number;
  }>;
  /**
   * Destroy a Type ID cell.
   *
   * @param props The arguments for destroying the cell.
   * @param props.client The client to communicate with CKB.
   * @param props.id The Type ID to destroy.
   * @param props.tx The transaction skeleton (optional).
   */
  destroy(this: void, props: {
    client: ccc.Client;
    id: ccc.HexLike;
    tx?: ccc.TransactionLike | null;
  }): Promise<{
    tx: ccc.Transaction;
    index: number;
  }>;
};
//#endregion
export { buildTypeIdOperations, advancedBarrel_d_exports as t };
//# sourceMappingURL=advancedBarrel.d.ts.map