import { createTypeId, destroyTypeId, t as barrel_d_exports, transferTypeId } from "./barrel.js";
export { createTypeId, destroyTypeId, transferTypeId, barrel_d_exports as typeId };