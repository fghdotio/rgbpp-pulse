import { ccc } from "@ckb-ccc/core";

//#region src/barrel.d.ts
declare namespace barrel_d_exports {
  export { createTypeId, destroyTypeId, transferTypeId };
}
declare const createTypeId: (this: void, props: {
    signer: ccc.Signer;
    data: ccc.BytesLike;
    receiver?: ccc.ScriptLike | null;
    tx?: ccc.TransactionLike | null;
  }) => Promise<{
    tx: ccc.Transaction;
    id: ccc.Hex;
    index: number;
  }>, transferTypeId: (this: void, props: {
    client: ccc.Client;
    id: ccc.HexLike;
    receiver: ccc.ScriptLike;
    tx?: ccc.TransactionLike | null;
    data?: ccc.BytesLike | ((cell: ccc.Cell, data?: ccc.Bytes | undefined) => ccc.BytesLike | Promise<ccc.BytesLike>) | null | undefined;
  }) => Promise<{
    tx: ccc.Transaction;
    inIndex: number;
    outIndex: number;
  }>, destroyTypeId: (this: void, props: {
    client: ccc.Client;
    id: ccc.HexLike;
    tx?: ccc.TransactionLike | null;
  }) => Promise<{
    tx: ccc.Transaction;
    index: number;
  }>;
//#endregion
export { createTypeId, destroyTypeId, barrel_d_exports as t, transferTypeId };
//# sourceMappingURL=barrel.d.ts.map