import { buildTypeIdOperations, t as advancedBarrel_d_exports } from "./advancedBarrel.js";
export { buildTypeIdOperations, advancedBarrel_d_exports as typeIdA };