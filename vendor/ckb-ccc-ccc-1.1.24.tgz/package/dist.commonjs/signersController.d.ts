import { ccc } from "@ckb-ccc/shell";
/**
 * @public
 */
export type WalletWithSigners = ccc.Wallet & {
    signers: ccc.SignerInfo[];
};
/**
 * @public
 */
export interface SignersControllerRefreshContext {
    client: ccc.Client;
    appName: string;
    appIcon: string;
    preferredNetworks: ccc.NetworkPreference[];
    onUpdate: (wallets: WalletWithSigners[]) => void;
    wallets: WalletWithSigners[];
}
/**
 * @public
 */
export declare class SignersController {
    private resetListeners;
    constructor();
    getConfig(configs?: {
        preferredNetworks?: ccc.NetworkPreference[];
        name?: string;
        icon?: string;
    }): {
        appName: string;
        appIcon: string;
        preferredNetworks: ccc.NetworkPreference[];
    };
    disconnect(): void;
    refresh(client: ccc.Client, onUpdate: (wallets: WalletWithSigners[]) => void, configs?: {
        preferredNetworks?: ccc.NetworkPreference[];
        name?: string;
        icon?: string;
    }): Promise<void>;
    addRealSigners(context: SignersControllerRefreshContext): Promise<void>;
    addDummySigners(context: SignersControllerRefreshContext): Promise<void>;
    addLinkSigners(walletName: string, icon: string, signerTypes: ccc.SignerType[], link: string, context: SignersControllerRefreshContext): Promise<void[]>;
    addSigners(walletName: string, icon: string, signers: ccc.SignerInfo[], context: SignersControllerRefreshContext): Promise<void[]>;
    protected addSigner(walletName: string, icon: string, signerInfo: ccc.SignerInfo, { wallets, onUpdate }: SignersControllerRefreshContext): Promise<void>;
}
//# sourceMappingURL=signersController.d.ts.map