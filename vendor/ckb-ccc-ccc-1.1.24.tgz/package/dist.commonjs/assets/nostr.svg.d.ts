export declare const NOSTR_SVG: string;
//# sourceMappingURL=nostr.svg.d.ts.map