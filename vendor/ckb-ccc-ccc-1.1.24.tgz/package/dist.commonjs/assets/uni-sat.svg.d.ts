export declare const UNI_SAT_SVG: string;
//# sourceMappingURL=uni-sat.svg.d.ts.map