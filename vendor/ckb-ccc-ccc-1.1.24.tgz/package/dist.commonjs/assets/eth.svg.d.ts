export declare const ETH_SVG: string;
//# sourceMappingURL=eth.svg.d.ts.map