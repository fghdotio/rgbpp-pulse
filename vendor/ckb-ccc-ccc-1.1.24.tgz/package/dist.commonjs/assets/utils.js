"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.encodeSvgToImgSrc = encodeSvgToImgSrc;
function encodeSvgToImgSrc(svg) {
    return `data:image/svg+xml,${encodeURIComponent(svg)}`;
}
