export declare const UTXO_GLOBAL_SVG: string;
//# sourceMappingURL=utxo-global.svg.d.ts.map