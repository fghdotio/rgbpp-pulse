export declare const JOY_ID_SVG: string;
//# sourceMappingURL=joy-id.svg.d.ts.map