export declare const OKX_SVG: string;
//# sourceMappingURL=okx.svg.d.ts.map