export declare function encodeSvgToImgSrc(svg: string): string;
//# sourceMappingURL=utils.d.ts.map