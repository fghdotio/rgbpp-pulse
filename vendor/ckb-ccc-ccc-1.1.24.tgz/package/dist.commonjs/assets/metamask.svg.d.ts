export declare const METAMASK_SVG: string;
//# sourceMappingURL=metamask.svg.d.ts.map