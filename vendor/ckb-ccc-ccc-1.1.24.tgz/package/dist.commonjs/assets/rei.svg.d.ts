export declare const REI_SVG: string;
//# sourceMappingURL=rei.svg.d.ts.map