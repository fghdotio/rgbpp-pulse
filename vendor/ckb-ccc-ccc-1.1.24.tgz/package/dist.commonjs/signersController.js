"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SignersController = void 0;
const eip6963_1 = require("@ckb-ccc/eip6963");
const joy_id_1 = require("@ckb-ccc/joy-id");
const nip07_1 = require("@ckb-ccc/nip07");
const okx_1 = require("@ckb-ccc/okx");
const rei_1 = require("@ckb-ccc/rei");
const shell_1 = require("@ckb-ccc/shell");
const uni_sat_1 = require("@ckb-ccc/uni-sat");
const utxo_global_1 = require("@ckb-ccc/utxo-global");
const xverse_1 = require("@ckb-ccc/xverse");
const eth_svg_js_1 = require("./assets/eth.svg.js");
const joy_id_svg_js_1 = require("./assets/joy-id.svg.js");
const metamask_svg_js_1 = require("./assets/metamask.svg.js");
const nostr_svg_js_1 = require("./assets/nostr.svg.js");
const okx_svg_js_1 = require("./assets/okx.svg.js");
const rei_svg_js_1 = require("./assets/rei.svg.js");
const uni_sat_svg_js_1 = require("./assets/uni-sat.svg.js");
const utxo_global_svg_js_1 = require("./assets/utxo-global.svg.js");
/**
 * @public
 */
class SignersController {
    constructor() {
        this.resetListeners = [];
    }
    getConfig(configs) {
        const appName = configs?.name ??
            // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
            document.querySelector("head title")?.text ??
            "Unknown";
        const appIcon = configs?.icon ??
            // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
            document.querySelector('link[rel="icon"]')
                ?.href ??
            "https://fav.farm/%E2%9D%93";
        const preferredNetworks = [
            ...(configs?.preferredNetworks ?? []),
            {
                addressPrefix: "ckb",
                signerType: shell_1.ccc.SignerType.BTC,
                network: "btc",
            },
            {
                addressPrefix: "ckt",
                signerType: shell_1.ccc.SignerType.BTC,
                network: "btcTestnet",
            },
            {
                addressPrefix: "ckb",
                signerType: shell_1.ccc.SignerType.Doge,
                network: "doge",
            },
            {
                addressPrefix: "ckt",
                signerType: shell_1.ccc.SignerType.Doge,
                network: "dogeTestnet",
            },
        ];
        return {
            appName,
            appIcon,
            preferredNetworks,
        };
    }
    disconnect() {
        this.resetListeners.forEach((listener) => listener());
        this.resetListeners = [];
    }
    async refresh(client, onUpdate, configs) {
        this.disconnect();
        const { appName, appIcon, preferredNetworks } = this.getConfig(configs);
        const context = {
            client,
            appName,
            appIcon,
            preferredNetworks,
            onUpdate,
            wallets: [],
        };
        await this.addRealSigners(context);
        await this.addDummySigners(context);
    }
    async addRealSigners(context) {
        const { appName, appIcon, client, preferredNetworks } = context;
        await this.addSigners("UTXO Global Wallet", utxo_global_svg_js_1.UTXO_GLOBAL_SVG, utxo_global_1.UtxoGlobal.getUtxoGlobalSigners(client, preferredNetworks), context);
        await this.addSigners("Rei Wallet", rei_svg_js_1.REI_SVG, rei_1.Rei.getReiSigners(client), context);
        await this.addSigners("JoyID Passkey", joy_id_svg_js_1.JOY_ID_SVG, joy_id_1.JoyId.getJoyIdSigners(client, appName, appIcon, preferredNetworks), context);
        await this.addSigners("UniSat", uni_sat_svg_js_1.UNI_SAT_SVG, uni_sat_1.UniSat.getUniSatSigners(client, preferredNetworks), context);
        await this.addSigners("OKX Wallet", okx_svg_js_1.OKX_SVG, okx_1.Okx.getOKXSigners(client, preferredNetworks), context);
        await Promise.all(xverse_1.Xverse.getXverseSigners(client, preferredNetworks).map(({ wallet, signerInfo }) => this.addSigner(wallet.name, wallet.icon, signerInfo, context)));
        const nostrSigner = nip07_1.Nip07.getNip07Signer(client);
        if (nostrSigner) {
            await this.addSigner("Nostr", nostr_svg_js_1.NOSTR_SVG, {
                name: "Nostr",
                signer: nostrSigner,
            }, context);
        }
        this.resetListeners.push(new eip6963_1.Eip6963.SignerFactory(client).subscribeSigners((signer, detail) => this.addSigner(detail?.info.name ?? "EVM", detail?.info.icon ?? eth_svg_js_1.ETH_SVG, {
            name: "EVM",
            signer,
        }, context)));
    }
    async addDummySigners(context) {
        await this.addLinkSigners("MetaMask", metamask_svg_js_1.METAMASK_SVG, [shell_1.ccc.SignerType.EVM], `https://metamask.app.link/dapp/${window.location.href}`, context);
        await this.addLinkSigners("OKX Wallet", okx_svg_js_1.OKX_SVG, [shell_1.ccc.SignerType.EVM, shell_1.ccc.SignerType.BTC], "https://www.okx.com/download?deeplink=" +
            encodeURIComponent("okx://wallet/dapp/url?dappUrl=" +
                encodeURIComponent(window.location.href)), context);
        await this.addLinkSigners("UniSat", uni_sat_svg_js_1.UNI_SAT_SVG, [shell_1.ccc.SignerType.BTC], "https://unisat.io/download", context);
        await this.addLinkSigners("UTXO Global Wallet", utxo_global_svg_js_1.UTXO_GLOBAL_SVG, [shell_1.ccc.SignerType.CKB, shell_1.ccc.SignerType.BTC], "https://chromewebstore.google.com/detail/lnamkkidoonpeknminiadpgjiofpdmle", context);
    }
    async addLinkSigners(walletName, icon, signerTypes, link, context) {
        return this.addSigners(walletName, icon, signerTypes.map((type) => ({
            name: type,
            signer: new shell_1.ccc.SignerOpenLink(context.client, type, link),
        })), context);
    }
    async addSigners(walletName, icon, signers, context) {
        return Promise.all(signers.map((signerInfo) => this.addSigner(walletName, icon, signerInfo, context)));
    }
    async addSigner(walletName, icon, signerInfo, { wallets, onUpdate }) {
        const wallet = wallets.find((w) => w.name === walletName);
        if (!wallet) {
            wallets.push({
                name: walletName,
                icon,
                signers: [signerInfo],
            });
        }
        else {
            const signers = [...wallet.signers, signerInfo].filter(({ signer }) => !(signer instanceof shell_1.ccc.SignerDummy));
            wallet.signers = signers.length !== 0 ? signers : [signerInfo];
        }
        onUpdate(wallets);
    }
}
exports.SignersController = SignersController;
