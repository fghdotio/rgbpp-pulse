import { ccc } from "@ckb-ccc/core";
/**
 * Retrieves the OKX Bitcoin signer if available.
 * @public
 *
 * @param client - The client instance.
 * @returns The BitcoinSigner instance if the OKX wallet is available, otherwise undefined.
 */
export declare function getOKXSigners(client: ccc.Client, preferredNetworks?: ccc.NetworkPreference[]): ccc.SignerInfo[];
//# sourceMappingURL=signersFactory.d.ts.map