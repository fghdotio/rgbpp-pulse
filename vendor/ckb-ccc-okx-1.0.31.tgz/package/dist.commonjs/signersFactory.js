"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getOKXSigners = getOKXSigners;
const index_js_1 = require("./btc/index.js");
const index_js_2 = require("./nostr/index.js");
/**
 * Retrieves the OKX Bitcoin signer if available.
 * @public
 *
 * @param client - The client instance.
 * @returns The BitcoinSigner instance if the OKX wallet is available, otherwise undefined.
 */
function getOKXSigners(client, preferredNetworks) {
    const windowRef = window;
    if (typeof windowRef.okxwallet === "undefined") {
        return [];
    }
    return [
        {
            signer: new index_js_1.BitcoinSigner(client, windowRef.okxwallet, preferredNetworks),
            name: "BTC",
        },
        {
            signer: new index_js_2.NostrSigner(client, windowRef.okxwallet.nostr),
            name: "Nostr",
        },
    ];
}
