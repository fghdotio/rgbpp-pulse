import { ccc } from "@ckb-ccc/core";
import { NostrProvider } from "../advancedBarrel.js";
/**
 * Class representing a Bitcoin signer that extends SignerBtc
 * @public
 */
export declare class NostrSigner extends ccc.SignerNostr {
    readonly provider: NostrProvider;
    private publicKeyCache?;
    constructor(client: ccc.Client, provider: NostrProvider);
    getNostrPublicKey(): Promise<ccc.Hex>;
    signNostrEvent(event: ccc.NostrEvent): Promise<Required<ccc.NostrEvent>>;
    connect(): Promise<void>;
    onReplaced(listener: () => void): () => void;
    isConnected(): Promise<boolean>;
}
//# sourceMappingURL=index.d.ts.map