"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NostrSigner = void 0;
const core_1 = require("@ckb-ccc/core");
/**
 * Class representing a Bitcoin signer that extends SignerBtc
 * @public
 */
class NostrSigner extends core_1.ccc.SignerNostr {
    constructor(client, provider) {
        super(client);
        this.provider = provider;
        this.publicKeyCache = undefined;
    }
    async getNostrPublicKey() {
        if (!this.publicKeyCache) {
            this.publicKeyCache = this.provider
                .getPublicKey()
                .then((v) => {
                // For some account types of OKX Wallet, this might returns null
                // e.g. Keyless accounts
                if (v) {
                    return v;
                }
                throw Error("This OKX Wallet account does not support Nostr");
            })
                .catch((e) => {
                this.publicKeyCache = undefined;
                throw e;
            });
        }
        return core_1.ccc.hexFrom(await this.publicKeyCache);
    }
    async signNostrEvent(event) {
        return this.provider.signEvent({
            ...event,
            pubkey: await this.publicKeyCache,
        });
    }
    async connect() {
        await this.provider.connect?.(); // Help extension to switch network
        await this.getNostrPublicKey();
    }
    onReplaced(listener) {
        const stop = [];
        const replacer = () => {
            listener();
            stop[0]?.();
        };
        stop.push(() => {
            this.provider.removeListener("accountChanged", replacer);
        });
        this.provider.on("accountChanged", replacer);
        return stop[0];
    }
    async isConnected() {
        return true;
    }
}
exports.NostrSigner = NostrSigner;
