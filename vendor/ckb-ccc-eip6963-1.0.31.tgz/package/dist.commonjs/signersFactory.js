"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SignerFactory = void 0;
const signer_js_1 = require("./signer.js");
/**
 * Class representing a factory for creating and managing Signer instances.
 * @public
 */
class SignerFactory {
    /**
     * Creates an instance of SignerFactory.
     * @param client - The client instance.
     */
    constructor(client) {
        this.client = client;
        this.existedUuids = [];
    }
    /**
     * Subscribes to new signers and triggers a callback when a new signer is available.
     * @param callback - The callback to trigger with the new signer.
     * @returns A function to unsubscribe from the signer events.
     */
    subscribeSigners(callback) {
        const onNewProvider = (event) => {
            const { detail } = event;
            const { uuid } = detail.info;
            if (this.existedUuids.includes(uuid)) {
                return;
            }
            this.existedUuids.push(uuid);
            const signer = new signer_js_1.Signer(this.client, detail.provider);
            callback(signer, detail);
        };
        window.addEventListener("eip6963:announceProvider", onNewProvider);
        window.dispatchEvent(new Event("eip6963:requestProvider"));
        const windowRef = window;
        if (typeof windowRef.ethereum !== "undefined") {
            callback(new signer_js_1.Signer(this.client, windowRef.ethereum));
        }
        return () => window.removeEventListener("eip6963:announceProvider", onNewProvider);
    }
}
exports.SignerFactory = SignerFactory;
