import { ccc } from "@ckb-ccc/core";
import { ProviderDetail } from "./eip6963.advanced.js";
import { Signer } from "./signer.js";
/**
 * Class representing a factory for creating and managing Signer instances.
 * @public
 */
export declare class SignerFactory {
    private readonly client;
    private readonly existedUuids;
    /**
     * Creates an instance of SignerFactory.
     * @param client - The client instance.
     */
    constructor(client: ccc.Client);
    /**
     * Subscribes to new signers and triggers a callback when a new signer is available.
     * @param callback - The callback to trigger with the new signer.
     * @returns A function to unsubscribe from the signer events.
     */
    subscribeSigners(callback: (newSigner: Signer, detail?: ProviderDetail) => unknown): () => void;
}
//# sourceMappingURL=signersFactory.d.ts.map