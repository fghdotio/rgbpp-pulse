import { ccc } from "@ckb-ccc/core";
import { Provider } from "./eip1193.advanced.js";
/**
 * Class representing an EVM signer that extends SignerEvm
 * @public
 */
export declare class Signer extends ccc.SignerEvm {
    readonly provider: Provider;
    private accountCache?;
    /**
     * Creates an instance of Signer.
     * @param client - The client instance.
     * @param provider - The provider.
     */
    constructor(client: ccc.Client, provider: Provider);
    /**
     * Gets the EVM account address.
     * @returns A promise that resolves to the EVM account address.
     */
    getEvmAccount(): Promise<ccc.Hex>;
    /**
     * Connects to the provider by requesting accounts.
     * @returns A promise that resolves when the connection is established.
     */
    connect(): Promise<void>;
    onReplaced(listener: () => void): () => void;
    /**
     * Checks if the provider is connected.
     * @returns A promise that resolves to true if connected, false otherwise.
     */
    isConnected(): Promise<boolean>;
    /**
     * Signs a raw message with the personal account.
     * @param message - The message to sign.
     * @returns A promise that resolves to the signed message.
     */
    signMessageRaw(message: string | ccc.BytesLike): Promise<ccc.Hex>;
}
//# sourceMappingURL=signer.d.ts.map