"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Signer = void 0;
const core_1 = require("@ckb-ccc/core");
/**
 * Class representing an EVM signer that extends SignerEvm
 * @public
 */
class Signer extends core_1.ccc.SignerEvm {
    /**
     * Creates an instance of Signer.
     * @param client - The client instance.
     * @param provider - The provider.
     */
    constructor(client, provider) {
        super(client);
        this.provider = provider;
        this.accountCache = undefined;
    }
    /**
     * Gets the EVM account address.
     * @returns A promise that resolves to the EVM account address.
     */
    async getEvmAccount() {
        this.accountCache = (await this.provider.request({ method: "eth_accounts" }))[0];
        return this.accountCache;
    }
    /**
     * Connects to the provider by requesting accounts.
     * @returns A promise that resolves when the connection is established.
     */
    async connect() {
        await this.provider.request({ method: "eth_requestAccounts" });
    }
    onReplaced(listener) {
        const stop = [];
        const replacer = async () => {
            listener();
            stop[0]?.();
        };
        stop.push(() => {
            this.provider.removeListener("accountsChanged", replacer);
            this.provider.removeListener("disconnect", replacer);
        });
        this.provider.on("accountsChanged", replacer);
        this.provider.on("disconnect", replacer);
        return stop[0];
    }
    /**
     * Checks if the provider is connected.
     * @returns A promise that resolves to true if connected, false otherwise.
     */
    async isConnected() {
        return ((await this.provider.request({ method: "eth_accounts" })).length !== 0);
    }
    /**
     * Signs a raw message with the personal account.
     * @param message - The message to sign.
     * @returns A promise that resolves to the signed message.
     */
    async signMessageRaw(message) {
        const challenge = typeof message === "string" ? core_1.ccc.bytesFrom(message, "utf8") : message;
        const account = this.accountCache ?? (await this.getEvmAccount());
        return this.provider.request({
            method: "personal_sign",
            params: [core_1.ccc.hexFrom(challenge), account],
        });
    }
}
exports.Signer = Signer;
