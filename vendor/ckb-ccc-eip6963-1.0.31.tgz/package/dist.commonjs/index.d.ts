export * as Eip6963 from "./barrel.js";
//# sourceMappingURL=index.d.ts.map