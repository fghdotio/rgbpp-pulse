import { ccc } from "@ckb-ccc/core";

//#region rolldown:runtime
//#endregion
//#region src/codec.d.ts
type DidCkbDataV1Like = {
  document: unknown;
  localId?: string | null;
};
declare const DidCkbDataV1_base: (abstract new () => {
  toBytes(): ccc.Bytes;
  clone(): DidCkbDataV1;
  eq(other: DidCkbDataV1Like): boolean;
  hash(): ccc.Hex;
  toHex(): ccc.Hex;
}) & {
  byteLength?: number;
  encode(_: DidCkbDataV1Like): ccc.Bytes;
  decode(_: ccc.BytesLike): DidCkbDataV1;
  fromBytes(_bytes: ccc.BytesLike): DidCkbDataV1;
  from(_: DidCkbDataV1Like): DidCkbDataV1;
};
declare class DidCkbDataV1 extends DidCkbDataV1_base {
  document: unknown;
  localId?: string | undefined;
  constructor(document: unknown, localId?: string | undefined);
  static from(data: DidCkbDataV1Like): DidCkbDataV1;
}
type DidCkbDataLike = {
  type?: "v1" | null;
  value: DidCkbDataV1Like;
};
declare const DidCkbData_base: (abstract new () => {
  toBytes(): ccc.Bytes;
  clone(): DidCkbData;
  eq(other: DidCkbDataLike): boolean;
  hash(): ccc.Hex;
  toHex(): ccc.Hex;
}) & {
  byteLength?: number;
  encode(_: DidCkbDataLike): ccc.Bytes;
  decode(_: ccc.BytesLike): DidCkbData;
  fromBytes(_bytes: ccc.BytesLike): DidCkbData;
  from(_: DidCkbDataLike): DidCkbData;
};
declare class DidCkbData extends DidCkbData_base {
  type: "v1";
  value: DidCkbDataV1;
  constructor(type: "v1", value: DidCkbDataV1);
  static from(data: DidCkbDataLike): DidCkbData;
  static fromV1(data: DidCkbDataV1Like): DidCkbData & {
    type: "v1";
    value: DidCkbDataV1;
  };
}
type PlcAuthorizationLike = {
  history: object[];
  sig: ccc.HexLike;
  rotationKeyIndices: ccc.NumLike[];
};
declare const PlcAuthorization_base: (abstract new () => {
  toBytes(): ccc.Bytes;
  clone(): PlcAuthorization;
  eq(other: PlcAuthorizationLike): boolean;
  hash(): ccc.Hex;
  toHex(): ccc.Hex;
}) & {
  byteLength?: number;
  encode(_: PlcAuthorizationLike): ccc.Bytes;
  decode(_: ccc.BytesLike): PlcAuthorization;
  fromBytes(_bytes: ccc.BytesLike): PlcAuthorization;
  from(_: PlcAuthorizationLike): PlcAuthorization;
};
declare class PlcAuthorization extends PlcAuthorization_base {
  history: object[];
  sig: ccc.Hex;
  rotationKeyIndices: ccc.Num[];
  constructor(history: object[], sig: ccc.Hex, rotationKeyIndices: ccc.Num[]);
  static from(data: PlcAuthorizationLike): PlcAuthorization;
}
type DidCkbWitnessLike = {
  localIdAuthorization: PlcAuthorizationLike;
};
declare const DidCkbWitness_base: (abstract new () => {
  toBytes(): ccc.Bytes;
  clone(): DidCkbWitness;
  eq(other: DidCkbWitnessLike): boolean;
  hash(): ccc.Hex;
  toHex(): ccc.Hex;
}) & {
  byteLength?: number;
  encode(_: DidCkbWitnessLike): ccc.Bytes;
  decode(_: ccc.BytesLike): DidCkbWitness;
  fromBytes(_bytes: ccc.BytesLike): DidCkbWitness;
  from(_: DidCkbWitnessLike): DidCkbWitness;
};
declare class DidCkbWitness extends DidCkbWitness_base {
  localIdAuthorization: PlcAuthorization;
  constructor(localIdAuthorization: PlcAuthorization);
  static from(data: DidCkbWitnessLike): DidCkbWitness;
}
//#endregion
//#region src/didCkb.d.ts
/**
 * Create a DID CKB cell.
 *
 * @param props The arguments for creating the cell.
 * @param props.signer The signer to sign the transaction.
 * @param props.receiver The receiver script (optional).
 * @param props.data The output data.
 * @param props.tx The transaction skeleton (optional).
 */
declare function createDidCkb(props: {
  signer: ccc.Signer;
  data: DidCkbDataLike;
  receiver?: ccc.ScriptLike | null;
  tx?: ccc.TransactionLike | null;
}): Promise<{
  tx: ccc.Transaction;
  id: ccc.Hex;
  index: number;
}>;
/**
 * Transfer a DID CKB cell.
 *
 * @param props The arguments for transferring the cell.
 * @param props.client The client to communicate with CKB.
 * @param props.id The Type ID to transfer.
 * @param props.receiver The new receiver script.
 * @param props.tx The transaction skeleton (optional).
 * @param props.data The new output data or a transformer to update the data (optional).
 */
declare function transferDidCkb(props: {
  client: ccc.Client;
  id: ccc.HexLike;
  receiver: ccc.ScriptLike;
  tx?: ccc.TransactionLike | null;
  data?: DidCkbDataLike | ((cell: ccc.Cell, data?: DidCkbData) => DidCkbDataLike | Promise<DidCkbDataLike>) | null;
}): Promise<{
  tx: ccc.Transaction;
  inIndex: number;
  outIndex: number;
}>;
/**
 * Destroy a DID CKB cell.
 *
 * @param props The arguments for destroying the cell.
 * @param props.client The client to communicate with CKB.
 * @param props.id The Type ID to destroy.
 * @param props.tx The transaction skeleton (optional).
 */
declare function destroyDidCkb(props: {
  client: ccc.Client;
  id: ccc.HexLike;
  tx?: ccc.TransactionLike | null;
}): Promise<{
  tx: ccc.Transaction;
  index: number;
}>;
declare namespace barrel_d_exports {
  export { DidCkbData, DidCkbDataLike, DidCkbDataV1, DidCkbDataV1Like, DidCkbWitness, DidCkbWitnessLike, PlcAuthorization, PlcAuthorizationLike, createDidCkb, destroyDidCkb, transferDidCkb };
}
//#endregion
export { DidCkbData as a, DidCkbDataV1Like as c, PlcAuthorization as d, PlcAuthorizationLike as f, transferDidCkb as i, DidCkbWitness as l, createDidCkb as n, DidCkbDataLike as o, destroyDidCkb as r, DidCkbDataV1 as s, barrel_d_exports as t, DidCkbWitnessLike as u };
//# sourceMappingURL=barrel-D_B8IbC0.d.ts.map