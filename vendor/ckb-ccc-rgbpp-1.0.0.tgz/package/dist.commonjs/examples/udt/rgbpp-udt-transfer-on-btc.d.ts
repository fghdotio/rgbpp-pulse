import "../env/load-env.js";
export interface RgbppBtcReceiver {
    address: string;
    amount: bigint;
}
//# sourceMappingURL=rgbpp-udt-transfer-on-btc.d.ts.map