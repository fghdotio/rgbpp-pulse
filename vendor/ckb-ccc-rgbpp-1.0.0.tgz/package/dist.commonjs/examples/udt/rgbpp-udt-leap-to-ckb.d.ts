import "../env/load-env.js";
//# sourceMappingURL=rgbpp-udt-leap-to-ckb.d.ts.map