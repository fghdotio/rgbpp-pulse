import { ccc } from "@ckb-ccc/core";
import { NetworkConfig, RgbppPrivateKeyBtcWallet } from "../../bitcoin/index.js";
import { CkbRgbppUnlockSigner } from "../../signer/index.js";
import { RgbppUdtClient } from "../../udt/index.js";
export declare function initializeRgbppEnv(): Promise<{
    ckbClient: ccc.Client;
    ckbSigner: ccc.SignerCkbPrivateKey;
    networkConfig: NetworkConfig;
    utxoBasedAccountAddress: string;
    rgbppUdtClient: RgbppUdtClient;
    rgbppBtcWallet: RgbppPrivateKeyBtcWallet;
    ckbRgbppUnlockSigner: CkbRgbppUnlockSigner;
}>;
//# sourceMappingURL=env.d.ts.map