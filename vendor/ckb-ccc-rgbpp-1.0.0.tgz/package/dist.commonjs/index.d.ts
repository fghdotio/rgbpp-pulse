export * from "./barrel.js";
export * as rgbpp from "./barrel.js";
//# sourceMappingURL=index.d.ts.map