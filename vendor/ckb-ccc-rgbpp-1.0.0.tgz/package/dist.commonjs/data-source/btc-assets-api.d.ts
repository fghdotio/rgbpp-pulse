import { ccc } from "@ckb-ccc/core";
import { BtcBalance, BtcBalanceParams, BtcRecommendedFeeRates, BtcTransaction, BtcUtxo, BtcUtxoParams, RgbppDataSource } from "./data-source.js";
export interface RgbppApiSpvProof {
    proof: string;
    spv_client: {
        tx_hash: string;
        index: string;
    };
}
export type Json = Record<string, any>;
export interface BaseApis {
    request<T>(route: string, options?: BaseApiRequestOptions): Promise<T>;
    post<T>(route: string, options?: BaseApiRequestOptions): Promise<T>;
}
export interface BaseApiRequestOptions extends RequestInit {
    params?: Json;
    method?: "GET" | "POST";
    requireToken?: boolean;
    allow404?: boolean;
}
export interface BtcAssetsApiToken {
    token: string;
}
export interface BtcAssetsApiContext {
    request: {
        url: string;
        body?: Json;
        params?: Json;
    };
    response: {
        status: number;
        data?: Json | string;
    };
}
export declare class BtcAssetsApiBase implements BaseApis {
    url: string;
    app?: string;
    domain?: string;
    origin?: string;
    private token?;
    private isMainnet;
    constructor(config: BtcAssetApiConfig);
    request<T>(route: string, options?: BaseApiRequestOptions): Promise<T>;
    post<T>(route: string, options?: BaseApiRequestOptions): Promise<T>;
}
export declare enum ErrorCodes {
    UNKNOWN = 0,
    ASSETS_API_RESPONSE_ERROR = 1,
    ASSETS_API_UNAUTHORIZED = 2,
    ASSETS_API_INVALID_PARAM = 3,
    ASSETS_API_RESOURCE_NOT_FOUND = 4,
    ASSETS_API_RESPONSE_DECODE_ERROR = 5,
    OFFLINE_DATA_SOURCE_METHOD_NOT_AVAILABLE = 6
}
export declare const ErrorMessages: {
    0: string;
    2: string;
    3: string;
    1: string;
    4: string;
    5: string;
    6: string;
};
export declare class BtcAssetsApiError extends Error {
    code: ErrorCodes;
    message: string;
    context?: BtcAssetsApiContext;
    constructor(payload: {
        code: ErrorCodes;
        message?: string;
        context?: BtcAssetsApiContext;
    });
    static withComment(code: ErrorCodes, comment?: string, context?: BtcAssetsApiContext): BtcAssetsApiError;
}
export interface BtcAssetApiConfig {
    url: string;
    app?: string;
    domain?: string;
    origin?: string;
    token?: string;
    isMainnet?: boolean;
}
/**
 * Typed API client for Bitcoin and RGBPP endpoints.
 *
 * Encapsulates all endpoint URLs and response types in one place.
 * Consumers use typed methods instead of raw `request<T>(url)` calls.
 */
export declare class BtcAssetsApi implements RgbppDataSource {
    private api;
    constructor(config: BtcAssetApiConfig);
    getTransaction(txId: string): Promise<BtcTransaction>;
    getTransactionHex(txId: string): Promise<string>;
    getUtxos(address: string, params?: BtcUtxoParams): Promise<BtcUtxo[]>;
    getBalance(address: string, params?: BtcBalanceParams): Promise<BtcBalance>;
    getRecommendedFee(): Promise<BtcRecommendedFeeRates>;
    sendTransaction(txHex: string): Promise<string>;
    getRgbppSpvProof(btcTxId: string, confirmations: number): Promise<{
        proof: ccc.Hex;
        spvClientOutpoint: ccc.OutPoint;
    } | null>;
    getRgbppCellOutputs(btcAddress: string): Promise<ccc.CellOutput[]>;
}
//# sourceMappingURL=btc-assets-api.d.ts.map