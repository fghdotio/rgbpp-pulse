import lodash from "lodash";
import { ccc } from "@ckb-ccc/core";
import { isDomain } from "../utils/index.js";
export class BtcAssetsApiBase {
    constructor(config) {
        this.url = config.url;
        this.app = config.app;
        this.domain = config.domain;
        this.origin = config.origin;
        this.token = config.token;
        this.isMainnet = config.isMainnet ?? true;
        // Validation
        if (this.domain && !isDomain(this.domain, true)) {
            throw BtcAssetsApiError.withComment(ErrorCodes.ASSETS_API_INVALID_PARAM, `Invalid domain format: "${this.domain}". Please provide a valid domain (e.g., "example.com")`);
        }
    }
    async request(route, options) {
        const { requireToken = this.isMainnet, allow404 = false, method = "GET", headers, params, ...otherOptions } = options ?? {};
        if (requireToken && (!this.token || !this.origin)) {
            throw BtcAssetsApiError.withComment(ErrorCodes.ASSETS_API_INVALID_PARAM, "Missing required parameters: both token and origin are required");
        }
        const pickedParams = lodash.pickBy(params, (val) => val !== undefined);
        const packedParams = params
            ? "?" + new URLSearchParams(pickedParams).toString()
            : "";
        const url = `${this.url}${route}${packedParams}`;
        const authHeaders = {};
        if (requireToken) {
            authHeaders.authorization = `Bearer ${this.token}`;
            authHeaders.origin = this.origin;
        }
        const res = await fetch(url, {
            method,
            headers: {
                ...authHeaders,
                ...(headers || {}),
            },
            ...otherOptions,
        });
        let text;
        let json;
        let ok = false;
        try {
            text = await res.text();
            if (text) {
                // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
                json = JSON.parse(text);
                // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
                ok = json?.ok ?? res.ok ?? false;
            }
            else {
                ok = res.ok;
            }
        }
        catch {
            // JSON.parse failed on non-empty text
            // We'll handle this decode error below
        }
        let comment;
        const status = res.status;
        const context = {
            request: {
                url,
                params,
                body: tryParseBody(otherOptions.body),
            },
            response: {
                status,
                data: json ?? text,
            },
        };
        if (!json) {
            comment = text ? `(${status}) ${text}` : `${status}`;
        }
        if (json && !ok) {
            // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
            const code = json.code ?? json.statusCode ?? json.error?.error?.code ?? res.status;
            // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
            const message = json.message ??
                (typeof json.error === "string"
                    ? json.error
                    : json.error?.error?.message);
            if (message) {
                // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
                comment = code ? `(${code}) ${message}` : message;
            }
            else {
                comment = JSON.stringify(json);
            }
        }
        if (status === 200) {
            if (text && !json) {
                // 200 OK, but we had body text that failed JSON parsing
                throw BtcAssetsApiError.withComment(ErrorCodes.ASSETS_API_RESPONSE_DECODE_ERROR, "Failed to decode JSON response", context);
            }
            if (!text) {
                return "";
            }
            return (json ?? text);
        }
        if (status === 401) {
            throw BtcAssetsApiError.withComment(ErrorCodes.ASSETS_API_UNAUTHORIZED, comment, context);
        }
        if (status === 404 && !allow404) {
            throw BtcAssetsApiError.withComment(ErrorCodes.ASSETS_API_RESOURCE_NOT_FOUND, comment, context);
        }
        if (status !== 200 && status !== 404 && !allow404) {
            throw BtcAssetsApiError.withComment(ErrorCodes.ASSETS_API_RESPONSE_ERROR, comment, context);
        }
        if (status === 404 && allow404) {
            return undefined;
        }
        return json;
    }
    async post(route, options) {
        return this.request(route, {
            method: "POST",
            ...options,
            headers: {
                "Content-Type": "application/json",
                ...options?.headers,
            },
        });
    }
}
function tryParseBody(body) {
    try {
        // eslint-disable-next-line @typescript-eslint/no-unsafe-return
        return typeof body === "string" ? JSON.parse(body) : undefined;
    }
    catch {
        return undefined;
    }
}
export var ErrorCodes;
(function (ErrorCodes) {
    ErrorCodes[ErrorCodes["UNKNOWN"] = 0] = "UNKNOWN";
    ErrorCodes[ErrorCodes["ASSETS_API_RESPONSE_ERROR"] = 1] = "ASSETS_API_RESPONSE_ERROR";
    ErrorCodes[ErrorCodes["ASSETS_API_UNAUTHORIZED"] = 2] = "ASSETS_API_UNAUTHORIZED";
    ErrorCodes[ErrorCodes["ASSETS_API_INVALID_PARAM"] = 3] = "ASSETS_API_INVALID_PARAM";
    ErrorCodes[ErrorCodes["ASSETS_API_RESOURCE_NOT_FOUND"] = 4] = "ASSETS_API_RESOURCE_NOT_FOUND";
    ErrorCodes[ErrorCodes["ASSETS_API_RESPONSE_DECODE_ERROR"] = 5] = "ASSETS_API_RESPONSE_DECODE_ERROR";
    ErrorCodes[ErrorCodes["OFFLINE_DATA_SOURCE_METHOD_NOT_AVAILABLE"] = 6] = "OFFLINE_DATA_SOURCE_METHOD_NOT_AVAILABLE";
})(ErrorCodes || (ErrorCodes = {}));
export const ErrorMessages = {
    [ErrorCodes.UNKNOWN]: "Unknown error",
    [ErrorCodes.ASSETS_API_UNAUTHORIZED]: "BtcAssetsAPI unauthorized, please check your token/origin",
    [ErrorCodes.ASSETS_API_INVALID_PARAM]: "Invalid param(s) was provided to the BtcAssetsAPI",
    [ErrorCodes.ASSETS_API_RESPONSE_ERROR]: "BtcAssetsAPI returned an error",
    [ErrorCodes.ASSETS_API_RESOURCE_NOT_FOUND]: "Resource not found on the BtcAssetsAPI",
    [ErrorCodes.ASSETS_API_RESPONSE_DECODE_ERROR]: "Failed to decode the response of BtcAssetsAPI",
    [ErrorCodes.OFFLINE_DATA_SOURCE_METHOD_NOT_AVAILABLE]: "Method not available for offline data source",
};
export class BtcAssetsApiError extends Error {
    constructor(payload) {
        const message = payload.message ??
            ErrorMessages[payload.code] ??
            ErrorMessages[ErrorCodes.UNKNOWN];
        super(message);
        this.code = ErrorCodes.UNKNOWN;
        this.message = message;
        this.code = payload.code;
        this.context = payload.context;
        Object.setPrototypeOf(this, BtcAssetsApiError.prototype);
    }
    static withComment(code, comment, context) {
        const prefixMessage = ErrorMessages[code] ?? ErrorMessages[ErrorCodes.UNKNOWN];
        const message = comment ? `${prefixMessage}: ${comment}` : undefined;
        return new BtcAssetsApiError({ code, message, context });
    }
}
/**
 * Typed API client for Bitcoin and RGBPP endpoints.
 *
 * Encapsulates all endpoint URLs and response types in one place.
 * Consumers use typed methods instead of raw `request<T>(url)` calls.
 */
export class BtcAssetsApi {
    constructor(config) {
        this.api = new BtcAssetsApiBase(config);
    }
    getTransaction(txId) {
        return this.api.request(`/bitcoin/v1/transaction/${txId}`);
    }
    async getTransactionHex(txId) {
        const { hex } = await this.api.request(`/bitcoin/v1/transaction/${txId}/hex`);
        return hex;
    }
    getUtxos(address, params) {
        return this.api.request(`/bitcoin/v1/address/${address}/unspent`, { params });
    }
    getBalance(address, params) {
        return this.api.request(`/bitcoin/v1/address/${address}/balance`, { params });
    }
    getRecommendedFee() {
        return this.api.request(`/bitcoin/v1/fees/recommended`);
    }
    async sendTransaction(txHex) {
        const { txid: txId } = await this.api.post("/bitcoin/v1/transaction", {
            body: JSON.stringify({ txhex: txHex }),
        });
        return txId;
    }
    async getRgbppSpvProof(btcTxId, confirmations) {
        const spvProof = await this.api.request("/rgbpp/v1/btc-spv/proof", {
            params: {
                btc_txid: btcTxId,
                confirmations,
            },
        });
        return spvProof
            ? {
                proof: spvProof.proof,
                spvClientOutpoint: ccc.OutPoint.from({
                    txHash: spvProof.spv_client.tx_hash,
                    index: spvProof.spv_client.index,
                }),
            }
            : null;
    }
    async getRgbppCellOutputs(btcAddress) {
        const res = await this.api.request(`/rgbpp/v1/address/${btcAddress}/assets`);
        return res.map((item) => item.cellOutput);
    }
}
