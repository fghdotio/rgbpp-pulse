import { ccc } from "@ckb-ccc/core";
export interface RgbppSpvProof {
    proof: ccc.Hex;
    spvClientOutpoint: ccc.OutPoint;
}
export interface RgbppSpvProofProvider {
    getRgbppSpvProof(btcTxId: string, confirmations: number): Promise<RgbppSpvProof | null>;
}
/** Default polling interval in milliseconds for SPV proof polling */
export declare const DEFAULT_SPV_POLL_INTERVAL = 30000;
/**
 * Poll for an SPV proof until it becomes available.
 *
 * @param provider - The SPV proof provider to query
 * @param btcTxId - The Bitcoin transaction ID to get the proof for
 * @param confirmations - The number of confirmations required
 * @param pollInterval - The polling interval in milliseconds
 * @returns The SPV proof once available
 */
export declare function pollForSpvProof(spvProofProvider: RgbppSpvProofProvider, btcTxId: string, confirmations?: number, intervalMs?: number): Promise<RgbppSpvProof>;
//# sourceMappingURL=spv.d.ts.map