/**
 * Public key provider that retrieves public keys from a wallet
 *
 * @public
 */
export class WalletPublicKeyProvider {
    constructor(wallet) {
        this.wallet = wallet;
    }
    async getPublicKey(address, _addressType) {
        // If it's the current wallet address, return its public key
        const currentAddress = await this.wallet.getAddress();
        if (address === currentAddress) {
            return await this.wallet.getPublicKey();
        }
        return undefined;
    }
}
/**
 * Public key provider that stores address-to-publickey mappings in memory
 *
 * @public
 */
export class CachedPublicKeyProvider {
    constructor() {
        this.cache = new Map();
    }
    /**
     * Add an address-to-publickey mapping to the cache
     *
     * @param address - Bitcoin address
     * @param publicKey - Public key in hex format
     */
    addMapping(address, publicKey) {
        this.cache.set(address, publicKey);
    }
    /**
     * Remove an address-to-publickey mapping from the cache
     *
     * @param address - Bitcoin address
     */
    removeMapping(address) {
        this.cache.delete(address);
    }
    /**
     * Clear all cached mappings
     */
    clear() {
        this.cache.clear();
    }
    async getPublicKey(address) {
        return this.cache.get(address);
    }
}
/**
 * Composite public key provider that tries multiple providers in sequence
 *
 * @public
 */
export class CompositePublicKeyProvider {
    constructor(providers) {
        this.providers = providers;
    }
    /**
     * Add a provider to the end of the provider chain
     *
     * @param provider - The provider to add
     */
    addProvider(provider) {
        this.providers.push(provider);
    }
    /**
     * Remove a provider from the provider chain
     *
     * @param provider - The provider to remove
     */
    removeProvider(provider) {
        const index = this.providers.indexOf(provider);
        if (index > -1) {
            this.providers.splice(index, 1);
        }
    }
    async getPublicKey(address, addressType) {
        // Try each provider in sequence until one returns a result
        for (const provider of this.providers) {
            const pubkey = await provider.getPublicKey(address, addressType);
            if (pubkey) {
                return pubkey;
            }
        }
        return undefined;
    }
}
export function toXOnly(pubKey) {
    return pubKey.length === 32 ? pubKey : pubKey.subarray(1, 33);
}
