import { AddressType } from "./address.js";
import { RgbppBtcWallet } from "./wallet.js";
/**
 * Public key provider interface
 * Used to lookup public keys for addresses when building P2TR PSBT inputs
 *
 * @public
 */
export interface PublicKeyProvider {
    /**
     * Get the public key for a given address
     *
     * @param address - Bitcoin address
     * @param addressType - Address type (e.g., P2TR, P2WPKH)
     * @returns Public key in hex format (33-byte compressed or 32-byte x-only format), or undefined if not found
     */
    getPublicKey(address: string, addressType: AddressType): Promise<string | undefined>;
}
/**
 * Public key provider that retrieves public keys from a wallet
 *
 * @public
 */
export declare class WalletPublicKeyProvider implements PublicKeyProvider {
    private wallet;
    constructor(wallet: RgbppBtcWallet);
    getPublicKey(address: string, _addressType: AddressType): Promise<string | undefined>;
}
/**
 * Public key provider that stores address-to-publickey mappings in memory
 *
 * @public
 */
export declare class CachedPublicKeyProvider implements PublicKeyProvider {
    private cache;
    /**
     * Add an address-to-publickey mapping to the cache
     *
     * @param address - Bitcoin address
     * @param publicKey - Public key in hex format
     */
    addMapping(address: string, publicKey: string): void;
    /**
     * Remove an address-to-publickey mapping from the cache
     *
     * @param address - Bitcoin address
     */
    removeMapping(address: string): void;
    /**
     * Clear all cached mappings
     */
    clear(): void;
    getPublicKey(address: string): Promise<string | undefined>;
}
/**
 * Composite public key provider that tries multiple providers in sequence
 *
 * @public
 */
export declare class CompositePublicKeyProvider implements PublicKeyProvider {
    private providers;
    constructor(providers: PublicKeyProvider[]);
    /**
     * Add a provider to the end of the provider chain
     *
     * @param provider - The provider to add
     */
    addProvider(provider: PublicKeyProvider): void;
    /**
     * Remove a provider from the provider chain
     *
     * @param provider - The provider to remove
     */
    removeProvider(provider: PublicKeyProvider): void;
    getPublicKey(address: string, addressType: AddressType): Promise<string | undefined>;
}
export declare function toXOnly(pubKey: Uint8Array): Uint8Array;
//# sourceMappingURL=public-key.d.ts.map