import { AddressType } from "../address.js";
import { PublicKeyProvider } from "../public-key.js";
import { TxInputData } from "./transaction.js";
interface OutPoint {
    txid: string;
    vout: number;
}
export type UtxoSeal = OutPoint;
/**
 * Deduplicate UTXO seals based on txid and vout
 */
export declare function deduplicateUtxoSeals(utxoSeals: UtxoSeal[]): UtxoSeal[];
export interface Output extends OutPoint {
    value: number;
    scriptPk: string;
}
export interface Utxo extends Output {
    addressType: AddressType;
    address: string;
    pubkey?: string;
}
/**
 * Convert UTXO to PSBT input data
 *
 * @param utxo - The UTXO to convert
 * @param publicKeyProvider - Optional provider to lookup public keys for P2TR addresses
 * @returns PSBT input data
 *
 * @throws Error if address type is unsupported or public key is missing for P2TR
 */
export declare function utxoToInputData(utxo: Utxo, publicKeyProvider?: PublicKeyProvider): Promise<TxInputData>;
export {};
//# sourceMappingURL=utxo.d.ts.map