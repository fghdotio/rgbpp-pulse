import { TxInputData, TxOutput } from "./transaction.js";
export declare const DEFAULT_VIRTUAL_SIZE_BUFFER = 20;
/**
 * Stateless fee estimator for Bitcoin transactions.
 * Estimates virtual size based on input/output address types
 * without requiring actual signing.
 */
export declare class BtcFeeEstimator {
    /**
     * Estimate virtual size of a transaction
     * Based on Bitcoin transaction structure and different address types
     */
    estimateVirtualSize(inputs: TxInputData[], outputs: TxOutput[]): number;
}
/**
 * Get the size of a variable integer encoding
 */
export declare function getVarIntSize(value: number): number;
/**
 * Determine address type from PSBT input data
 */
export declare function getInputAddressType(input: TxInputData): string;
//# sourceMappingURL=fee-estimator.d.ts.map