import * as bitcoin from "bitcoinjs-lib";
export declare const BTC_DEFAULT_DUST_LIMIT = 546;
export declare const BTC_DEFAULT_FEE_RATE = 1;
export declare const BTC_DEFAULT_CONFIRMATIONS = 6;
export interface TxInputData {
    hash: string;
    index: number;
    witnessUtxo: {
        value: number;
        script: Uint8Array;
    };
    tapInternalKey?: Uint8Array;
}
export type TxOutput = TxAddressOutput | TxScriptOutput;
export interface TxBaseOutput {
    value: number;
    fixed?: boolean;
    protected?: boolean;
    minUtxoSatoshi?: number;
}
export interface TxAddressOutput extends TxBaseOutput {
    address: string;
}
export interface TxScriptOutput extends TxBaseOutput {
    script: Uint8Array;
}
export type InitOutput = TxAddressOutput | TxDataOutput | TxScriptOutput;
export interface TxDataOutput extends TxBaseOutput {
    data: Uint8Array | string;
}
export declare function convertToOutput(output: InitOutput): TxOutput;
/**
 * Convert data to OP_RETURN script pubkey.
 * The data size should be ranged in 1 to 80 bytes.
 *
 * @example
 * const data = ccc.bytesFrom('01020304');
 * const scriptPk = dataToOpReturnScriptPubkey(data); // Uint8Array [0x6a, 0x04, 0x01, 0x02, 0x03, 0x04]
 * const scriptPkHex = ccc.bytesTo(scriptPk, 'hex'); // 6a0401020304
 */
export declare function dataToOpReturnScriptPubkey(data: Uint8Array | string): Uint8Array;
/**
 * Convert a bitcoin.Transaction to hex string.
 * Note if using for RGBPP proof, shouldn't set the "withWitness" param to "true".
 *
 * @param tx - The Bitcoin transaction object
 * @param withWitness - Whether to include witness data (default: false)
 * @returns Hex string of the transaction
 */
export declare function transactionToHex(tx: bitcoin.Transaction, withWitness?: boolean): string;
//# sourceMappingURL=transaction.d.ts.map