import { BtcDataProvider, BtcUtxoParams } from "../../data-source/index.js";
import { Logger, RetryOptions } from "../../utils/index.js";
import { NetworkConfig } from "../network.js";
import { PublicKeyProvider } from "../public-key.js";
import { TxInputData, TxOutput } from "./transaction.js";
import { UtxoSeal } from "./utxo.js";
export interface BtcTransactionBuilderOptions {
    concurrency?: number;
    retryOptions?: RetryOptions;
    logger?: Logger;
}
/**
 * Handles BTC transaction building: input construction, UTXO collection,
 * fee estimation, and input/output balancing.
 *
 * Stateless with respect to wallet identity — receives dependencies via constructor.
 */
export declare class BtcTransactionBuilder {
    private dataSource;
    private networkConfig;
    private publicKeyProvider;
    private getAddress;
    private feeEstimator;
    private options;
    constructor(dataSource: BtcDataProvider, networkConfig: NetworkConfig, publicKeyProvider: PublicKeyProvider, getAddress: () => Promise<string>, options?: BtcTransactionBuilderOptions);
    buildInputs(utxoSeals: UtxoSeal[]): Promise<TxInputData[]>;
    balanceInputsOutputs(inputs: TxInputData[], outputs: TxOutput[], btcUtxoParams?: BtcUtxoParams, feeRate?: number): Promise<{
        balancedInputs: TxInputData[];
        balancedOutputs: TxOutput[];
    }>;
    collectUtxos(requiredValue: number, params?: BtcUtxoParams, knownInputs?: TxInputData[]): Promise<{
        inputs: TxInputData[];
        changeValue: number;
    }>;
    /**
     * Estimate transaction fee without requiring actual signing.
     * This avoids triggering wallet confirmation dialogs for fee estimation.
     */
    estimateFee(inputs: TxInputData[], outputs: TxOutput[], feeRate?: number): Promise<number>;
}
//# sourceMappingURL=transaction-builder.d.ts.map