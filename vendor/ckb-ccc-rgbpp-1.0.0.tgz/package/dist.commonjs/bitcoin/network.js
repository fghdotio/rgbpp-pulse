import * as bitcoin from "bitcoinjs-lib";
import { BTC_DEFAULT_DUST_LIMIT, BTC_DEFAULT_FEE_RATE, } from "./transaction/index.js";
export var PredefinedNetwork;
(function (PredefinedNetwork) {
    PredefinedNetwork["BitcoinTestnet3"] = "BitcoinTestnet3";
    PredefinedNetwork["BitcoinMainnet"] = "BitcoinMainnet";
})(PredefinedNetwork || (PredefinedNetwork = {}));
export function toBtcNetwork(network) {
    return network === PredefinedNetwork.BitcoinMainnet
        ? bitcoin.networks.bitcoin
        : bitcoin.networks.testnet;
}
export function buildNetworkConfig(network, overrides) {
    let config;
    switch (network) {
        // eslint-disable-next-line @typescript-eslint/no-unsafe-enum-comparison
        case PredefinedNetwork.BitcoinTestnet3:
            config = {
                name: PredefinedNetwork.BitcoinTestnet3,
                isMainnet: false,
                btcDustLimit: overrides?.btcDustLimit || BTC_DEFAULT_DUST_LIMIT,
                btcFeeRate: overrides?.btcFeeRate || BTC_DEFAULT_FEE_RATE,
            };
            break;
        // eslint-disable-next-line @typescript-eslint/no-unsafe-enum-comparison
        case PredefinedNetwork.BitcoinMainnet:
            config = {
                name: PredefinedNetwork.BitcoinMainnet,
                isMainnet: true,
                btcDustLimit: overrides?.btcDustLimit || BTC_DEFAULT_DUST_LIMIT,
                btcFeeRate: overrides?.btcFeeRate || BTC_DEFAULT_FEE_RATE,
            };
            break;
        default:
            config = {
                name: network,
                isMainnet: false,
                btcDustLimit: overrides?.btcDustLimit || BTC_DEFAULT_DUST_LIMIT,
                btcFeeRate: overrides?.btcFeeRate || BTC_DEFAULT_FEE_RATE,
            };
            break;
    }
    return overrides ? mergeNetworkConfigs(config, overrides) : config;
}
function mergeNetworkConfigs(base, overrides) {
    return {
        name: base.name,
        isMainnet: base.isMainnet,
        btcDustLimit: overrides?.btcDustLimit || base.btcDustLimit,
        btcFeeRate: overrides?.btcFeeRate || base.btcFeeRate,
    };
}
export function isMainnet(network) {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-enum-comparison
    return network === PredefinedNetwork.BitcoinMainnet;
}
