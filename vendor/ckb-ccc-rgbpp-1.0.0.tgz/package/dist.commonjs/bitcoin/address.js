import * as bitcoin from "bitcoinjs-lib";
import { ccc } from "@ckb-ccc/core";
import { ErrorBtcInvalidAddress } from "../error.js";
import { toBtcNetwork } from "./network.js";
// Read more about the available address types:
// - P2WPKH: https://github.com/bitcoin/bips/blob/master/bip-0141.mediawiki#p2wpkh
// - P2TR: https://github.com/bitcoin/bips/blob/master/bip-0341.mediawiki
export var AddressType;
(function (AddressType) {
    AddressType["P2PKH"] = "P2PKH";
    AddressType["P2WPKH"] = "P2WPKH";
    AddressType["P2TR"] = "P2TR";
    AddressType["P2SH_P2WPKH"] = "P2SH_P2WPKH";
    AddressType["P2WSH"] = "P2WSH";
    AddressType["P2SH"] = "P2SH";
    AddressType["UNKNOWN"] = "UNKNOWN";
})(AddressType || (AddressType = {}));
export const SUPPORTED_ADDRESS_TYPES = [
    AddressType.P2WPKH,
    AddressType.P2TR,
];
export function isSupportedAddressType(at) {
    return SUPPORTED_ADDRESS_TYPES.includes(at);
}
export function addressToScriptPublicKeyHex(address, networkType) {
    const network = toBtcNetwork(networkType);
    const script = bitcoin.address.toOutputScript(address, network);
    if (!script) {
        throw new Error("Invalid address!");
    }
    return ccc.bytesTo(script, "hex");
}
export function decodeAddress(address) {
    const mainnet = bitcoin.networks.bitcoin;
    const testnet = bitcoin.networks.testnet;
    const regtest = bitcoin.networks.regtest;
    let decodeBase58;
    let decodeBech32;
    let network;
    let addressType;
    if (address.startsWith("bc1") ||
        address.startsWith("tb1") ||
        address.startsWith("bcrt1")) {
        try {
            decodeBech32 = bitcoin.address.fromBech32(address);
            if (decodeBech32.prefix === mainnet.bech32) {
                network = mainnet;
            }
            else if (decodeBech32.prefix === testnet.bech32) {
                network = testnet;
            }
            else if (decodeBech32.prefix === regtest.bech32) {
                network = regtest;
            }
            if (decodeBech32.version === 0) {
                if (decodeBech32.data.length === 20) {
                    addressType = AddressType.P2WPKH;
                }
                else if (decodeBech32.data.length === 32) {
                    addressType = AddressType.P2WSH;
                }
            }
            else if (decodeBech32.version === 1) {
                if (decodeBech32.data.length === 32) {
                    addressType = AddressType.P2TR;
                }
            }
            if (network !== undefined && addressType !== undefined) {
                return {
                    network,
                    addressType,
                };
            }
        }
        catch (_e) {
            // Do nothing (no need to throw here)
        }
    }
    else {
        try {
            decodeBase58 = bitcoin.address.fromBase58Check(address);
            if (decodeBase58.version === mainnet.pubKeyHash) {
                network = mainnet;
                addressType = AddressType.P2PKH;
            }
            else if (decodeBase58.version === testnet.pubKeyHash) {
                network = testnet;
                addressType = AddressType.P2PKH;
            }
            else if (decodeBase58.version === mainnet.scriptHash) {
                network = mainnet;
                addressType = AddressType.P2SH_P2WPKH;
            }
            else if (decodeBase58.version === testnet.scriptHash) {
                network = testnet;
                addressType = AddressType.P2SH_P2WPKH;
            }
            if (network !== undefined && addressType !== undefined) {
                return {
                    network,
                    addressType,
                };
            }
        }
        catch (_e) {
            // Do nothing (no need to throw here)
        }
    }
    throw new ErrorBtcInvalidAddress(address);
}
export function getAddressType(address) {
    return decodeAddress(address).addressType;
}
export function parseAddressType(addressType) {
    if (typeof addressType === "string") {
        const type = AddressType[addressType];
        if (!type) {
            throw new Error(`Invalid address type: ${addressType}`);
        }
        return type;
    }
    return addressType;
}
