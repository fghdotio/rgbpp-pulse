import * as bitcoin from "bitcoinjs-lib";
export declare enum PredefinedNetwork {
    BitcoinTestnet3 = "BitcoinTestnet3",
    BitcoinMainnet = "BitcoinMainnet"
}
export interface NetworkConfig {
    name: string;
    isMainnet: boolean;
    btcDustLimit: number;
    btcFeeRate: number;
}
export interface NetworkConfigOverrides {
    btcDustLimit?: number;
    btcFeeRate?: number;
}
export type Network = PredefinedNetwork | string;
export declare function toBtcNetwork(network: string): bitcoin.Network;
export declare function buildNetworkConfig(network: Network, overrides?: NetworkConfigOverrides): NetworkConfig;
export declare function isMainnet(network: Network): boolean;
//# sourceMappingURL=network.d.ts.map