import * as bitcoin from "bitcoinjs-lib";
export declare enum AddressType {
    P2PKH = "P2PKH",
    P2WPKH = "P2WPKH",
    P2TR = "P2TR",
    P2SH_P2WPKH = "P2SH_P2WPKH",
    P2WSH = "P2WSH",
    P2SH = "P2SH",
    UNKNOWN = "UNKNOWN"
}
export declare const SUPPORTED_ADDRESS_TYPES: readonly [AddressType.P2WPKH, AddressType.P2TR];
export declare function isSupportedAddressType(at: AddressType): boolean;
export declare function addressToScriptPublicKeyHex(address: string, networkType: string): string;
export declare function decodeAddress(address: string): {
    network: bitcoin.Network;
    addressType: AddressType;
};
export declare function getAddressType(address: string): AddressType;
export declare function parseAddressType(addressType: AddressType | string): AddressType;
//# sourceMappingURL=address.d.ts.map