import * as bitcoin from "bitcoinjs-lib";
import { ccc } from "@ckb-ccc/core";
import { Logger, RetryOptions } from "../utils/index.js";
import { BtcTransactionBuilder, BtcTransactionBuilderOptions } from "./transaction/index.js";
import { BtcDataProvider, BtcTransaction, BtcUtxoParams } from "../data-source/index.js";
import { RgbppUdtClient } from "../udt/index.js";
import { AddressType } from "./address.js";
import { NetworkConfig } from "./network.js";
import { PublicKeyProvider } from "./public-key.js";
/** Default polling interval in milliseconds for waiting transaction confirmation */
export declare const BTC_DEFAULT_CONFIRMATION_POLL_INTERVAL = 30000;
/** Options for waiting for a BTC transaction to be confirmed */
export interface WaitForConfirmationOptions {
    /** Polling interval in milliseconds (default: 30000, minimum: 5000) */
    pollInterval?: number;
    /** Maximum time to wait in milliseconds (default: unlimited) */
    timeout?: number;
    /** AbortSignal to cancel the wait */
    signal?: AbortSignal;
    /** Retry options for initial transaction indexing (default: maxRetries=10, initialDelay=5) */
    retryOptions?: RetryOptions;
}
/** Parameters for building a seal UTXO PSBT */
export interface UtxoSealParams {
    /** Target UTXO value in satoshis (default: btcDustLimit) */
    targetValue?: number;
    /** Fee rate for the transaction */
    feeRate?: number;
    /** UTXO selection parameters */
    btcUtxoParams?: BtcUtxoParams;
}
/** Result of building a seal UTXO PSBT */
export interface UtxoSealPsbt {
    /** The constructed PSBT, ready to be signed */
    psbt: bitcoin.Psbt;
    /** The output index of the seal UTXO in the transaction */
    sealOutputIndex: number;
}
export interface RgbppBtcTxParams {
    ckbPartialTx: ccc.Transaction;
    ckbClient: ccc.Client;
    rgbppUdtClient: RgbppUdtClient;
    receiverBtcAddresses: string[];
    btcChangeAddress: string;
    btcUtxoParams?: BtcUtxoParams;
    feeRate?: number;
}
export interface RgbppBtcWalletOptions {
    btcTxBuilderOptions?: BtcTransactionBuilderOptions;
    logger?: Logger;
}
export declare abstract class RgbppBtcWallet {
    protected networkConfig: NetworkConfig;
    protected dataSource: BtcDataProvider;
    protected options?: RgbppBtcWalletOptions | undefined;
    protected publicKeyProvider: PublicKeyProvider;
    protected txBuilder: BtcTransactionBuilder;
    private cachedPubKeyProvider;
    constructor(networkConfig: NetworkConfig, dataSource: BtcDataProvider, options?: RgbppBtcWalletOptions | undefined);
    get btcDataSource(): BtcDataProvider;
    /**
     * Get the current wallet address
     */
    abstract getAddress(): Promise<string>;
    /**
     * Get the public key for the current wallet address
     * @returns Public key in hex format (33-byte compressed format)
     */
    abstract getPublicKey(): Promise<string>;
    /**
     * Register a public key for a specific address
     * This is useful when you need to spend UTXOs from addresses other than the current wallet
     *
     * @param address - Bitcoin address
     * @param publicKey - Public key in hex format (33-byte compressed or 32-byte x-only format)
     *
     * @example
     * ```typescript
     * // Register a public key for a service address
     * wallet.registerPublicKey(
     *   "bc1p_service_address_xxx",
     *   "02abc123..." // 33-byte compressed public key
     * );
     * ```
     */
    registerPublicKey(address: string, publicKey: string): void;
    /**
     * Set a custom public key provider
     * This will replace the default composite provider
     *
     * @param provider - The public key provider to use
     */
    setPublicKeyProvider(provider: PublicKeyProvider): void;
    private buildBtcRgbppOutputs;
    /**
     * Assemble a PSBT from balanced inputs and outputs.
     * Shared helper used by buildPsbt and buildSealPsbt.
     */
    private assemblePsbt;
    buildPsbt(params: RgbppBtcTxParams): Promise<{
        psbt: bitcoin.Psbt;
        indexedCkbPartialTx: ccc.Transaction;
    }>;
    abstract signAndBroadcast(psbt: bitcoin.Psbt): Promise<string>;
    rawTxHex(tx: bitcoin.Transaction, withWitness?: boolean): string;
    isCommitmentMatched(commitment: string, ckbPartialTx: ccc.Transaction, lastCkbTypedOutputIndex: number): boolean;
    /**
     * Build a PSBT that creates a dust UTXO for use as an RGB++ seal.
     *
     * This only constructs the PSBT without signing or broadcasting.
     * Use this when you need custom signing flows.
     *
     * @returns The PSBT and the output index of the seal UTXO.
     */
    buildSealPsbt(options?: UtxoSealParams): Promise<UtxoSealPsbt>;
    /**
     * Wait for a BTC transaction to be confirmed.
     *
     * Supports bounded polling with optional timeout and AbortSignal cancellation.
     *
     * @param txId - The transaction ID to wait for.
     * @param options - Polling, timeout, and cancellation options.
     * @returns The confirmed BTC transaction.
     *
     * @throws Error if timeout is reached or signal is aborted.
     */
    waitForConfirmation(txId: string, options?: WaitForConfirmationOptions): Promise<BtcTransaction>;
}
export declare class RgbppPrivateKeyBtcWallet extends RgbppBtcWallet {
    private account;
    constructor(privateKey: string, addressType: AddressType, networkConfig: NetworkConfig, dataSource: BtcDataProvider, options?: RgbppBtcWalletOptions);
    getAddress(): Promise<string>;
    getPublicKey(): Promise<string>;
    /**
     * Format SignPsbtOptions to actual inputs that need to be signed
     * @private
     */
    private formatOptionsToSignInputs;
    signPsbt(psbt: bitcoin.Psbt, options?: ccc.SignPsbtOptionsLike): Promise<bitcoin.Transaction>;
    sendTx(tx: bitcoin.Transaction): Promise<string>;
    signAndBroadcast(psbt: bitcoin.Psbt, options?: ccc.SignPsbtOptionsLike): Promise<string>;
}
export declare class RgbppBrowserBtcWallet extends RgbppBtcWallet {
    protected signer: ccc.SignerBtc;
    constructor(signer: ccc.SignerBtc, networkConfig: NetworkConfig, dataSource: BtcDataProvider, options?: RgbppBtcWalletOptions);
    getAddress(): Promise<string>;
    getPublicKey(): Promise<string>;
    signAndBroadcast(psbt: bitcoin.Psbt, options?: ccc.SignPsbtOptionsLike): Promise<string>;
}
/**
 * Create a RgbppBrowserBtcWallet from a SignerBtc.
 *
 * TODO: Wallet capability validation (e.g. whether the signer fully implements
 * signAndBroadcastPsbt) should be enforced at the ccc.SignerBtc.
 */
export declare function createRgbppBrowserBtcWallet(signer: ccc.SignerBtc, networkConfig: NetworkConfig, dataSource: BtcDataProvider): RgbppBrowserBtcWallet;
export declare const RGBPP_CKB_MAX_CELL = 255;
export declare const calculateCommitment: (ckbPartialTx: ccc.Transaction) => string;
//# sourceMappingURL=wallet.d.ts.map