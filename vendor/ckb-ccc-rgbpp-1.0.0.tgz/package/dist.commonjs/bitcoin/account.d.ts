import * as bitcoin from "bitcoinjs-lib";
import { AddressType } from "./address.js";
export interface BtcAccount {
    from: string;
    fromPubkey?: string;
    keyPair: bitcoin.Signer;
    payment: bitcoin.Payment;
    addressType: AddressType;
    networkType: string;
}
export declare function createBtcAccount(privateKey: string, addressType: AddressType, networkType: string): BtcAccount;
interface TweakableSigner extends bitcoin.Signer {
    privateKey?: Uint8Array;
}
export declare function tweakSigner<T extends TweakableSigner>(signer: T, options?: {
    network?: bitcoin.Network;
    tweakHash?: Uint8Array;
}): bitcoin.Signer;
export {};
//# sourceMappingURL=account.d.ts.map