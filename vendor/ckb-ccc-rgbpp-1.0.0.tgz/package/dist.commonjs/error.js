// =============================================================================
// Bitcoin errors
// =============================================================================
export class ErrorBtcUnsupportedAddressType extends Error {
    constructor(addressType, supported) {
        super(`Unsupported address type: ${addressType}, only ${supported.join(", ")} supported`);
        this.addressType = addressType;
        this.supported = supported;
    }
}
export class ErrorBtcInvalidAddress extends Error {
    constructor(address) {
        super(`Unable to decode address: "${address}". Unrecognized format.`);
        this.address = address;
    }
}
export class ErrorBtcInsufficientFunds extends Error {
    constructor(required, available) {
        super(`Insufficient BTC funds: needed ${required} sats, but only ${available} available`);
        this.required = required;
        this.available = available;
    }
}
export class ErrorBtcTransactionNotFound extends Error {
    constructor(txid) {
        super(`Transaction ${txid} not found. The referenced UTXO may not exist or the API may be unavailable.`);
        this.txid = txid;
    }
}
export class ErrorBtcUtxoNotFound extends Error {
    constructor(txid, vout, txVoutCount) {
        super(`Output index ${vout} not found in transaction ${txid} (tx has ${txVoutCount} outputs).`);
        this.txid = txid;
        this.vout = vout;
        this.txVoutCount = txVoutCount;
    }
}
export class ErrorBtcOpReturnUtxo extends Error {
    constructor(txid, vout) {
        super(`Output ${vout} of transaction ${txid} is an OP_RETURN output and cannot be spent. ` +
            `RGB++ lock args should not reference OP_RETURN outputs.`);
        this.txid = txid;
        this.vout = vout;
    }
}
export class ErrorBtcMissingPublicKey extends Error {
    constructor(address) {
        super(`Missing public key for P2TR address ${address}. ` +
            `Provide a PublicKeyProvider or include pubkey in UTXO data.`);
        this.address = address;
    }
}
// =============================================================================
// RGB++ script errors
// =============================================================================
export class ErrorRgbppInvalidLockArgs extends Error {
    constructor(argsLength, minLength) {
        super(`Invalid RGB++ lock args: got ${argsLength} bytes, need at least ${minLength}`);
        this.argsLength = argsLength;
        this.minLength = minLength;
    }
}
export class ErrorRgbppScriptNotFound extends Error {
    constructor(scriptName) {
        super(`Required RGB++ script not found: ${scriptName}`);
        this.scriptName = scriptName;
    }
}
export class ErrorRgbppInvalidCellLock extends Error {
    constructor(expected, actual) {
        super(`Invalid cell lock: expected one of [${expected.join(", ")}], got ${actual}`);
        this.expected = expected;
        this.actual = actual;
    }
}
// =============================================================================
// RGB++ signer errors
// =============================================================================
export class ErrorRgbppOutputNotFound extends Error {
    constructor() {
        super("No output with RGB++ lock or BTC time lock found in transaction");
    }
}
export class ErrorRgbppInvalidInputLock extends Error {
    constructor(codeHash) {
        super(`All inputs must use RGB++ lock, but found input with lock codeHash: ${codeHash}`);
        this.codeHash = codeHash;
    }
}
export class ErrorRgbppMaxCellExceeded extends Error {
    constructor(count, max) {
        super(`RGB++ CKB virtual tx exceeds cell limit: ${count} cells, max ${max}`);
        this.count = count;
        this.max = max;
    }
}
export class ErrorRgbppNoTypedOutput extends Error {
    constructor() {
        super("RGB++ transaction has no CKB outputs with a type script. At least one typed output is required.");
    }
}
export class ErrorRgbppCellNotFound extends Error {
    constructor(txHash) {
        super(`RGB++ cell not found after issuance in transaction ${txHash}`);
        this.txHash = txHash;
    }
}
