/**
 * Retry utility with exponential backoff and jitter
 */
export interface RetryOptions {
    /** Maximum number of retry attempts (default: 10) */
    maxRetries?: number;
    /** Initial delay in seconds (default: 5) */
    initialDelay?: number;
    /** Backoff multiplier (default: 1.5) */
    backoffMultiplier?: number;
    /** Jitter factor as percentage (default: 0.1 for ±10%) */
    jitterFactor?: number;
    /** Enable verbose logging (default: false) */
    verbose?: boolean;
    /** Custom logger function (default: console.log) */
    logger?: (message: string) => void;
}
export declare function retryWithBackoff<T>(operation: () => Promise<T>, options?: RetryOptions): Promise<T>;
//# sourceMappingURL=retry.d.ts.map