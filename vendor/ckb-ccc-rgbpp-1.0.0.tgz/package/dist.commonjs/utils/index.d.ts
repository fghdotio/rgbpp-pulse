export declare function removeHexPrefix(hex: string): string;
/**
 * Check if target string is a valid domain.
 * @exmaple
 * isDomain('google.com') // => true
 * isDomain('https://google.com') // => false
 * isDomain('localhost') // => false
 * isDomain('localhost', true) // => true
 */
export declare function isDomain(domain: string, allowLocalhost?: boolean): boolean;
export * from "./concurrency.js";
export * from "./logger.js";
export * from "./retry.js";
//# sourceMappingURL=index.d.ts.map