/**
 * Iterate through an array and run an async function on each item with concurrency control.
 *
 * @param items - The items to iterate through
 * @param concurrency - The maximum number of concurrent executions
 * @param fn - The async function to run on each item
 * @returns An array of results in the same order as the inputs
 */
export declare function mapWithConcurrency<T, R>(items: T[], concurrency: number, fn: (item: T) => Promise<R>): Promise<R[]>;
//# sourceMappingURL=concurrency.d.ts.map