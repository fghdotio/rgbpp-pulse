export function removeHexPrefix(hex) {
    return hex.startsWith("0x") ? hex.slice(2) : hex;
}
// Domain validation utility
/**
 * Check if target string is a valid domain.
 * @exmaple
 * isDomain('google.com') // => true
 * isDomain('https://google.com') // => false
 * isDomain('localhost') // => false
 * isDomain('localhost', true) // => true
 */
export function isDomain(domain, allowLocalhost) {
    if (allowLocalhost && domain === "localhost") {
        return true;
    }
    const regex = /^(?:[-A-Za-z0-9]+\.)+[A-Za-z]{2,}$/;
    return regex.test(domain);
}
export * from "./concurrency.js";
export * from "./logger.js";
export * from "./retry.js";
