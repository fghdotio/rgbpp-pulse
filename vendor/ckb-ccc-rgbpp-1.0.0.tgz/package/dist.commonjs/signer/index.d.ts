import { ccc, SignerSignType, SignerType, Transaction, TransactionLike } from "@ckb-ccc/core";
import { RgbppSpvProof } from "../data-source/index.js";
import { RgbppScriptName } from "../script/index.js";
import { RgbppDataSource } from "../data-source/index.js";
export interface CkbRgbppUnlockSignerParams {
    ckbClient: ccc.Client;
    rgbppBtcAddress: string;
    rgbppDataSource: RgbppDataSource;
    scriptInfos: Record<RgbppScriptName, ccc.ScriptInfo>;
    /** Polling interval in milliseconds for SPV proof polling (default: 30000, minimum: 5000) */
    spvPollIntervalMs?: number;
    /** SPV proof cache expiry time in milliseconds (default: 600000 = 10 minutes) */
    cacheExpiryMs?: number;
}
export declare class CkbRgbppUnlockSigner extends ccc.Signer {
    private readonly scriptMap;
    private readonly rgbppScriptInfos;
    private spvProofCache;
    private readonly cacheExpiryTime;
    private readonly spvPollIntervalMs;
    private readonly rgbppBtcAddress;
    private readonly rgbppDataSource;
    constructor({ ckbClient, rgbppBtcAddress, rgbppDataSource, scriptInfos, spvPollIntervalMs, cacheExpiryMs, }: CkbRgbppUnlockSignerParams);
    get type(): SignerType;
    get signType(): SignerSignType;
    getScriptName(script?: ccc.Script): ccc.KnownScript | undefined;
    collectCellDeps(tx: Transaction): Promise<ccc.CellDep[]>;
    private collectClusterCellDeps;
    prepareTransaction(txLike: TransactionLike): Promise<Transaction>;
    signOnlyTransaction(txLike: TransactionLike): Promise<Transaction>;
    private getRgbppSpvProof;
    private getRawBtcTxHex;
    parseBtcTxIdFromScriptArgs(tx: ccc.Transaction): string;
    insertWitnesses(partialTx: ccc.Transaction, btcLikeTxBytes: string, spvClient: RgbppSpvProof): Promise<ccc.Transaction>;
    handleSporeWitness(tx: ccc.Transaction): Promise<void>;
    connect(): Promise<void>;
    isConnected(): Promise<boolean>;
    getInternalAddress(): Promise<string>;
    getAddressObjs(): Promise<ccc.Address[]>;
    getAddressObj(): Promise<ccc.Address>;
}
//# sourceMappingURL=index.d.ts.map