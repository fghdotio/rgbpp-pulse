import { ccc } from "@ckb-ccc/core";
import { ErrorRgbppCellNotFound, ErrorRgbppInvalidCellLock } from "../error.js";
import { isUsingOneOfScripts, RGBPP_BTC_TX_ID_PLACEHOLDER, ScriptManager, updateScriptArgsWithTxId, } from "../script/index.js";
export class RgbppUdtClient {
    constructor(ckbClient, scriptProvider) {
        this.ckbClient = ckbClient;
        // * It's assumed that all the tx.outputs are rgbpp/btc time lock scripts.
        this.injectTxIdToRgbppCkbTx = async (tx, txId) => {
            const rgbppLockTemplate = await this.rgbppLockScriptTemplate();
            const btcTimeLockTemplate = await this.btcTimeLockScriptTemplate();
            const outputs = tx.outputs.map((output, _index) => {
                if (!isUsingOneOfScripts(output.lock, [
                    rgbppLockTemplate,
                    btcTimeLockTemplate,
                ])) {
                    throw new ErrorRgbppInvalidCellLock(["RgbppLock", "BtcTimeLock"], output.lock.codeHash);
                }
                return ccc.CellOutput.from({
                    ...output,
                    lock: {
                        ...output.lock,
                        args: updateScriptArgsWithTxId(output.lock.args, txId),
                    },
                });
            });
            return ccc.Transaction.from({
                ...tx,
                outputs,
            });
        };
        this.scriptManager = new ScriptManager(scriptProvider);
    }
    async rgbppLockScriptTemplate() {
        return this.scriptManager.rgbppLockScriptTemplate();
    }
    async btcTimeLockScriptTemplate() {
        return this.scriptManager.btcTimeLockScriptTemplate();
    }
    async buildRgbppLockScript(utxoSeal) {
        return this.scriptManager.buildRgbppLockScript(utxoSeal);
    }
    async buildPseudoRgbppLockScript() {
        return this.scriptManager.buildPseudoRgbppLockScript();
    }
    async buildBtcTimeLockScript(ckbAddress, confirmations) {
        const receiverLock = (await ccc.Address.fromString(ckbAddress, this.ckbClient)).script;
        return this.scriptManager.buildBtcTimeLockScript(receiverLock, RGBPP_BTC_TX_ID_PLACEHOLDER, confirmations);
    }
    async getRgbppScriptInfos() {
        return this.scriptManager.getRgbppScriptInfos();
    }
    async createRgbppUdtIssuanceCells(signer, utxoSeal) {
        const rgbppLockScript = await this.buildRgbppLockScript(utxoSeal);
        const rgbppCellsGen = signer.client.findCellsByLock(rgbppLockScript);
        const rgbppCells = [];
        for await (const cell of rgbppCellsGen) {
            rgbppCells.push(cell);
        }
        if (rgbppCells.length !== 0) {
            return rgbppCells;
        }
        const tx = ccc.Transaction.default();
        // If additional capacity is required when used as an input in a transaction, it can always be supplemented in `completeInputsByCapacity`.
        tx.addOutput({
            lock: rgbppLockScript,
        });
        await tx.completeInputsByCapacity(signer);
        await tx.completeFeeBy(signer);
        const txHash = await signer.sendTransaction(tx);
        await signer.client.waitTransaction(txHash);
        const cell = await signer.client.getCellLive({
            txHash,
            index: 0,
        });
        if (!cell) {
            throw new ErrorRgbppCellNotFound(txHash);
        }
        return [cell];
    }
}
