import { ccc } from "@ckb-ccc/core";
import { UtxoSeal } from "../bitcoin/transaction/index.js";
import { IScriptProvider, RgbppScriptName, ScriptManager } from "../script/index.js";
export declare class RgbppUdtClient {
    private ckbClient;
    scriptManager: ScriptManager;
    constructor(ckbClient: ccc.Client, scriptProvider: IScriptProvider);
    rgbppLockScriptTemplate(): Promise<ccc.Script>;
    btcTimeLockScriptTemplate(): Promise<ccc.Script>;
    buildRgbppLockScript(utxoSeal: UtxoSeal): Promise<ccc.Script>;
    buildPseudoRgbppLockScript(): Promise<ccc.Script>;
    buildBtcTimeLockScript(ckbAddress: string, confirmations?: number): Promise<ccc.Script>;
    getRgbppScriptInfos(): Promise<Record<RgbppScriptName, ccc.ScriptInfo>>;
    injectTxIdToRgbppCkbTx: (tx: ccc.Transaction, txId: string) => Promise<ccc.Transaction>;
    createRgbppUdtIssuanceCells(signer: ccc.Signer, utxoSeal: UtxoSeal): Promise<ccc.Cell[]>;
}
//# sourceMappingURL=client.d.ts.map