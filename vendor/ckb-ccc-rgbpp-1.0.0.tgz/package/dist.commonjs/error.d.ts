export declare class ErrorBtcUnsupportedAddressType extends Error {
    readonly addressType: string;
    readonly supported: readonly string[];
    constructor(addressType: string, supported: readonly string[]);
}
export declare class ErrorBtcInvalidAddress extends Error {
    readonly address: string;
    constructor(address: string);
}
export declare class ErrorBtcInsufficientFunds extends Error {
    readonly required: number;
    readonly available: number;
    constructor(required: number, available: number);
}
export declare class ErrorBtcTransactionNotFound extends Error {
    readonly txid: string;
    constructor(txid: string);
}
export declare class ErrorBtcUtxoNotFound extends Error {
    readonly txid: string;
    readonly vout: number;
    readonly txVoutCount: number;
    constructor(txid: string, vout: number, txVoutCount: number);
}
export declare class ErrorBtcOpReturnUtxo extends Error {
    readonly txid: string;
    readonly vout: number;
    constructor(txid: string, vout: number);
}
export declare class ErrorBtcMissingPublicKey extends Error {
    readonly address: string;
    constructor(address: string);
}
export declare class ErrorRgbppInvalidLockArgs extends Error {
    readonly argsLength: number;
    readonly minLength: number;
    constructor(argsLength: number, minLength: number);
}
export declare class ErrorRgbppScriptNotFound extends Error {
    readonly scriptName: string;
    constructor(scriptName: string);
}
export declare class ErrorRgbppInvalidCellLock extends Error {
    readonly expected: string[];
    readonly actual: string;
    constructor(expected: string[], actual: string);
}
export declare class ErrorRgbppOutputNotFound extends Error {
    constructor();
}
export declare class ErrorRgbppInvalidInputLock extends Error {
    readonly codeHash: string;
    constructor(codeHash: string);
}
export declare class ErrorRgbppMaxCellExceeded extends Error {
    readonly count: number;
    readonly max: number;
    constructor(count: number, max: number);
}
export declare class ErrorRgbppNoTypedOutput extends Error {
    constructor();
}
export declare class ErrorRgbppCellNotFound extends Error {
    readonly txHash: string;
    constructor(txHash: string);
}
//# sourceMappingURL=error.d.ts.map