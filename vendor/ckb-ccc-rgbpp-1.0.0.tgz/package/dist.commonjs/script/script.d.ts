import { ccc } from "@ckb-ccc/core";
import { UtxoSeal } from "../bitcoin/transaction/index.js";
/**
 * Required RGBPP scripts that must be provided
 * @public
 */
export declare const RGBPP_REQUIRED_SCRIPTS: readonly [ccc.KnownScript.RgbppLock, ccc.KnownScript.BtcTimeLock, ccc.KnownScript.UniqueType];
/**
 * Type representing the required RGBPP script names
 * @public
 */
export type RgbppScriptName = (typeof RGBPP_REQUIRED_SCRIPTS)[number];
/**
 * @public
 */
export type ExtraCommitmentDataLike = {
    inputLen: ccc.NumLike;
    outputLen: ccc.NumLike;
};
declare const ExtraCommitmentData_base: (abstract new () => {
    toBytes(): ccc.Bytes;
    clone(): ExtraCommitmentData;
    eq(other: ExtraCommitmentDataLike): boolean;
    hash(): ccc.Hex;
    toHex(): ccc.Hex;
}) & {
    byteLength?: number;
    encode(_: ExtraCommitmentDataLike): ccc.Bytes;
    decode(_: ccc.BytesLike): ExtraCommitmentData;
    fromBytes(_bytes: ccc.BytesLike): ExtraCommitmentData;
    from(_: ExtraCommitmentDataLike): ExtraCommitmentData;
};
export declare class ExtraCommitmentData extends ExtraCommitmentData_base {
    inputLen: ccc.Num;
    outputLen: ccc.Num;
    constructor(inputLen: ccc.Num, outputLen: ccc.Num);
    static from(ec: ExtraCommitmentDataLike): ExtraCommitmentData;
}
/**
 * @public
 */
export type RgbppUnlockLike = {
    version: ccc.NumLike;
    extraData: ExtraCommitmentDataLike;
    btcTx: ccc.HexLike;
    btcTxProof: ccc.HexLike;
};
declare const RgbppUnlock_base: (abstract new () => {
    toBytes(): ccc.Bytes;
    clone(): RgbppUnlock;
    eq(other: RgbppUnlockLike): boolean;
    hash(): ccc.Hex;
    toHex(): ccc.Hex;
}) & {
    byteLength?: number;
    encode(_: RgbppUnlockLike): ccc.Bytes;
    decode(_: ccc.BytesLike): RgbppUnlock;
    fromBytes(_bytes: ccc.BytesLike): RgbppUnlock;
    from(_: RgbppUnlockLike): RgbppUnlock;
};
/**
 * @public
 */
export declare class RgbppUnlock extends RgbppUnlock_base {
    version: ccc.Num;
    extraData: ExtraCommitmentData;
    btcTx: ccc.Hex;
    btcTxProof: ccc.Hex;
    constructor(version: ccc.Num, extraData: ExtraCommitmentData, btcTx: ccc.Hex, btcTxProof: ccc.Hex);
    static from(ru: RgbppUnlockLike): RgbppUnlock;
}
/**
 * @public
 */
export type BtcTimeLockLike = {
    lockScript: ccc.Script;
    after: ccc.NumLike;
    btcTxid: ccc.HexLike;
};
declare const BtcTimeLock_base: (abstract new () => {
    toBytes(): ccc.Bytes;
    clone(): BtcTimeLock;
    eq(other: BtcTimeLockLike): boolean;
    hash(): ccc.Hex;
    toHex(): ccc.Hex;
}) & {
    byteLength?: number;
    encode(_: BtcTimeLockLike): ccc.Bytes;
    decode(_: ccc.BytesLike): BtcTimeLock;
    fromBytes(_bytes: ccc.BytesLike): BtcTimeLock;
    from(_: BtcTimeLockLike): BtcTimeLock;
};
/**
 * @public
 */
export declare class BtcTimeLock extends BtcTimeLock_base {
    lockScript: ccc.Script;
    after: ccc.Num;
    btcTxid: ccc.Hex;
    constructor(lockScript: ccc.Script, after: ccc.Num, btcTxid: ccc.Hex);
    static from(btl: BtcTimeLockLike): BtcTimeLock;
}
/**
 * @public
 */
export type BtcTimeUnlockLike = {
    btcTxProof: ccc.HexLike;
};
declare const BtcTimeUnlock_base: (abstract new () => {
    toBytes(): ccc.Bytes;
    clone(): BtcTimeUnlock;
    eq(other: BtcTimeUnlockLike): boolean;
    hash(): ccc.Hex;
    toHex(): ccc.Hex;
}) & {
    byteLength?: number;
    encode(_: BtcTimeUnlockLike): ccc.Bytes;
    decode(_: ccc.BytesLike): BtcTimeUnlock;
    fromBytes(_bytes: ccc.BytesLike): BtcTimeUnlock;
    from(_: BtcTimeUnlockLike): BtcTimeUnlock;
};
/**
 * @public
 */
export declare class BtcTimeUnlock extends BtcTimeUnlock_base {
    btcTxProof: ccc.Hex;
    constructor(btcTxProof: ccc.Hex);
    static from(btul: BtcTimeUnlockLike): BtcTimeUnlock;
}
export declare const RGBPP_BTC_BLANK_TX_ID = "0000000000000000000000000000000000000000000000000000000000000000";
export declare const RGBPP_BTC_TX_ID_PLACEHOLDER_PRE_IMAGE = "sha256 this for easy replacement in spore co-build witness";
export declare const RGBPP_BTC_TX_ID_PLACEHOLDER: string;
export declare const RGBPP_BTC_TX_PSEUDO_INDEX = 4294967295;
export declare const RGBPP_BTC_TX_DEFAULT_CONFIRMATIONS = 6;
export declare const RGBPP_UNIQUE_TYPE_OUTPUT_INDEX = 1;
export declare const RGBPP_CONFIG_CELL_INDEX = 1;
export declare const deadLock: ccc.Script;
/**
 * https://learnmeabitcoin.com/technical/general/byte-order/
 * Whenever you're working with transaction/block hashes internally (e.g. inside raw bitcoin data), you use the natural byte order.
 * Whenever you're displaying or searching for transaction/block hashes, you use the reverse byte order.
 */
export declare const buildRgbppLockArgs: (utxoSeal: UtxoSeal) => ccc.Hex;
export declare function pseudoRgbppLockArgs(): ccc.Hex;
export declare function pseudoRgbppLockArgsForCommitment(index: number): ccc.Hex;
export declare const buildBtcTimeLockArgs: (receiverLock: ccc.Script, btcTxId: string, confirmations?: number) => ccc.Hex;
export declare const buildUniqueTypeArgs: (firstInput: ccc.CellInput, firstOutputIndex: number) => string;
export declare const buildRgbppUnlock: (btcLikeTxBytes: string, btcLikeTxProof: ccc.Hex, inputLen: number, outputLen: number) => `0x${string}`;
export declare const isSameScriptTemplate: (lock1: ccc.Script, lock2: ccc.Script) => boolean;
export declare const isUsingOneOfScripts: (script: ccc.Script, scripts: ccc.Script[]) => boolean;
export declare const updateScriptArgsWithTxId: (args: ccc.Hex, txId: string) => string;
export declare function getTxIdFromRgbppLockArgs(args: ccc.Hex): string;
export declare function getTxIndexFromRgbppLockArgs(args: ccc.Hex): number;
export declare function parseUtxoSealFromRgbppLockArgs(args: ccc.Hex): UtxoSeal;
export declare function deduplicateByOutPoint<T extends {
    outPoint: ccc.OutPoint;
}>(items: T[]): T[];
export declare const parseBtcTimeLockArgs: (args: string) => {
    lock: ccc.Script;
    confirmations: number;
    btcTxId: string;
};
export declare const buildBtcTimeUnlockWitness: (btcTxProof: string) => ccc.Hex;
export declare function btcTxIdInReverseByteOrder(btcTxId: string): string;
export {};
//# sourceMappingURL=script.d.ts.map