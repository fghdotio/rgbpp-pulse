import { ccc } from "@ckb-ccc/core";
import { UtxoSeal } from "../bitcoin/transaction/index.js";
import { IScriptProvider } from "./provider.js";
import { RgbppScriptName } from "./script.js";
/**
 * ScriptManager - Manages and builds RGB++ related scripts
 *
 * Uses IScriptProvider for flexible script source configuration.
 * Supports multiple script sources through provider composition.
 *
 * @example
 * ```typescript
 * import { ScriptManager, ClientScriptProvider } from "@ckb-ccc/rgbpp";
 *
 * // Basic usage with client
 * const manager = new ScriptManager(new ClientScriptProvider(client));
 *
 * // With custom scripts
 * const manager = new ScriptManager(
 *   createScriptProvider(client, customScripts)
 * );
 * ```
 */
export declare class ScriptManager {
    private provider;
    constructor(provider: IScriptProvider);
    /**
     * Get script info by name using the configured provider
     *
     * @param name - Known script name from ccc.KnownScript
     * @returns ccc.ScriptInfo containing code hash, hash type, and cell dependencies
     */
    getKnownScriptInfo(name: ccc.KnownScript): Promise<ccc.ScriptInfo>;
    /**
     * Get all required RGBPP script infos in one call
     * This is a convenience method for initializing CkbRgbppUnlockSigner
     *
     * @returns Record containing RgbppLock, BtcTimeLock, and UniqueType script infos
     * @example
     * ```typescript
     * const scriptInfos = await scriptManager.getRgbppScriptInfos();
     * const signer = new CkbRgbppUnlockSigner({
     *   ckbClient,
     *   rgbppBtcAddress,
     *   btcDataSource,
     *   scriptInfos,
     * });
     * ```
     */
    getRgbppScriptInfos(): Promise<Record<RgbppScriptName, ccc.ScriptInfo>>;
    buildPseudoRgbppLockScript(): Promise<ccc.Script>;
    buildRgbppLockScript(utxoSeal: UtxoSeal): Promise<ccc.Script>;
    buildBtcTimeLockScript(receiverLock: ccc.Script, btcTxId: string, confirmations?: number): Promise<ccc.Script>;
    /**
     * Build unique type script by firstInput and outputIndex
     *
     * @see https://github.com/nervosnetwork/rfcs/blob/master/rfcs/0022-transaction-structure/0022-transaction-structure.md#type-id
     *
     * There are two ways to create a new cell with a specific type id.
     *
     * 1. Create a transaction which uses any out point as tx.inputs[0] and has a output cell whose type script is Type ID. The output cell's type script args is the hash of tx.inputs[0] and its output index. Because any out point can only be used once as an input, tx.inputs[0] and thus the new type id must be different in each creation transaction.
     * 2. Destroy an old cell with a specific type id and create a new cell with the same type id in the same transaction.
     *
     * @param firstInput - The first input of the transaction
     * @param outputIndex - The index of the output cell
     */
    buildUniqueTypeScript(firstInput: ccc.CellInput, outputIndex: number): Promise<ccc.Script>;
    /**
     * Get RGB++ lock script template (without args)
     */
    rgbppLockScriptTemplate(): Promise<ccc.Script>;
    /**
     * Get BTC time lock script template (without args)
     */
    btcTimeLockScriptTemplate(): Promise<ccc.Script>;
}
//# sourceMappingURL=manager.d.ts.map