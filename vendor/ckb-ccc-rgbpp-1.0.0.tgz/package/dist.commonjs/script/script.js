var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var ExtraCommitmentData_1, RgbppUnlock_1, BtcTimeLock_1, BtcTimeUnlock_1;
import { sha256 } from "@noble/hashes/sha2";
import { ccc, mol } from "@ckb-ccc/core";
import { ErrorRgbppInvalidLockArgs } from "../error.js";
/**
 * Required RGBPP scripts that must be provided
 * @public
 */
export const RGBPP_REQUIRED_SCRIPTS = [
    ccc.KnownScript.RgbppLock,
    ccc.KnownScript.BtcTimeLock,
    ccc.KnownScript.UniqueType,
];
let ExtraCommitmentData = ExtraCommitmentData_1 = class ExtraCommitmentData extends mol.Entity.Base() {
    constructor(inputLen, outputLen) {
        super();
        this.inputLen = inputLen;
        this.outputLen = outputLen;
    }
    static from(ec) {
        return new ExtraCommitmentData_1(ccc.numFrom(ec.inputLen), ccc.numFrom(ec.outputLen));
    }
};
ExtraCommitmentData = ExtraCommitmentData_1 = __decorate([
    mol.codec(mol.struct({
        inputLen: mol.Uint8,
        outputLen: mol.Uint8,
    }))
], ExtraCommitmentData);
export { ExtraCommitmentData };
/**
 * @public
 */
let RgbppUnlock = RgbppUnlock_1 = class RgbppUnlock extends mol.Entity.Base() {
    constructor(version, extraData, btcTx, btcTxProof) {
        super();
        this.version = version;
        this.extraData = extraData;
        this.btcTx = btcTx;
        this.btcTxProof = btcTxProof;
    }
    static from(ru) {
        return new RgbppUnlock_1(ccc.numFrom(ru.version), ExtraCommitmentData.from(ru.extraData), ccc.hexFrom(ru.btcTx), ccc.hexFrom(ru.btcTxProof));
    }
};
RgbppUnlock = RgbppUnlock_1 = __decorate([
    mol.codec(mol.table({
        version: mol.Uint16,
        extraData: ExtraCommitmentData,
        btcTx: mol.Bytes,
        btcTxProof: mol.Bytes,
    }))
], RgbppUnlock);
export { RgbppUnlock };
/**
 * @public
 */
let BtcTimeLock = BtcTimeLock_1 = class BtcTimeLock extends mol.Entity.Base() {
    constructor(lockScript, after, btcTxid) {
        super();
        this.lockScript = lockScript;
        this.after = after;
        this.btcTxid = btcTxid;
    }
    static from(btl) {
        return new BtcTimeLock_1(ccc.Script.from(btl.lockScript), ccc.numFrom(btl.after), ccc.hexFrom(btl.btcTxid));
    }
};
BtcTimeLock = BtcTimeLock_1 = __decorate([
    mol.codec(mol.table({
        lockScript: ccc.Script,
        after: mol.Uint32,
        btcTxid: mol.Byte32,
    }))
], BtcTimeLock);
export { BtcTimeLock };
/**
 * @public
 */
let BtcTimeUnlock = BtcTimeUnlock_1 = class BtcTimeUnlock extends mol.Entity.Base() {
    constructor(btcTxProof) {
        super();
        this.btcTxProof = btcTxProof;
    }
    static from(btul) {
        return new BtcTimeUnlock_1(ccc.hexFrom(btul.btcTxProof));
    }
};
BtcTimeUnlock = BtcTimeUnlock_1 = __decorate([
    mol.codec(mol.table({
        btcTxProof: mol.Bytes,
    }))
], BtcTimeUnlock);
export { BtcTimeUnlock };
// https://github.com/RGBPlusPlus/rgbpp/blob/main/contracts/rgbpp-lock/src/main.rs#L228
export const RGBPP_BTC_BLANK_TX_ID = "0000000000000000000000000000000000000000000000000000000000000000";
export const RGBPP_BTC_TX_ID_PLACEHOLDER_PRE_IMAGE = "sha256 this for easy replacement in spore co-build witness";
export const RGBPP_BTC_TX_ID_PLACEHOLDER = ccc.bytesTo(sha256(ccc.bytesFrom(RGBPP_BTC_TX_ID_PLACEHOLDER_PRE_IMAGE, "utf8")), "hex");
export const RGBPP_BTC_TX_PSEUDO_INDEX = 0xffffffff; // 4,294,967,295 (max u32)
export const RGBPP_BTC_TX_DEFAULT_CONFIRMATIONS = 6;
export const RGBPP_UNIQUE_TYPE_OUTPUT_INDEX = 1;
export const RGBPP_CONFIG_CELL_INDEX = 1;
export const deadLock = ccc.Script.from({
    codeHash: "0x0000000000000000000000000000000000000000000000000000000000000000",
    hashType: "data",
    args: "0x",
});
/**
 * https://learnmeabitcoin.com/technical/general/byte-order/
 * Whenever you're working with transaction/block hashes internally (e.g. inside raw bitcoin data), you use the natural byte order.
 * Whenever you're displaying or searching for transaction/block hashes, you use the reverse byte order.
 */
export const buildRgbppLockArgs = (utxoSeal) => {
    return ccc.hexFrom(ccc.bytesConcat(ccc.numLeToBytes(utxoSeal.vout, 4), ccc.bytesFrom(utxoSeal.txid).reverse()));
};
export function pseudoRgbppLockArgs() {
    return buildRgbppLockArgs({
        txid: RGBPP_BTC_TX_ID_PLACEHOLDER,
        vout: RGBPP_BTC_TX_PSEUDO_INDEX,
    });
}
export function pseudoRgbppLockArgsForCommitment(index) {
    return buildRgbppLockArgs({
        txid: RGBPP_BTC_BLANK_TX_ID,
        vout: index,
    });
}
export const buildBtcTimeLockArgs = (receiverLock, btcTxId, confirmations = RGBPP_BTC_TX_DEFAULT_CONFIRMATIONS) => {
    return ccc.hexFrom(BtcTimeLock.encode({
        lockScript: receiverLock,
        after: confirmations,
        btcTxid: ccc.hexFrom(ccc.bytesFrom(btcTxId).reverse()),
    }));
};
export const buildUniqueTypeArgs = (firstInput, firstOutputIndex) => {
    const input = ccc.bytesFrom(firstInput.toBytes());
    const s = new ccc.HasherCkb();
    s.update(input);
    s.update(ccc.numLeToBytes(firstOutputIndex, 8));
    return s.digest().slice(0, 42);
};
export const buildRgbppUnlock = (btcLikeTxBytes, btcLikeTxProof, inputLen, outputLen) => {
    return ccc.hexFrom(RgbppUnlock.encode({
        version: 0,
        extraData: {
            inputLen,
            outputLen,
        },
        btcTx: ccc.hexFrom(btcLikeTxBytes),
        btcTxProof: ccc.hexFrom(btcLikeTxProof),
    }));
};
export const isSameScriptTemplate = (lock1, lock2) => {
    return lock1.codeHash === lock2.codeHash && lock1.hashType === lock2.hashType;
};
export const isUsingOneOfScripts = (script, scripts) => {
    return (scripts.length > 0 && scripts.some((s) => isSameScriptTemplate(s, script)));
};
export const updateScriptArgsWithTxId = (args, txId) => {
    const argsBytes = ccc.bytesFrom(args);
    if (argsBytes.length < 32) {
        throw new ErrorRgbppInvalidLockArgs(argsBytes.length, 32);
    }
    const txIdBytes = ccc.bytesFrom(txId).reverse();
    const newArgs = ccc.bytesConcat(argsBytes.subarray(0, argsBytes.length - 32), txIdBytes);
    return ccc.hexFrom(newArgs);
};
export function getTxIdFromRgbppLockArgs(args) {
    const argsBytes = ccc.bytesFrom(args);
    if (argsBytes.length < 32) {
        throw new ErrorRgbppInvalidLockArgs(argsBytes.length, 32);
    }
    return ccc.bytesTo(argsBytes.subarray(argsBytes.length - 32).reverse(), "hex");
}
export function getTxIndexFromRgbppLockArgs(args) {
    const argsBytes = ccc.bytesFrom(args);
    if (argsBytes.length < 32) {
        throw new ErrorRgbppInvalidLockArgs(argsBytes.length, 32);
    }
    return Number(ccc.numLeFromBytes(argsBytes.subarray(0, 4)));
}
export function parseUtxoSealFromRgbppLockArgs(args) {
    return {
        txid: getTxIdFromRgbppLockArgs(args),
        vout: getTxIndexFromRgbppLockArgs(args),
    };
}
export function deduplicateByOutPoint(items) {
    const seen = new Set();
    return items.filter((item) => {
        const key = `${item.outPoint.txHash}-${item.outPoint.index.toString()}`;
        if (seen.has(key))
            return false;
        seen.add(key);
        return true;
    });
}
export const parseBtcTimeLockArgs = (args) => {
    const { lockScript, after: confirmations, btcTxid: btcTxId, } = BtcTimeLock.decode(ccc.hexFrom(args));
    return {
        lock: lockScript,
        confirmations: Number(confirmations),
        btcTxId: btcTxIdInReverseByteOrder(btcTxId),
    };
};
export const buildBtcTimeUnlockWitness = (btcTxProof) => {
    const btcTimeUnlock = BtcTimeUnlock.encode({
        btcTxProof: ccc.hexFrom(btcTxProof),
    });
    return ccc.hexFrom(ccc.WitnessArgs.from({
        lock: ccc.hexFrom(btcTimeUnlock),
        inputType: "",
        outputType: "",
    }).toBytes());
};
export function btcTxIdInReverseByteOrder(btcTxId) {
    return ccc.bytesTo(ccc.bytesFrom(btcTxId).reverse(), "hex");
}
