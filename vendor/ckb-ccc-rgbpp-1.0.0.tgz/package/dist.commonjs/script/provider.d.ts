import { ccc } from "@ckb-ccc/core";
/**
 * Script provider interface
 * Implement this interface to provide custom script sources
 *
 * Returns ccc.ScriptInfo which contains the script's code hash, hash type, and cell dependencies.
 *
 * @public
 */
export interface IScriptProvider {
    getScriptInfo(name: ccc.KnownScript): Promise<ccc.ScriptInfo>;
}
/**
 * ClientScriptProvider - Fetches script info from CKB client with caching
 *
 * @example
 * ```typescript
 * const provider = new ClientScriptProvider(client);
 * const scriptInfo = await provider.getScriptInfo(ccc.KnownScript.RgbppLock);
 * ```
 */
export declare class ClientScriptProvider implements IScriptProvider {
    private client;
    private cache;
    constructor(client: ccc.Client);
    getScriptInfo(name: ccc.KnownScript): Promise<ccc.ScriptInfo>;
    /**
     * Clear the internal cache
     */
    clearCache(): void;
}
/**
 * StaticScriptProvider - Uses predefined script configurations
 *
 * @example
 * ```typescript
 * const provider = new StaticScriptProvider({
 *   [ccc.KnownScript.RgbppLock]: ccc.ScriptInfo.from({
 *     codeHash: "0x...",
 *     hashType: "type",
 *     cellDeps: [{ outPoint: { txHash: "0x...", index: 0 }, depType: "code" }]
 *   })
 * });
 * ```
 */
export declare class StaticScriptProvider implements IScriptProvider {
    private scripts;
    constructor(scripts: Partial<Record<ccc.KnownScript, ccc.ScriptInfo>>);
    getScriptInfo(name: ccc.KnownScript): Promise<ccc.ScriptInfo>;
}
/**
 * CompositeScriptProvider - Tries multiple providers in order until one succeeds
 *
 * **Priority**: Providers are tried in array order - the first provider has the highest priority.
 * If a provider throws an error, the next provider is tried. This enables fallback strategies.
 *
 * Common use cases:
 * - **Custom scripts with fallback**: Try user-defined scripts first, then fall back to client
 * - **Multi-source**: Support multiple script sources with priority
 * - **Override**: Override specific scripts while keeping others from the default source
 *
 * @example
 * ```typescript
 * // Priority: Custom scripts (highest) → Client (fallback)
 * const provider = new CompositeScriptProvider([
 *   new StaticScriptProvider(customScripts),  // Tried first
 *   new ClientScriptProvider(client),         // Tried if custom fails
 * ]);
 *
 * // Priority: TestNet → MainNet (for testing with mainnet fallback)
 * const provider = new CompositeScriptProvider([
 *   new ClientScriptProvider(testnetClient),  // Tried first
 *   new ClientScriptProvider(mainnetClient),  // Fallback
 * ]);
 * ```
 */
export declare class CompositeScriptProvider implements IScriptProvider {
    private providers;
    /**
     * @param providers - Array of providers in priority order (first = highest priority)
     */
    constructor(providers: IScriptProvider[]);
    getScriptInfo(name: ccc.KnownScript): Promise<ccc.ScriptInfo>;
    /**
     * Add a high-priority provider (inserted at the beginning)
     * Useful for adding override scripts without recreating the provider chain
     *
     * @example
     * ```typescript
     * const baseProvider = createScriptProvider(client);
     * const withOverrides = baseProvider.withHighPriority(
     *   new StaticScriptProvider(overrideScripts)
     * );
     * ```
     */
    withHighPriority(provider: IScriptProvider): CompositeScriptProvider;
    /**
     * Add a low-priority provider (appended at the end)
     * Useful for adding fallback scripts
     *
     * @example
     * ```typescript
     * const provider = createScriptProvider(client);
     * const withFallback = provider.withFallback(
     *   new StaticScriptProvider(fallbackScripts)
     * );
     * ```
     */
    withFallback(provider: IScriptProvider): CompositeScriptProvider;
    /**
     * Create a composite provider with custom scripts having highest priority
     *
     * @example
     * ```typescript
     * const provider = CompositeScriptProvider.withCustomScripts(
     *   client,
     *   customScripts
     * );
     * ```
     */
    static withCustomScripts(client: ccc.Client, customScripts: Partial<Record<ccc.KnownScript, ccc.ScriptInfo>>): CompositeScriptProvider;
}
/**
 * Factory function to create a script provider with common patterns
 *
 * **Priority when custom scripts provided:**
 * 1. Custom scripts (highest priority) - user-defined configurations
 * 2. Client scripts (fallback) - fetched from CKB node
 *
 * This ensures your custom scripts always take precedence, with automatic fallback
 * to the client for any scripts not defined in your custom configuration.
 *
 * @param client - CKB client instance
 * @param customScripts - Optional custom script configurations (highest priority)
 * @returns A script provider (composite if custom scripts provided, otherwise client-based)
 *
 * @example
 * ```typescript
 * // Without custom scripts - uses client only
 * const provider = createScriptProvider(client);
 *
 * // With custom scripts - custom scripts have highest priority
 * const provider = createScriptProvider(client, {
 *   [ccc.KnownScript.RgbppLock]: myCustomRgbppScript,  // This will be used
 * });
 * // When requesting RgbppLock: returns myCustomRgbppScript
 * // When requesting other scripts: falls back to client
 *
 * // Override specific scripts for testing
 * const testProvider = createScriptProvider(client, {
 *   [ccc.KnownScript.RgbppLock]: testRgbppScript,  // Override for testing
 *   // Other scripts will use client defaults
 * });
 * ```
 */
export declare function createScriptProvider(client: ccc.Client, customScripts?: Partial<Record<ccc.KnownScript, ccc.ScriptInfo>>): IScriptProvider;
//# sourceMappingURL=provider.d.ts.map