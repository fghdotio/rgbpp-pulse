"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExecutorJsonRpc = exports.Executor = exports.ExecutorResponse = exports.ExecutorErrorDecode = exports.ExecutorErrorExecutionFailed = exports.ExecutorErrorUnknown = void 0;
const core_1 = require("@ckb-ccc/core");
const advanced_1 = require("@ckb-ccc/core/advanced");
const utils_js_1 = require("./utils.js");
class ExecutorErrorUnknown extends Error {
    constructor(msg) {
        super(msg);
    }
}
exports.ExecutorErrorUnknown = ExecutorErrorUnknown;
class ExecutorErrorExecutionFailed extends Error {
    constructor(msg) {
        super(msg);
    }
}
exports.ExecutorErrorExecutionFailed = ExecutorErrorExecutionFailed;
class ExecutorErrorDecode extends Error {
    constructor(msg) {
        super(msg);
    }
}
exports.ExecutorErrorDecode = ExecutorErrorDecode;
class ExecutorResponse {
    constructor(res, cellDeps) {
        this.res = res;
        this.cellDeps = cellDeps;
    }
    static new(res, cellDeps) {
        return new ExecutorResponse(res, cellDeps?.map(core_1.ccc.OutPoint.from) ?? []);
    }
    map(fn) {
        try {
            return new ExecutorResponse(fn(this.res), this.cellDeps);
        }
        catch (err) {
            throw new ExecutorErrorDecode(JSON.stringify(err));
        }
    }
}
exports.ExecutorResponse = ExecutorResponse;
/**
 * Represents an SSRI executor.
 */
class Executor {
    async runScriptTry(codeOutPoint, method, args, context) {
        try {
            return await this.runScript(codeOutPoint, method, args, context);
        }
        catch (err) {
            if (err instanceof ExecutorErrorExecutionFailed) {
                return undefined;
            }
            throw err;
        }
    }
}
exports.Executor = Executor;
class ExecutorJsonRpc extends Executor {
    /**
     * Creates an instance of SSRI executor through Json RPC.
     * @param {string} [url] - The external server URL.
     */
    constructor(url, config) {
        super();
        this.requestor =
            config?.requestor ??
                new core_1.ccc.RequestorJsonRpc(url, config, (errAny) => {
                    if (typeof errAny !== "object" ||
                        errAny === null ||
                        !("code" in errAny) ||
                        typeof errAny.code !== "number") {
                        throw new ExecutorErrorUnknown(JSON.stringify(errAny));
                    }
                    if (errAny.code === 1003 || errAny.code === 1004) {
                        if ("message" in errAny && typeof errAny.message === "string") {
                            throw new ExecutorErrorExecutionFailed(errAny.message);
                        }
                        throw new ExecutorErrorExecutionFailed();
                    }
                    if ("message" in errAny && typeof errAny.message === "string") {
                        throw new ExecutorErrorUnknown(errAny.message);
                    }
                    throw new ExecutorErrorUnknown();
                });
    }
    get url() {
        return this.requestor.url;
    }
    /* Calls a method on the SSRI executor through SSRI Server.
     * @param codeOutPoint - The code OutPoint.
     * @param method - The SSRI method.
     * @param args - The arguments for the method.
     * @param context - The SSRI context for the method.
     * @param context.script - The script level parameters.
     * @param context.cell - The cell level parameters. Take precedence over script.
     * @param context.transaction - The transaction level parameters. Take precedence over cell.
     * @returns The result of the call.
     */
    async runScript(codeOutPoint, method, args, context) {
        const code = core_1.ccc.OutPoint.from(codeOutPoint);
        const [rpcMethod, rpcContext] = (() => {
            if (context?.tx) {
                const tx = core_1.ccc.Transaction.from(context.tx);
                return [
                    "run_script_level_transaction",
                    [
                        {
                            inner: advanced_1.cccA.JsonRpcTransformers.transactionFrom(tx),
                            hash: tx.hash(),
                        },
                    ],
                ];
            }
            if (context?.cell) {
                const cell = core_1.ccc.CellAny.from(context.cell);
                return [
                    "run_script_level_cell",
                    [
                        {
                            cell_output: advanced_1.cccA.JsonRpcTransformers.cellOutputFrom(cell.cellOutput, cell.outputData),
                            hex_data: core_1.ccc.hexFrom(cell.outputData),
                        },
                    ],
                ];
            }
            if (context?.script) {
                return [
                    "run_script_level_script",
                    [advanced_1.cccA.JsonRpcTransformers.scriptFrom(context.script)],
                ];
            }
            return ["run_script_level_code", []];
        })();
        const { content, cell_deps } = (await this.requestor.request(rpcMethod, [
            code.txHash,
            Number(code.index),
            [(0, utils_js_1.getMethodPath)(method), ...args.map(core_1.ccc.hexFrom)],
            ...rpcContext,
        ]));
        return ExecutorResponse.new(content, cell_deps.map(advanced_1.cccA.JsonRpcTransformers.outPointTo));
    }
}
exports.ExecutorJsonRpc = ExecutorJsonRpc;
