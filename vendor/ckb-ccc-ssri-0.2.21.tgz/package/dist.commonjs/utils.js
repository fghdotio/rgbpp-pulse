"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getMethodPath = getMethodPath;
const core_1 = require("@ckb-ccc/core");
function getMethodPath(method) {
    return core_1.ccc.hashCkb(core_1.ccc.bytesFrom(method, "utf8")).slice(0, 18);
}
