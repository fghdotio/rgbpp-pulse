export * as ssri from "./barrel.js";
//# sourceMappingURL=index.d.ts.map