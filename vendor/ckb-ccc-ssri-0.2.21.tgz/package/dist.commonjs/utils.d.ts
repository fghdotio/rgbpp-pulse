import { ccc } from "@ckb-ccc/core";
export declare function getMethodPath(method: string): ccc.Hex;
//# sourceMappingURL=utils.d.ts.map