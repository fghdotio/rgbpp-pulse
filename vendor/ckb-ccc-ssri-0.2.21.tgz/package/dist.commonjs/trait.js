"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Trait = void 0;
const core_1 = require("@ckb-ccc/core");
const executor_js_1 = require("./executor.js");
const utils_js_1 = require("./utils.js");
/**
 * Class representing an SSRI trait. Should be used as the base of all SSRI traits.
 */
class Trait {
    /**
     * Creates an instance of SSRI trait.
     * @param code - The cell dependency.
     * @param executor - The SSRI executor instance.
     */
    constructor(code, executor) {
        this.code = core_1.ccc.OutPoint.from(code);
        this.executor = executor ?? undefined;
    }
    static async tryRun(call) {
        try {
            return await call;
        }
        catch (e) {
            if (e instanceof executor_js_1.ExecutorErrorExecutionFailed ||
                e instanceof executor_js_1.ExecutorErrorDecode) {
                return executor_js_1.ExecutorResponse.new(undefined);
            }
            throw e;
        }
    }
    async tryRun(call) {
        return Trait.tryRun(call);
    }
    assertExecutor() {
        if (!this.executor) {
            throw new Error("SSRI executor is not set");
        }
        return this.executor;
    }
    /**
     * Retrieves a list of methods.
     * @param offset - The offset for the methods.
     * @param limit - The limit for the methods.
     * @returns {Promise<Bytes[]>} A promise that resolves to a list of methods.
     */
    async getMethods(offset = 0, limit = 0) {
        const res = await this.assertExecutor().runScript(this.code, "SSRI.get_methods", [core_1.ccc.numToBytes(offset ?? 0, 8), core_1.ccc.numToBytes(limit ?? 0, 8)]);
        return res.map((res) => core_1.ccc.mol.Byte8Vec.decode(res));
    }
    /**
     * Checks if the specified methods exist.
     * @param methodNames - The methods to check.
     * @returns A promise that resolves to an array of booleans indicating if methods exist.
     */
    async hasMethods(methodNames, extraMethodPaths) {
        const methodPaths = core_1.ccc.mol.Byte8Vec.encode(methodNames
            .map(utils_js_1.getMethodPath)
            .concat(extraMethodPaths?.map(core_1.ccc.hexFrom) ?? []));
        const res = await this.assertExecutor().runScript(this.code, "SSRI.has_methods", [methodPaths]);
        return res.map((res) => core_1.ccc.mol.BoolVec.decode(res));
    }
    /**
     * Retrieves the version of the trait.
     * @returns A promise that resolves to the version number.
     */
    async version() {
        const res = await this.assertExecutor().runScript(this.code, "SSRI.version", []);
        return res.map((res) => {
            if (res.length !== 4) {
                throw new Error("Invalid U8");
            }
            return core_1.ccc.numFrom(res);
        });
    }
}
exports.Trait = Trait;
