import { ccc } from "@ckb-ccc/core";
export type ContextTransaction = {
    script?: ccc.ScriptLike | null;
    cell?: ccc.CellAnyLike | null;
    tx: ccc.TransactionLike;
};
export type ContextCell = {
    script?: ccc.ScriptLike | null;
    cell: ccc.CellAnyLike;
    tx?: undefined | null;
};
export type ContextScript = {
    script: ccc.ScriptLike;
    cell?: undefined | null;
    tx?: undefined | null;
};
export declare class ExecutorErrorUnknown extends Error {
    constructor(msg?: string);
}
export declare class ExecutorErrorExecutionFailed extends Error {
    constructor(msg?: string);
}
export declare class ExecutorErrorDecode extends Error {
    constructor(msg?: string);
}
export type ContextCode = undefined | {
    script?: undefined | null;
    cell?: undefined | null;
    tx?: undefined | null;
};
export declare class ExecutorResponse<T> {
    readonly res: T;
    readonly cellDeps: ccc.OutPoint[];
    constructor(res: T, cellDeps: ccc.OutPoint[]);
    static new<T>(res: T, cellDeps?: ccc.OutPointLike[] | null): ExecutorResponse<T>;
    map<U>(fn: (res: T) => U): ExecutorResponse<U>;
}
/**
 * Represents an SSRI executor.
 */
export declare abstract class Executor {
    abstract runScript(codeOutPoint: ccc.OutPointLike, method: string, args: ccc.HexLike[], context?: ContextCode | ContextScript | ContextCell | ContextTransaction): Promise<ExecutorResponse<ccc.Hex>>;
    runScriptTry(codeOutPoint: ccc.OutPointLike, method: string, args: ccc.HexLike[], context?: ContextCode | ContextScript | ContextCell | ContextTransaction): Promise<ExecutorResponse<ccc.Hex> | undefined>;
}
export declare class ExecutorJsonRpc extends Executor {
    readonly requestor: ccc.RequestorJsonRpc;
    /**
     * Creates an instance of SSRI executor through Json RPC.
     * @param {string} [url] - The external server URL.
     */
    constructor(url: string, config?: ccc.RequestorJsonRpcConfig & {
        requestor?: ccc.RequestorJsonRpc;
    });
    get url(): string;
    runScript(codeOutPoint: ccc.OutPointLike, method: string, args: ccc.HexLike[], context?: ContextCode | ContextScript | ContextCell | ContextTransaction): Promise<ExecutorResponse<ccc.Hex>>;
}
//# sourceMappingURL=executor.d.ts.map