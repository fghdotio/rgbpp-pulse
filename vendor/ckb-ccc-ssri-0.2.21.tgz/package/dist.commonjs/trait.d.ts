import { ccc } from "@ckb-ccc/core";
import { Executor, ExecutorResponse } from "./executor.js";
/**
 * Class representing an SSRI trait. Should be used as the base of all SSRI traits.
 */
export declare class Trait {
    readonly code: ccc.OutPoint;
    readonly executor?: Executor;
    /**
     * Creates an instance of SSRI trait.
     * @param code - The cell dependency.
     * @param executor - The SSRI executor instance.
     */
    constructor(code: ccc.OutPointLike, executor?: Executor | null);
    static tryRun<T>(call: Promise<ExecutorResponse<T>>): Promise<ExecutorResponse<T | undefined>>;
    tryRun<T>(call: Promise<ExecutorResponse<T>>): Promise<ExecutorResponse<T | undefined>>;
    assertExecutor(): Executor;
    /**
     * Retrieves a list of methods.
     * @param offset - The offset for the methods.
     * @param limit - The limit for the methods.
     * @returns {Promise<Bytes[]>} A promise that resolves to a list of methods.
     */
    getMethods(offset?: ccc.NumLike, limit?: ccc.NumLike): Promise<ExecutorResponse<ccc.Hex[]>>;
    /**
     * Checks if the specified methods exist.
     * @param methodNames - The methods to check.
     * @returns A promise that resolves to an array of booleans indicating if methods exist.
     */
    hasMethods(methodNames: string[], extraMethodPaths?: ccc.HexLike[]): Promise<ExecutorResponse<boolean[]>>;
    /**
     * Retrieves the version of the trait.
     * @returns A promise that resolves to the version number.
     */
    version(): Promise<ExecutorResponse<ccc.Num>>;
}
//# sourceMappingURL=trait.d.ts.map